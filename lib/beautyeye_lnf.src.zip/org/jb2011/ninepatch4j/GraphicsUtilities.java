/*    */ package org.jb2011.ninepatch4j;
/*    */ 
/*    */ import java.awt.Graphics;
/*    */ import java.awt.GraphicsConfiguration;
/*    */ import java.awt.GraphicsDevice;
/*    */ import java.awt.GraphicsEnvironment;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.awt.image.ColorModel;
/*    */ import java.awt.image.Raster;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import javax.imageio.ImageIO;
/*    */ 
/*    */ public class GraphicsUtilities
/*    */ {
/*    */   public static BufferedImage loadCompatibleImage(URL resource)
/*    */     throws IOException
/*    */   {
/* 17 */     BufferedImage image = ImageIO.read(resource);
/* 18 */     return toCompatibleImage(image);
/*    */   }
/*    */ 
/*    */   public static BufferedImage loadCompatibleImage(InputStream stream) throws IOException
/*    */   {
/* 23 */     BufferedImage image = ImageIO.read(stream);
/* 24 */     return toCompatibleImage(image);
/*    */   }
/*    */ 
/*    */   public static BufferedImage createCompatibleImage(int width, int height)
/*    */   {
/* 29 */     return getGraphicsConfiguration().createCompatibleImage(width, 
/* 30 */       height);
/*    */   }
/*    */ 
/*    */   public static BufferedImage toCompatibleImage(BufferedImage image) {
/* 34 */     if (isHeadless()) {
/* 35 */       return image;
/*    */     }
/*    */ 
/* 38 */     if (image.getColorModel().equals(
/* 39 */       getGraphicsConfiguration().getColorModel())) {
/* 40 */       return image;
/*    */     }
/*    */ 
/* 43 */     BufferedImage compatibleImage = getGraphicsConfiguration()
/* 44 */       .createCompatibleImage(image.getWidth(), 
/* 45 */       image.getHeight(), image.getTransparency());
/* 46 */     Graphics g = compatibleImage.getGraphics();
/* 47 */     g.drawImage(image, 0, 0, null);
/* 48 */     g.dispose();
/*    */ 
/* 50 */     return compatibleImage;
/*    */   }
/*    */ 
/*    */   public static BufferedImage createCompatibleImage(BufferedImage image, int width, int height)
/*    */   {
/* 55 */     return getGraphicsConfiguration().createCompatibleImage(width, 
/* 56 */       height, image.getTransparency());
/*    */   }
/*    */ 
/*    */   private static GraphicsConfiguration getGraphicsConfiguration() {
/* 60 */     GraphicsEnvironment environment = 
/* 61 */       GraphicsEnvironment.getLocalGraphicsEnvironment();
/* 62 */     return environment.getDefaultScreenDevice()
/* 63 */       .getDefaultConfiguration();
/*    */   }
/*    */ 
/*    */   private static boolean isHeadless() {
/* 67 */     return GraphicsEnvironment.isHeadless();
/*    */   }
/*    */ 
/*    */   public static BufferedImage createTranslucentCompatibleImage(int width, int height)
/*    */   {
/* 72 */     return getGraphicsConfiguration().createCompatibleImage(width, 
/* 73 */       height, 3);
/*    */   }
/*    */ 
/*    */   public static int[] getPixels(BufferedImage img, int x, int y, int w, int h, int[] pixels)
/*    */   {
/* 78 */     if ((w == 0) || (h == 0)) {
/* 79 */       return new int[0];
/*    */     }
/*    */ 
/* 82 */     if (pixels == null)
/* 83 */       pixels = new int[w * h];
/* 84 */     else if (pixels.length < w * h) {
/* 85 */       throw new IllegalArgumentException(
/* 86 */         "Pixels array must have a length >= w * h");
/*    */     }
/*    */ 
/* 89 */     int imageType = img.getType();
/* 90 */     if ((imageType == 2) || 
/* 91 */       (imageType == 1)) {
/* 92 */       Raster raster = img.getRaster();
/* 93 */       return (int[])raster.getDataElements(x, y, w, h, pixels);
/*    */     }
/*    */ 
/* 97 */     return img.getRGB(x, y, w, h, pixels, 0, w);
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.ninepatch4j.GraphicsUtilities
 * JD-Core Version:    0.6.2
 */