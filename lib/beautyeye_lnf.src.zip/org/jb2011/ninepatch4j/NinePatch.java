/*     */ package org.jb2011.ninepatch4j;
/*     */ 
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ 
/*     */ public class NinePatch
/*     */ {
/*     */   public static final String EXTENSION_9PATCH = ".9.png";
/*     */   private BufferedImage mImage;
/*     */   private NinePatchChunk mChunk;
/*     */ 
/*     */   public BufferedImage getImage()
/*     */   {
/*  30 */     return this.mImage;
/*     */   }
/*     */ 
/*     */   public NinePatchChunk getChunk() {
/*  34 */     return this.mChunk;
/*     */   }
/*     */ 
/*     */   public static NinePatch load(URL fileUrl, boolean convert)
/*     */     throws IOException
/*     */   {
/*  51 */     BufferedImage image = null;
/*     */     try {
/*  53 */       image = GraphicsUtilities.loadCompatibleImage(fileUrl);
/*     */     }
/*     */     catch (MalformedURLException e) {
/*  56 */       return null;
/*     */     }
/*     */ 
/*  59 */     boolean is9Patch = fileUrl.getPath().toLowerCase().endsWith(
/*  60 */       ".9.png");
/*     */ 
/*  62 */     return load(image, is9Patch, convert);
/*     */   }
/*     */ 
/*     */   public static NinePatch load(InputStream stream, boolean is9Patch, boolean convert)
/*     */     throws IOException
/*     */   {
/*  80 */     BufferedImage image = null;
/*     */     try {
/*  82 */       image = GraphicsUtilities.loadCompatibleImage(stream);
/*     */     }
/*     */     catch (MalformedURLException e) {
/*  85 */       return null;
/*     */     }
/*     */ 
/*  88 */     return load(image, is9Patch, convert);
/*     */   }
/*     */ 
/*     */   public static NinePatch load(BufferedImage image, boolean is9Patch, boolean convert)
/*     */   {
/* 106 */     if (!is9Patch) {
/* 107 */       if (convert)
/* 108 */         image = convertTo9Patch(image);
/*     */       else
/* 110 */         return null;
/*     */     }
/*     */     else {
/* 113 */       ensure9Patch(image);
/*     */     }
/*     */ 
/* 116 */     return new NinePatch(image);
/*     */   }
/*     */ 
/*     */   public int getWidth()
/*     */   {
/* 126 */     return this.mImage.getWidth();
/*     */   }
/*     */ 
/*     */   public int getHeight()
/*     */   {
/* 136 */     return this.mImage.getHeight();
/*     */   }
/*     */ 
/*     */   public boolean getPadding(int[] padding)
/*     */   {
/* 147 */     this.mChunk.getPadding(padding);
/* 148 */     return true;
/*     */   }
/*     */ 
/*     */   public void draw(Graphics2D graphics2D, int x, int y, int scaledWidth, int scaledHeight)
/*     */   {
/* 163 */     this.mChunk.draw(this.mImage, graphics2D, x, y, scaledWidth, 
/* 164 */       scaledHeight, 0, 0);
/*     */   }
/*     */ 
/*     */   private NinePatch(BufferedImage image) {
/* 168 */     this.mChunk = NinePatchChunk.create(image);
/* 169 */     this.mImage = extractBitmapContent(image);
/*     */   }
/*     */ 
/*     */   private static void ensure9Patch(BufferedImage image) {
/* 173 */     int width = image.getWidth();
/* 174 */     int height = image.getHeight();
/* 175 */     for (int i = 0; i < width; i++) {
/* 176 */       int pixel = image.getRGB(i, 0);
/* 177 */       if ((pixel != 0) && (pixel != -16777216)) {
/* 178 */         image.setRGB(i, 0, 0);
/*     */       }
/* 180 */       pixel = image.getRGB(i, height - 1);
/* 181 */       if ((pixel != 0) && (pixel != -16777216)) {
/* 182 */         image.setRGB(i, height - 1, 0);
/*     */       }
/*     */     }
/* 185 */     for (int i = 0; i < height; i++) {
/* 186 */       int pixel = image.getRGB(0, i);
/* 187 */       if ((pixel != 0) && (pixel != -16777216)) {
/* 188 */         image.setRGB(0, i, 0);
/*     */       }
/* 190 */       pixel = image.getRGB(width - 1, i);
/* 191 */       if ((pixel != 0) && (pixel != -16777216))
/* 192 */         image.setRGB(width - 1, i, 0);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static BufferedImage convertTo9Patch(BufferedImage image)
/*     */   {
/* 198 */     BufferedImage buffer = 
/* 199 */       GraphicsUtilities.createTranslucentCompatibleImage(image.getWidth() + 2, 
/* 200 */       image.getHeight() + 2);
/*     */ 
/* 202 */     Graphics2D g2 = buffer.createGraphics();
/* 203 */     g2.drawImage(image, 1, 1, null);
/* 204 */     g2.dispose();
/*     */ 
/* 206 */     return buffer;
/*     */   }
/*     */ 
/*     */   private BufferedImage extractBitmapContent(BufferedImage image) {
/* 210 */     return image.getSubimage(1, 1, image.getWidth() - 2, image
/* 211 */       .getHeight() - 2);
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.ninepatch4j.NinePatch
 * JD-Core Version:    0.6.2
 */