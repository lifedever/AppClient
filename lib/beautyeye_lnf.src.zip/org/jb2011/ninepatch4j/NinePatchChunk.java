/*     */ package org.jb2011.ninepatch4j;
/*     */ 
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class NinePatchChunk
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -7353439224505296217L;
/*  28 */   private static final int[] sPaddingRect = new int[4];
/*     */   private boolean mVerticalStartWithPatch;
/*     */   private boolean mHorizontalStartWithPatch;
/*     */   private List<Rectangle> mFixed;
/*     */   private List<Rectangle> mPatches;
/*     */   private List<Rectangle> mHorizontalPatches;
/*     */   private List<Rectangle> mVerticalPatches;
/*     */   private Pair<Integer> mHorizontalPadding;
/*     */   private Pair<Integer> mVerticalPadding;
/*     */ 
/*     */   public static NinePatchChunk create(BufferedImage image)
/*     */   {
/*  57 */     NinePatchChunk chunk = new NinePatchChunk();
/*  58 */     chunk.findPatches(image);
/*  59 */     return chunk;
/*     */   }
/*     */ 
/*     */   public void draw(BufferedImage image, Graphics2D graphics2D, int x, int y, int scaledWidth, int scaledHeight, int destDensity, int srcDensity)
/*     */   {
/*  66 */     boolean scaling = (destDensity != srcDensity) && (destDensity != 0) && 
/*  67 */       (srcDensity != 0);
/*     */ 
/*  69 */     if (scaling) {
/*     */       try {
/*  71 */         graphics2D = (Graphics2D)graphics2D.create();
/*     */ 
/*  74 */         float densityScale = destDensity / srcDensity;
/*     */ 
/*  77 */         graphics2D.translate(x, y);
/*  78 */         graphics2D.scale(densityScale, densityScale);
/*     */ 
/*  81 */         scaledWidth = (int)(scaledWidth / densityScale);
/*  82 */         scaledHeight = (int)(scaledHeight / densityScale);
/*  83 */         x = y = 0;
/*     */ 
/*  86 */         draw(image, graphics2D, x, y, scaledWidth, scaledHeight);
/*     */       } finally {
/*  88 */         graphics2D.dispose();
/*     */       }
/*     */     }
/*     */     else
/*  92 */       draw(image, graphics2D, x, y, scaledWidth, scaledHeight);
/*     */   }
/*     */ 
/*     */   private void draw(BufferedImage image, Graphics2D graphics2D, int x, int y, int scaledWidth, int scaledHeight)
/*     */   {
/*  98 */     if ((scaledWidth <= 1) || (scaledHeight <= 1)) {
/*  99 */       return;
/*     */     }
/*     */ 
/* 102 */     Graphics2D g = (Graphics2D)graphics2D.create();
/* 103 */     g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, 
/* 104 */       RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/*     */     try
/*     */     {
/* 107 */       if (this.mPatches.size() == 0) {
/* 108 */         g.drawImage(image, x, y, scaledWidth, scaledHeight, 
/* 109 */           null);
/* 110 */         return;
/*     */       }
/*     */ 
/* 113 */       g.translate(x, y);
/* 114 */       x = y = 0;
/*     */ 
/* 116 */       DrawingData data = computePatches(scaledWidth, scaledHeight);
/*     */ 
/* 118 */       int fixedIndex = 0;
/* 119 */       int horizontalIndex = 0;
/* 120 */       int verticalIndex = 0;
/* 121 */       int patchIndex = 0;
/*     */ 
/* 126 */       float vWeightSum = 1.0F;
/* 127 */       float vRemainder = data.mRemainderVertical;
/*     */ 
/* 129 */       boolean vStretch = this.mVerticalStartWithPatch;
/* 130 */       while (y < scaledHeight - 1) {
/* 131 */         boolean hStretch = this.mHorizontalStartWithPatch;
/*     */ 
/* 133 */         int height = 0;
/* 134 */         float vExtra = 0.0F;
/*     */ 
/* 136 */         float hWeightSum = 1.0F;
/* 137 */         float hRemainder = data.mRemainderHorizontal;
/*     */ 
/* 139 */         while (x < scaledWidth - 1)
/*     */         {
/* 141 */           if (!vStretch)
/*     */           {
/*     */             Rectangle r;
/* 142 */             if (hStretch) {
/* 143 */               Rectangle r = 
/* 144 */                 (Rectangle)this.mHorizontalPatches
/* 144 */                 .get(horizontalIndex++);
/* 145 */               float extra = r.width / 
/* 146 */                 data.mHorizontalPatchesSum;
/* 147 */               int width = (int)(extra * hRemainder / hWeightSum);
/* 148 */               hWeightSum -= extra;
/* 149 */               hRemainder -= width;
/* 150 */               g
/* 151 */                 .drawImage(image, x, y, x + width, 
/* 152 */                 y + r.height, r.x, r.y, r.x + 
/* 153 */                 r.width, r.y + 
/* 154 */                 r.height, null);
/* 155 */               x += width;
/*     */             } else {
/* 157 */               r = (Rectangle)this.mFixed.get(fixedIndex++);
/* 158 */               g
/* 159 */                 .drawImage(image, x, y, 
/* 160 */                 x + r.width, y + r.height, 
/* 161 */                 r.x, r.y, r.x + r.width, 
/* 162 */                 r.y + r.height, null);
/* 163 */               x += r.width;
/*     */             }
/* 165 */             height = r.height;
/*     */           }
/* 167 */           else if (hStretch) {
/* 168 */             Rectangle r = (Rectangle)this.mPatches.get(patchIndex++);
/* 169 */             vExtra = r.height / 
/* 170 */               data.mVerticalPatchesSum;
/* 171 */             height = (int)(vExtra * vRemainder / vWeightSum);
/* 172 */             float extra = r.width / 
/* 173 */               data.mHorizontalPatchesSum;
/* 174 */             int width = (int)(extra * hRemainder / hWeightSum);
/* 175 */             hWeightSum -= extra;
/* 176 */             hRemainder -= width;
/* 177 */             g.drawImage(image, x, y, x + width, y + 
/* 178 */               height, r.x, r.y, r.x + r.width, 
/* 179 */               r.y + r.height, null);
/* 180 */             x += width;
/*     */           } else {
/* 182 */             Rectangle r = (Rectangle)this.mVerticalPatches.get(verticalIndex++);
/* 183 */             vExtra = r.height / 
/* 184 */               data.mVerticalPatchesSum;
/* 185 */             height = (int)(vExtra * vRemainder / vWeightSum);
/* 186 */             g.drawImage(image, x, y, x + r.width, y + 
/* 187 */               height, r.x, r.y, r.x + r.width, 
/* 188 */               r.y + r.height, null);
/* 189 */             x += r.width;
/*     */           }
/*     */ 
/* 193 */           hStretch = !hStretch;
/*     */         }
/* 195 */         x = 0;
/* 196 */         y += height;
/* 197 */         if (vStretch) {
/* 198 */           vWeightSum -= vExtra;
/* 199 */           vRemainder -= height;
/*     */         }
/* 201 */         vStretch = !vStretch;
/*     */       }
/*     */     }
/*     */     finally {
/* 205 */       g.dispose(); } g.dispose();
/*     */   }
/*     */ 
/*     */   public void getPadding(int[] padding)
/*     */   {
/* 215 */     padding[0] = ((Integer)this.mHorizontalPadding.mFirst).intValue();
/* 216 */     padding[2] = ((Integer)this.mHorizontalPadding.mSecond).intValue();
/* 217 */     padding[1] = ((Integer)this.mVerticalPadding.mFirst).intValue();
/* 218 */     padding[3] = ((Integer)this.mVerticalPadding.mSecond).intValue();
/*     */   }
/*     */ 
/*     */   public int[] getPadding()
/*     */   {
/* 229 */     getPadding(sPaddingRect);
/* 230 */     return sPaddingRect;
/*     */   }
/*     */ 
/*     */   private DrawingData computePatches(int scaledWidth, int scaledHeight) {
/* 234 */     DrawingData data = new DrawingData();
/* 235 */     boolean measuredWidth = false;
/* 236 */     boolean endRow = true;
/*     */ 
/* 238 */     int remainderHorizontal = 0;
/* 239 */     int remainderVertical = 0;
/*     */ 
/* 241 */     if (this.mFixed.size() > 0) {
/* 242 */       int start = ((Rectangle)this.mFixed.get(0)).y;
/* 243 */       for (Rectangle rect : this.mFixed) {
/* 244 */         if (rect.y > start) {
/* 245 */           endRow = true;
/* 246 */           measuredWidth = true;
/*     */         }
/* 248 */         if (!measuredWidth) {
/* 249 */           remainderHorizontal += rect.width;
/*     */         }
/* 251 */         if (endRow) {
/* 252 */           remainderVertical += rect.height;
/* 253 */           endRow = false;
/* 254 */           start = rect.y;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 259 */     data.mRemainderHorizontal = (scaledWidth - remainderHorizontal);
/* 260 */     data.mRemainderVertical = (scaledHeight - remainderVertical);
/*     */ 
/* 262 */     data.mHorizontalPatchesSum = 0.0F;
/* 263 */     if (this.mHorizontalPatches.size() > 0) {
/* 264 */       int start = -1;
/* 265 */       for (Rectangle rect : this.mHorizontalPatches)
/* 266 */         if (rect.x > start) {
/* 267 */           data.mHorizontalPatchesSum += rect.width;
/* 268 */           start = rect.x;
/*     */         }
/*     */     }
/*     */     else {
/* 272 */       int start = -1;
/* 273 */       for (Rectangle rect : this.mPatches) {
/* 274 */         if (rect.x > start) {
/* 275 */           data.mHorizontalPatchesSum += rect.width;
/* 276 */           start = rect.x;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 281 */     data.mVerticalPatchesSum = 0.0F;
/* 282 */     if (this.mVerticalPatches.size() > 0) {
/* 283 */       int start = -1;
/* 284 */       for (Rectangle rect : this.mVerticalPatches)
/* 285 */         if (rect.y > start) {
/* 286 */           data.mVerticalPatchesSum += rect.height;
/* 287 */           start = rect.y;
/*     */         }
/*     */     }
/*     */     else {
/* 291 */       int start = -1;
/* 292 */       for (Rectangle rect : this.mPatches) {
/* 293 */         if (rect.y > start) {
/* 294 */           data.mVerticalPatchesSum += rect.height;
/* 295 */           start = rect.y;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 300 */     return data;
/*     */   }
/*     */ 
/*     */   private void findPatches(BufferedImage image)
/*     */   {
/* 309 */     int width = image.getWidth() - 2;
/* 310 */     int height = image.getHeight() - 2;
/*     */ 
/* 312 */     int[] row = (int[])null;
/* 313 */     int[] column = (int[])null;
/*     */ 
/* 317 */     row = GraphicsUtilities.getPixels(image, 1, 0, width, 1, row);
/* 318 */     column = GraphicsUtilities.getPixels(image, 0, 1, 1, height, 
/* 319 */       column);
/*     */ 
/* 321 */     boolean[] result = new boolean[1];
/* 322 */     Pair left = getPatches(column, result);
/* 323 */     this.mVerticalStartWithPatch = result[0];
/*     */ 
/* 325 */     result = new boolean[1];
/* 326 */     Pair top = getPatches(row, result);
/* 327 */     this.mHorizontalStartWithPatch = result[0];
/*     */ 
/* 329 */     this.mFixed = getRectangles((List)left.mFirst, (List)top.mFirst);
/* 330 */     this.mPatches = getRectangles((List)left.mSecond, (List)top.mSecond);
/*     */ 
/* 332 */     if (this.mFixed.size() > 0) {
/* 333 */       this.mHorizontalPatches = getRectangles((List)left.mFirst, (List)top.mSecond);
/* 334 */       this.mVerticalPatches = getRectangles((List)left.mSecond, (List)top.mFirst);
/*     */     }
/* 336 */     else if (((List)top.mFirst).size() > 0) {
/* 337 */       this.mHorizontalPatches = new ArrayList(0);
/* 338 */       this.mVerticalPatches = getVerticalRectangles(height, 
/* 339 */         (List)top.mFirst);
/* 340 */     } else if (((List)left.mFirst).size() > 0) {
/* 341 */       this.mHorizontalPatches = getHorizontalRectangles(width, 
/* 342 */         (List)left.mFirst);
/* 343 */       this.mVerticalPatches = new ArrayList(0);
/*     */     } else {
/* 345 */       this.mHorizontalPatches = (this.mVerticalPatches = new ArrayList(
/* 346 */         0));
/*     */     }
/*     */ 
/* 352 */     row = GraphicsUtilities.getPixels(image, 1, height + 1, width, 
/* 353 */       1, row);
/* 354 */     column = GraphicsUtilities.getPixels(image, width + 1, 1, 1, 
/* 355 */       height, column);
/*     */ 
/* 357 */     top = getPatches(row, result);
/* 358 */     this.mHorizontalPadding = getPadding((List)top.mFirst);
/*     */ 
/* 360 */     left = getPatches(column, result);
/* 361 */     this.mVerticalPadding = getPadding((List)left.mFirst);
/*     */   }
/*     */ 
/*     */   private List<Rectangle> getVerticalRectangles(int imageHeight, List<Pair<Integer>> topPairs)
/*     */   {
/* 366 */     List rectangles = new ArrayList();
/* 367 */     for (Pair top : topPairs) {
/* 368 */       int x = ((Integer)top.mFirst).intValue();
/* 369 */       int width = ((Integer)top.mSecond).intValue() - ((Integer)top.mFirst).intValue();
/*     */ 
/* 371 */       rectangles.add(new Rectangle(x, 0, width, imageHeight));
/*     */     }
/* 373 */     return rectangles;
/*     */   }
/*     */ 
/*     */   private List<Rectangle> getHorizontalRectangles(int imageWidth, List<Pair<Integer>> leftPairs)
/*     */   {
/* 378 */     List rectangles = new ArrayList();
/* 379 */     for (Pair left : leftPairs) {
/* 380 */       int y = ((Integer)left.mFirst).intValue();
/* 381 */       int height = ((Integer)left.mSecond).intValue() - ((Integer)left.mFirst).intValue();
/*     */ 
/* 383 */       rectangles.add(new Rectangle(0, y, imageWidth, height));
/*     */     }
/* 385 */     return rectangles;
/*     */   }
/*     */ 
/*     */   private Pair<Integer> getPadding(List<Pair<Integer>> pairs) {
/* 389 */     if (pairs.size() == 0)
/* 390 */       return new Pair(Integer.valueOf(0), Integer.valueOf(0));
/* 391 */     if (pairs.size() == 1) {
/* 392 */       if (((Integer)((Pair)pairs.get(0)).mFirst).intValue() == 0) {
/* 393 */         return new Pair(
/* 394 */           Integer.valueOf(((Integer)((Pair)pairs.get(0)).mSecond).intValue() - 
/* 394 */           ((Integer)((Pair)pairs.get(0)).mFirst).intValue()), Integer.valueOf(0));
/*     */       }
/* 396 */       return new Pair(Integer.valueOf(0), 
/* 397 */         Integer.valueOf(((Integer)((Pair)pairs.get(0)).mSecond).intValue() - 
/* 397 */         ((Integer)((Pair)pairs.get(0)).mFirst).intValue()));
/*     */     }
/*     */ 
/* 400 */     int index = pairs.size() - 1;
/* 401 */     return new Pair(
/* 402 */       Integer.valueOf(((Integer)((Pair)pairs.get(0)).mSecond).intValue() - 
/* 402 */       ((Integer)((Pair)pairs.get(0)).mFirst).intValue()), 
/* 403 */       Integer.valueOf(((Integer)((Pair)pairs.get(index)).mSecond).intValue() - 
/* 403 */       ((Integer)((Pair)pairs.get(index)).mFirst).intValue()));
/*     */   }
/*     */ 
/*     */   private List<Rectangle> getRectangles(List<Pair<Integer>> leftPairs, List<Pair<Integer>> topPairs)
/*     */   {
/* 409 */     List rectangles = new ArrayList();
/*     */     Iterator localIterator2;
/* 410 */     for (Iterator localIterator1 = leftPairs.iterator(); localIterator1.hasNext(); 
/* 413 */       localIterator2.hasNext())
/*     */     {
/* 410 */       Pair left = (Pair)localIterator1.next();
/* 411 */       int y = ((Integer)left.mFirst).intValue();
/* 412 */       int height = ((Integer)left.mSecond).intValue() - ((Integer)left.mFirst).intValue();
/* 413 */       localIterator2 = topPairs.iterator(); continue; Pair top = (Pair)localIterator2.next();
/* 414 */       int x = ((Integer)top.mFirst).intValue();
/* 415 */       int width = ((Integer)top.mSecond).intValue() - ((Integer)top.mFirst).intValue();
/*     */ 
/* 417 */       rectangles.add(new Rectangle(x, y, width, height));
/*     */     }
/*     */ 
/* 420 */     return rectangles;
/*     */   }
/*     */ 
/*     */   private Pair<List<Pair<Integer>>> getPatches(int[] pixels, boolean[] startWithPatch)
/*     */   {
/* 442 */     int lastIndex = 0;
/* 443 */     int lastPixel = pixels[0];
/* 444 */     boolean first = true;
/*     */ 
/* 446 */     List fixed = new ArrayList();
/* 447 */     List patches = new ArrayList();
/*     */ 
/* 449 */     for (int i = 0; i < pixels.length; i++) {
/* 450 */       int pixel = pixels[i];
/* 451 */       if (pixel != lastPixel) {
/* 452 */         if (lastPixel == -16777216) {
/* 453 */           if (first)
/* 454 */             startWithPatch[0] = true;
/* 455 */           patches.add(new Pair(Integer.valueOf(lastIndex), Integer.valueOf(i)));
/*     */         } else {
/* 457 */           fixed.add(new Pair(Integer.valueOf(lastIndex), Integer.valueOf(i)));
/*     */         }
/* 459 */         first = false;
/*     */ 
/* 461 */         lastIndex = i;
/* 462 */         lastPixel = pixel;
/*     */       }
/*     */     }
/* 465 */     if (lastPixel == -16777216) {
/* 466 */       if (first)
/* 467 */         startWithPatch[0] = true;
/* 468 */       patches.add(new Pair(Integer.valueOf(lastIndex), Integer.valueOf(pixels.length)));
/*     */     } else {
/* 470 */       fixed.add(new Pair(Integer.valueOf(lastIndex), Integer.valueOf(pixels.length)));
/*     */     }
/*     */ 
/* 473 */     if (patches.size() == 0) {
/* 474 */       patches.add(new Pair(Integer.valueOf(1), Integer.valueOf(pixels.length)));
/* 475 */       startWithPatch[0] = true;
/* 476 */       fixed.clear();
/*     */     }
/*     */ 
/* 479 */     return new Pair(fixed, patches); } 
/*     */   static final class DrawingData { private int mRemainderHorizontal;
/*     */     private int mRemainderVertical;
/*     */     private float mHorizontalPatchesSum;
/*     */     private float mVerticalPatchesSum; }
/*     */ 
/*     */   static class Pair<E> implements Serializable { private static final long serialVersionUID = -2204108979541762418L;
/*     */     E mFirst;
/*     */     E mSecond;
/*     */ 
/* 494 */     Pair(E first, E second) { this.mFirst = first;
/* 495 */       this.mSecond = second;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 500 */       return "Pair[" + this.mFirst + ", " + this.mSecond + "]";
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.ninepatch4j.NinePatchChunk
 * JD-Core Version:    0.6.2
 */