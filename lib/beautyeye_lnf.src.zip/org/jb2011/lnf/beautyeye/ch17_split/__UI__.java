/*    */ package org.jb2011.lnf.beautyeye.ch17_split;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.plaf.BorderUIResource;
/*    */ import javax.swing.plaf.ColorUIResource;
/*    */ import org.jb2011.lnf.beautyeye.ch4_scroll.ScrollPaneBorder;
/*    */ 
/*    */ public class __UI__
/*    */ {
/*    */   public static void uiImpl()
/*    */   {
/* 31 */     UIManager.put("SplitPane.shadow", new ColorUIResource(new Color(200, 200, 200)));
/*    */ 
/* 33 */     UIManager.put("SplitPane.background", new ColorUIResource(new Color(250, 250, 250)));
/*    */ 
/* 35 */     UIManager.put("SplitPane.border", new BorderUIResource(new ScrollPaneBorder()));
/* 36 */     UIManager.put("SplitPaneUI", BESplitPaneUI.class.getName());
/*    */ 
/* 39 */     UIManager.put("SplitPaneDivider.draggingColor", new ColorUIResource(new Color(0, 0, 0, 50)));
/*    */ 
/* 41 */     UIManager.put("SplitPane.oneTouchButtonSize", Integer.valueOf(4));
/*    */ 
/* 43 */     UIManager.put("SplitPane.dividerSize", Integer.valueOf(7));
/*    */ 
/* 45 */     UIManager.put("SplitPaneDivider.border", new SplitPaneDividerBorder());
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch17_split.__UI__
 * JD-Core Version:    0.6.2
 */