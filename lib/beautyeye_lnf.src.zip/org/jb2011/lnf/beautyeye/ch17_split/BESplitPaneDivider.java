/*     */ package org.jb2011.lnf.beautyeye.ch17_split;
/*     */ 
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Stroke;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JSplitPane;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.basic.BasicSplitPaneDivider;
/*     */ import javax.swing.plaf.basic.BasicSplitPaneUI;
/*     */ import org.jb2011.lnf.beautyeye.utils.BEUtils;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ import sun.swing.DefaultLookup;
/*     */ 
/*     */ public class BESplitPaneDivider extends BasicSplitPaneDivider
/*     */ {
/*     */   private int oneTouchSize;
/*  50 */   protected final Color TOUCH_BUTTON_COLOR = new Color(58, 135, 173);
/*     */   protected static final int TOUCH_DECRATED_BUTTON_W = 5;
/*     */   protected static final int TOUCH_DECRATED_BUTTON_H = 30;
/*  62 */   protected static final Color TOUCH_DECRATED_BUTTON_COLOR = new Color(180, 180, 180);
/*     */ 
/*  65 */   protected static final Color TOUCH_DECRATED_BUTTON_HILIGHT_COLOR = Color.white;
/*     */ 
/*     */   public BESplitPaneDivider(BasicSplitPaneUI ui)
/*     */   {
/*  74 */     super(ui);
/*     */ 
/*  77 */     this.oneTouchSize = DefaultLookup.getInt(ui.getSplitPane(), ui, 
/*  78 */       "SplitPane.oneTouchButtonSize", 6);
/*     */   }
/*     */ 
/*     */   public void paint(Graphics g)
/*     */   {
/*  89 */     Color bgColor = this.splitPane.hasFocus() ? 
/*  90 */       UIManager.getColor("SplitPane.shadow") : getBackground();
/*  91 */     Dimension size = getSize();
/*  92 */     Graphics2D g2 = (Graphics2D)g;
/*  93 */     BEUtils.setAntiAliasing((Graphics2D)g, true);
/*     */ 
/*  96 */     if (bgColor != null)
/*     */     {
/*  98 */       int orient = this.splitPane.getOrientation();
/*  99 */       if (orient == 1)
/*     */       {
/* 101 */         int halfWidth = size.width / 2;
/* 102 */         int halfHeight = size.height / 2;
/*     */ 
/* 106 */         Stroke oldStroke = ((Graphics2D)g).getStroke();
/* 107 */         Stroke sroke = new BasicStroke(1.0F, 0, 
/* 108 */           2, 0.0F, new float[] { 2.0F, 2.0F }, 0.0F);
/* 109 */         ((Graphics2D)g).setStroke(sroke);
/*     */ 
/* 111 */         g.setColor(TOUCH_DECRATED_BUTTON_COLOR);
/*     */ 
/* 113 */         g.drawLine(halfWidth + 0, 0, halfWidth + 0, size.height);
/*     */ 
/* 115 */         g.setColor(TOUCH_DECRATED_BUTTON_HILIGHT_COLOR);
/* 116 */         g.drawLine(halfWidth + 1, 0, halfWidth + 1, size.height);
/*     */ 
/* 118 */         ((Graphics2D)g).setStroke(oldStroke);
/*     */ 
/* 121 */         int decratedButton_w = 5;
/* 122 */         int decratedButton_h = 30;
/* 123 */         int diverTouchStartX = halfWidth - decratedButton_w / 2;
/* 124 */         __Icon9Factory__.getInstance().getSplitTouchBg1()
/* 125 */           .draw((Graphics2D)g, diverTouchStartX, halfHeight - decratedButton_h / 2, 
/* 126 */           decratedButton_w, decratedButton_h);
/*     */       }
/*     */       else
/*     */       {
/* 130 */         int halfHeight = size.height / 2;
/* 131 */         int halfWidth = size.width / 2;
/*     */ 
/* 135 */         Stroke oldStroke = ((Graphics2D)g).getStroke();
/* 136 */         Stroke sroke = new BasicStroke(1.0F, 0, 
/* 137 */           2, 0.0F, new float[] { 2.0F, 2.0F }, 0.0F);
/* 138 */         ((Graphics2D)g).setStroke(sroke);
/*     */ 
/* 140 */         g.setColor(TOUCH_DECRATED_BUTTON_COLOR);
/*     */ 
/* 142 */         g.drawLine(0, halfHeight + 0, size.width, halfHeight + 0);
/*     */ 
/* 144 */         g.setColor(TOUCH_DECRATED_BUTTON_HILIGHT_COLOR);
/* 145 */         g.drawLine(0, halfHeight + 1, size.width, halfHeight + 1);
/*     */ 
/* 147 */         ((Graphics2D)g).setStroke(oldStroke);
/*     */ 
/* 150 */         int decratedButton_w = 5;
/* 151 */         int decratedButton_h = 30;
/* 152 */         int diverTouchStartY = halfHeight - decratedButton_w / 2;
/* 153 */         __Icon9Factory__.getInstance().getSplitTouchBg1()
/* 154 */           .draw((Graphics2D)g, halfWidth - decratedButton_h, diverTouchStartY, 
/* 155 */           decratedButton_h, decratedButton_w);
/*     */       }
/*     */ 
/* 159 */       BEUtils.setAntiAliasing((Graphics2D)g, false);
/*     */     }
/*     */ 
/* 162 */     super.paint(g);
/*     */   }
/*     */ 
/*     */   protected JButton createLeftOneTouchButton()
/*     */   {
/* 176 */     JButton b = new JButton()
/*     */     {
/*     */       public void setBorder(Border b)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void paint(Graphics g)
/*     */       {
/* 184 */         if (BESplitPaneDivider.this.splitPane != null)
/*     */         {
/* 186 */           int[] xs = new int[3];
/* 187 */           int[] ys = new int[3];
/*     */ 
/* 191 */           g.setColor(getBackground());
/* 192 */           g.fillRect(0, 0, getWidth(), getHeight());
/*     */ 
/* 196 */           g.setColor(BESplitPaneDivider.this.TOUCH_BUTTON_COLOR);
/*     */ 
/* 199 */           BEUtils.setAntiAliasing((Graphics2D)g, true);
/*     */ 
/* 201 */           if (BESplitPaneDivider.this.orientation == 0)
/*     */           {
/* 203 */             int blockSize = Math.min(getHeight(), BESplitPaneDivider.this.oneTouchSize);
/* 204 */             xs[0] = blockSize;
/* 205 */             xs[1] = 0;
/* 206 */             xs[2] = (blockSize << 1);
/* 207 */             ys[0] = 0;
/*     */             int tmp111_109 = blockSize; ys[2] = tmp111_109; ys[1] = tmp111_109;
/* 209 */             g.drawPolygon(xs, ys, 3);
/*     */           }
/*     */           else
/*     */           {
/* 214 */             int blockSize = Math.min(getWidth(), BESplitPaneDivider.this.oneTouchSize);
/*     */             int tmp146_144 = blockSize; xs[2] = tmp146_144; xs[0] = tmp146_144;
/* 216 */             xs[1] = 0;
/* 217 */             ys[0] = 0;
/* 218 */             ys[1] = blockSize;
/* 219 */             ys[2] = (blockSize << 1);
/*     */           }
/* 221 */           g.fillPolygon(xs, ys, 3);
/*     */ 
/* 224 */           BEUtils.setAntiAliasing((Graphics2D)g, false);
/*     */         }
/*     */       }
/*     */ 
/*     */       public boolean isFocusTraversable()
/*     */       {
/* 231 */         return false;
/*     */       }
/*     */     };
/* 234 */     b.setMinimumSize(new Dimension(this.oneTouchSize, this.oneTouchSize));
/* 235 */     b.setCursor(Cursor.getPredefinedCursor(0));
/* 236 */     b.setFocusPainted(false);
/* 237 */     b.setBorderPainted(false);
/* 238 */     b.setRequestFocusEnabled(false);
/* 239 */     return b;
/*     */   }
/*     */ 
/*     */   protected JButton createRightOneTouchButton()
/*     */   {
/* 252 */     JButton b = new JButton() {
/*     */       public void setBorder(Border border) {
/*     */       }
/*     */       public void paint(Graphics g) {
/* 256 */         if (BESplitPaneDivider.this.splitPane != null) {
/* 257 */           int[] xs = new int[3];
/* 258 */           int[] ys = new int[3];
/*     */ 
/* 262 */           g.setColor(getBackground());
/* 263 */           g.fillRect(0, 0, getWidth(), 
/* 264 */             getHeight());
/*     */ 
/* 267 */           BEUtils.setAntiAliasing((Graphics2D)g, true);
/*     */ 
/* 270 */           if (BESplitPaneDivider.this.orientation == 0) {
/* 271 */             int blockSize = Math.min(getHeight(), BESplitPaneDivider.this.oneTouchSize);
/* 272 */             xs[0] = blockSize;
/* 273 */             xs[1] = (blockSize << 1);
/* 274 */             xs[2] = 0;
/* 275 */             ys[0] = blockSize;
/*     */             int tmp100_99 = 0; ys[2] = tmp100_99; ys[1] = tmp100_99;
/*     */           }
/*     */           else {
/* 279 */             int blockSize = Math.min(getWidth(), BESplitPaneDivider.this.oneTouchSize);
/*     */             int tmp127_126 = 0; xs[2] = tmp127_126; xs[0] = tmp127_126;
/* 281 */             xs[1] = blockSize;
/* 282 */             ys[0] = 0;
/* 283 */             ys[1] = blockSize;
/* 284 */             ys[2] = (blockSize << 1);
/*     */           }
/*     */ 
/* 288 */           g.setColor(BESplitPaneDivider.this.TOUCH_BUTTON_COLOR);
/*     */ 
/* 290 */           g.fillPolygon(xs, ys, 3);
/*     */ 
/* 293 */           BEUtils.setAntiAliasing((Graphics2D)g, false);
/*     */         }
/*     */       }
/*     */ 
/*     */       public boolean isFocusTraversable() {
/* 298 */         return false;
/*     */       }
/*     */     };
/* 301 */     b.setMinimumSize(new Dimension(this.oneTouchSize, this.oneTouchSize));
/* 302 */     b.setCursor(Cursor.getPredefinedCursor(0));
/* 303 */     b.setFocusPainted(false);
/* 304 */     b.setBorderPainted(false);
/* 305 */     b.setRequestFocusEnabled(false);
/* 306 */     return b;
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch17_split.BESplitPaneDivider
 * JD-Core Version:    0.6.2
 */