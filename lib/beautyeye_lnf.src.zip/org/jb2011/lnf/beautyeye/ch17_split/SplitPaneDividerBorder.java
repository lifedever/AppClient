/*     */ package org.jb2011.lnf.beautyeye.ch17_split;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.JSplitPane;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.basic.BasicSplitPaneDivider;
/*     */ import javax.swing.plaf.basic.BasicSplitPaneUI;
/*     */ 
/*     */ public class SplitPaneDividerBorder
/*     */   implements Border, UIResource
/*     */ {
/*     */   public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/*     */   {
/*     */   }
/*     */ 
/*     */   public Insets getBorderInsets(Component c)
/*     */   {
/* 103 */     Insets insets = new Insets(0, 0, 0, 0);
/* 104 */     if ((c instanceof BasicSplitPaneDivider))
/*     */     {
/* 106 */       BasicSplitPaneUI bspui = ((BasicSplitPaneDivider)c)
/* 107 */         .getBasicSplitPaneUI();
/*     */ 
/* 109 */       if (bspui != null)
/*     */       {
/* 111 */         JSplitPane splitPane = bspui.getSplitPane();
/*     */ 
/* 113 */         if (splitPane != null)
/*     */         {
/* 115 */           if (splitPane.getOrientation() == 1)
/*     */           {
/* 117 */             insets.top = (insets.bottom = 0);
/* 118 */             insets.left = (insets.right = 1);
/* 119 */             return insets;
/*     */           }
/*     */ 
/* 122 */           insets.top = (insets.bottom = 1);
/* 123 */           insets.left = (insets.right = 0);
/* 124 */           return insets;
/*     */         }
/*     */       }
/*     */     }
/* 128 */     insets.top = (insets.bottom = insets.left = insets.right = 1);
/* 129 */     return insets;
/*     */   }
/*     */ 
/*     */   public boolean isBorderOpaque()
/*     */   {
/* 137 */     return true;
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch17_split.SplitPaneDividerBorder
 * JD-Core Version:    0.6.2
 */