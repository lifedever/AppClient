/*     */ package org.jb2011.lnf.beautyeye.ch3_button;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicToggleButtonUI;
/*     */ import org.jb2011.lnf.beautyeye.utils.BEUtils;
/*     */ import org.jb2011.lnf.beautyeye.utils.MySwingUtilities2;
/*     */ import sun.awt.AppContext;
/*     */ 
/*     */ public class BEToggleButtonUI extends BasicToggleButtonUI
/*     */ {
/*  44 */   private static final Object WINDOWS_TOGGLE_BUTTON_UI_KEY = new Object();
/*     */ 
/*  47 */   private BEButtonUI.NormalColor nomalColor = BEButtonUI.NormalColor.normal;
/*     */ 
/*     */   public static ComponentUI createUI(JComponent b)
/*     */   {
/*  56 */     AppContext appContext = AppContext.getAppContext();
/*  57 */     BEToggleButtonUI windowsToggleButtonUI = 
/*  58 */       (BEToggleButtonUI)appContext.get(WINDOWS_TOGGLE_BUTTON_UI_KEY);
/*  59 */     if (windowsToggleButtonUI == null) {
/*  60 */       windowsToggleButtonUI = new BEToggleButtonUI();
/*  61 */       appContext.put(WINDOWS_TOGGLE_BUTTON_UI_KEY, windowsToggleButtonUI);
/*     */     }
/*  63 */     return windowsToggleButtonUI;
/*     */   }
/*     */ 
/*     */   protected void installDefaults(AbstractButton b)
/*     */   {
/*  71 */     super.installDefaults(b);
/*  72 */     LookAndFeel.installProperty(b, "opaque", Boolean.FALSE);
/*     */   }
/*     */ 
/*     */   public void paint(Graphics g, JComponent c)
/*     */   {
/*  85 */     BEButtonUI.paintXPButtonBackground(this.nomalColor, g, c);
/*     */ 
/*  87 */     super.paint(g, c);
/*     */   }
/*     */ 
/*     */   protected void paintText(Graphics g, JComponent c, Rectangle textRect, String text)
/*     */   {
/* 102 */     AbstractButton b = (AbstractButton)c;
/* 103 */     ButtonModel model = b.getModel();
/* 104 */     FontMetrics fm = 
/* 105 */       MySwingUtilities2.getFontMetrics(c, g);
/* 106 */     int mnemonicIndex = b.getDisplayedMnemonicIndex();
/*     */ 
/* 109 */     if (model.isEnabled())
/*     */     {
/* 112 */       if (model.isSelected()) {
/* 113 */         g.setColor(UIManager.getColor(getPropertyPrefix() + "focus"));
/*     */       }
/*     */       else {
/* 116 */         g.setColor(b.getForeground());
/*     */       }
/*     */ 
/* 120 */       MySwingUtilities2.drawStringUnderlineCharAt(c, g, text, mnemonicIndex, 
/* 121 */         textRect.x + getTextShiftOffset(), 
/* 122 */         textRect.y + fm.getAscent() + getTextShiftOffset());
/*     */     }
/*     */     else
/*     */     {
/* 127 */       g.setColor(b.getBackground().brighter());
/*     */ 
/* 129 */       MySwingUtilities2.drawStringUnderlineCharAt(c, g, text, mnemonicIndex, 
/* 130 */         textRect.x, textRect.y + fm.getAscent());
/* 131 */       g.setColor(b.getBackground().darker());
/*     */ 
/* 133 */       MySwingUtilities2.drawStringUnderlineCharAt(c, g, text, mnemonicIndex, 
/* 134 */         textRect.x - 1, textRect.y + fm.getAscent() - 1);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void paintFocus(Graphics g, AbstractButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect)
/*     */   {
/* 146 */     Rectangle bound = b.getVisibleRect();
/*     */ 
/* 148 */     int delta = 3;
/* 149 */     int x = bound.x + 3; int y = bound.y + 3;
/* 150 */     int w = bound.width - 6; int h = bound.height - 6;
/*     */ 
/* 153 */     g.setColor(UIManager.getColor("ToggleButton.focusLine"));
/* 154 */     BEUtils.drawDashedRect(g, x, y, w, h, 17, 17, 2, 2);
/*     */ 
/* 156 */     g.setColor(UIManager.getColor("ToggleButton.focusLineHilight"));
/* 157 */     BEUtils.drawDashedRect(g, x + 1, y + 1, w, h, 17, 17, 2, 2);
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch3_button.BEToggleButtonUI
 * JD-Core Version:    0.6.2
 */