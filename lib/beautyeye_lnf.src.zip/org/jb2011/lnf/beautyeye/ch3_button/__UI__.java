/*    */ package org.jb2011.lnf.beautyeye.ch3_button;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.border.Border;
/*    */ import javax.swing.plaf.BorderUIResource;
/*    */ import javax.swing.plaf.ColorUIResource;
/*    */ import javax.swing.plaf.InsetsUIResource;
/*    */ import javax.swing.plaf.basic.BasicBorders.MarginBorder;
/*    */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*    */ 
/*    */ public class __UI__
/*    */ {
/*    */   public static void uiImpl()
/*    */   {
/* 38 */     UIManager.put("Button.background", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/*    */ 
/* 41 */     UIManager.put("Button.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/*    */ 
/* 44 */     UIManager.put("Button.dashedRectGapX", Integer.valueOf(3));
/* 45 */     UIManager.put("Button.dashedRectGapY", Integer.valueOf(3));
/* 46 */     UIManager.put("Button.dashedRectGapWidth", Integer.valueOf(6));
/* 47 */     UIManager.put("Button.dashedRectGapHeight", Integer.valueOf(6));
/*    */ 
/* 49 */     UIManager.put("ButtonUI", BEButtonUI.class.getName());
/* 50 */     UIManager.put("Button.margin", new InsetsUIResource(6, 8, 6, 8));
/*    */ 
/* 52 */     UIManager.put("Button.border", new BEButtonUI.XPEmptyBorder(
/* 53 */       new Insets(3, 3, 3, 3)));
/*    */ 
/* 55 */     UIManager.put("Button.focus", new ColorUIResource(130, 130, 130));
/*    */ 
/* 60 */     UIManager.put("ToggleButton.margin", new Insets(3, 11, 3, 11));
/* 61 */     UIManager.put("ToggleButton.background", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/* 62 */     UIManager.put("ToggleButton.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/*    */ 
/* 66 */     UIManager.put("ToggleButton.focus", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/* 67 */     UIManager.put("ToggleButtonUI", BEToggleButtonUI.class.getName());
/*    */ 
/* 69 */     Border toggleButtonBorder = new BorderUIResource(new BasicBorders.MarginBorder());
/*    */ 
/* 71 */     UIManager.put("ToggleButton.border", toggleButtonBorder);
/*    */ 
/* 73 */     UIManager.put("ToggleButton.focusLine", 
/* 74 */       new ColorUIResource(BeautyEyeLNFHelper.commonFocusedBorderColor.darker()));
/*    */ 
/* 76 */     UIManager.put("ToggleButton.focusLineHilight", new ColorUIResource(new Color(240, 240, 240)));
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch3_button.__UI__
 * JD-Core Version:    0.6.2
 */