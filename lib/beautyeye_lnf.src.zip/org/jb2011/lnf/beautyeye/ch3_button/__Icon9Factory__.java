/*     */ package org.jb2011.lnf.beautyeye.ch3_button;
/*     */ 
/*     */ import org.jb2011.lnf.beautyeye.utils.NinePatchHelper;
/*     */ import org.jb2011.lnf.beautyeye.utils.RawCache;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class __Icon9Factory__ extends RawCache<NinePatch>
/*     */ {
/*     */   public static final String IMGS_ROOT = "imgs/np";
/*  30 */   private static __Icon9Factory__ instance = null;
/*     */ 
/*     */   public static __Icon9Factory__ getInstance()
/*     */   {
/*  39 */     if (instance == null)
/*  40 */       instance = new __Icon9Factory__();
/*  41 */     return instance;
/*     */   }
/*     */ 
/*     */   protected NinePatch getResource(String relativePath, Class baseClass)
/*     */   {
/*  50 */     return NinePatchHelper.createNinePatch(baseClass.getResource(relativePath), false);
/*     */   }
/*     */ 
/*     */   public NinePatch getRaw(String relativePath)
/*     */   {
/*  61 */     return (NinePatch)getRaw(relativePath, getClass());
/*     */   }
/*     */ 
/*     */   public NinePatch getButtonIcon_NormalGreen()
/*     */   {
/*  72 */     return getRaw("imgs/np/btn_special_default.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getButtonIcon_NormalGray()
/*     */   {
/*  82 */     return getRaw("imgs/np/btn_general_default.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getButtonIcon_DisableGray()
/*     */   {
/*  92 */     return getRaw("imgs/np/btn_special_disabled.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getButtonIcon_PressedOrange()
/*     */   {
/* 102 */     return getRaw("imgs/np/btn_general_pressed.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getButtonIcon_rover()
/*     */   {
/* 112 */     return getRaw("imgs/np/btn_general_rover.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getButtonIcon_NormalLightBlue()
/*     */   {
/* 122 */     return getRaw("imgs/np/btn_special_lightblue.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getButtonIcon_NormalRed()
/*     */   {
/* 132 */     return getRaw("imgs/np/btn_special_red.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getButtonIcon_NormalBlue()
/*     */   {
/* 142 */     return getRaw("imgs/np/btn_special_blue.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getToggleButtonIcon_CheckedGreen()
/*     */   {
/* 152 */     return getRaw("imgs/np/toggle_button_selected.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getToggleButtonIcon_RoverGreen()
/*     */   {
/* 162 */     return getRaw("imgs/np/toggle_button_rover.9.png");
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch3_button.__Icon9Factory__
 * JD-Core Version:    0.6.2
 */