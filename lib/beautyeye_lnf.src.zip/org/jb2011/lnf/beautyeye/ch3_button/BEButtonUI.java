/*     */ package org.jb2011.lnf.beautyeye.ch3_button;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JToggleButton;
/*     */ import javax.swing.JToolBar;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.border.CompoundBorder;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.InsetsUIResource;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.basic.BasicButtonUI;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import org.jb2011.lnf.beautyeye.utils.BEUtils;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class BEButtonUI extends BasicButtonUI
/*     */ {
/*  53 */   private static final BEButtonUI xWindowsButtonUI = new BEButtonUI();
/*     */ 
/*  56 */   private NormalColor nomalColor = NormalColor.normal;
/*     */   protected int dashedRectGapX;
/*     */   protected int dashedRectGapY;
/*     */   protected int dashedRectGapWidth;
/*     */   protected int dashedRectGapHeight;
/*     */   protected Color focusColor;
/* 108 */   private boolean defaults_initialized = false;
/*     */ 
/*     */   public BEButtonUI setNormalColor(NormalColor nc)
/*     */   {
/*  88 */     this.nomalColor = nc;
/*  89 */     return this;
/*     */   }
/*     */ 
/*     */   public static ComponentUI createUI(JComponent c)
/*     */   {
/* 121 */     return xWindowsButtonUI;
/*     */   }
/*     */ 
/*     */   protected void installDefaults(AbstractButton b)
/*     */   {
/* 132 */     super.installDefaults(b);
/* 133 */     b.setOpaque(false);
/*     */ 
/* 135 */     if (!this.defaults_initialized) {
/* 136 */       String pp = getPropertyPrefix();
/* 137 */       this.dashedRectGapX = UIManager.getInt(pp + "dashedRectGapX");
/* 138 */       this.dashedRectGapY = UIManager.getInt(pp + "dashedRectGapY");
/* 139 */       this.dashedRectGapWidth = UIManager.getInt(pp + "dashedRectGapWidth");
/* 140 */       this.dashedRectGapHeight = UIManager.getInt(pp + "dashedRectGapHeight");
/* 141 */       this.focusColor = UIManager.getColor(pp + "focus");
/* 142 */       this.defaults_initialized = true;
/*     */     }
/*     */ 
/* 148 */     b.setBorder(new XPEmptyBorder(new Insets(3, 3, 3, 3)));
/* 149 */     LookAndFeel.installProperty(b, "rolloverEnabled", Boolean.TRUE);
/*     */   }
/*     */ 
/*     */   protected void uninstallDefaults(AbstractButton b)
/*     */   {
/* 157 */     super.uninstallDefaults(b);
/* 158 */     this.defaults_initialized = false;
/*     */   }
/*     */ 
/*     */   protected Color getFocusColor()
/*     */   {
/* 167 */     return this.focusColor;
/*     */   }
/*     */ 
/*     */   protected void paintFocus(Graphics g, AbstractButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect)
/*     */   {
/* 198 */     int width = b.getWidth();
/* 199 */     int height = b.getHeight();
/* 200 */     g.setColor(getFocusColor());
/*     */ 
/* 206 */     BEUtils.drawDashedRect(g, this.dashedRectGapX, this.dashedRectGapY, 
/* 207 */       width - this.dashedRectGapWidth, height - this.dashedRectGapHeight);
/*     */ 
/* 209 */     g.setColor(new Color(255, 255, 255, 50));
/*     */ 
/* 211 */     BEUtils.drawDashedRect(g, this.dashedRectGapX + 1, this.dashedRectGapY + 1, 
/* 212 */       width - this.dashedRectGapWidth, height - this.dashedRectGapHeight);
/*     */   }
/*     */ 
/*     */   public Dimension getPreferredSize(JComponent c)
/*     */   {
/* 227 */     Dimension d = super.getPreferredSize(c);
/*     */ 
/* 232 */     AbstractButton b = (AbstractButton)c;
/* 233 */     if ((d != null) && (b.isFocusPainted())) {
/* 234 */       if (d.width % 2 == 0) d.width += 1;
/* 235 */       if (d.height % 2 == 0) d.height += 1;
/*     */     }
/* 237 */     return d;
/*     */   }
/*     */ 
/*     */   public void paint(Graphics g, JComponent c)
/*     */   {
/* 254 */     paintXPButtonBackground(this.nomalColor, g, c);
/*     */ 
/* 256 */     super.paint(g, c);
/*     */   }
/*     */ 
/*     */   public static void paintXPButtonBackground(NormalColor nomalColor, Graphics g, JComponent c)
/*     */   {
/* 273 */     AbstractButton b = (AbstractButton)c;
/*     */ 
/* 277 */     boolean toolbar = b.getParent() instanceof JToolBar;
/*     */ 
/* 280 */     if (b.isContentAreaFilled())
/*     */     {
/* 282 */       ButtonModel model = b.getModel();
/*     */ 
/* 334 */       Dimension d = c.getSize();
/* 335 */       int dx = 0;
/* 336 */       int dy = 0;
/* 337 */       int dw = d.width;
/* 338 */       int dh = d.height;
/*     */ 
/* 340 */       Border border = c.getBorder();
/*     */       Insets insets;
/*     */       Insets insets;
/* 342 */       if (border != null)
/*     */       {
/* 349 */         insets = getOpaqueInsets(border, c);
/*     */       }
/*     */       else
/*     */       {
/* 353 */         insets = c.getInsets();
/*     */       }
/* 355 */       if (insets != null)
/*     */       {
/* 357 */         dx += insets.left;
/* 358 */         dy += insets.top;
/* 359 */         dw -= insets.left + insets.right;
/* 360 */         dh -= insets.top + insets.bottom;
/*     */       }
/*     */ 
/* 364 */       if (toolbar)
/*     */       {
/* 367 */         if ((model.isRollover()) || (model.isPressed()))
/*     */         {
/* 369 */           if ((c instanceof JToggleButton))
/* 370 */             __Icon9Factory__.getInstance().getToggleButtonIcon_RoverGreen().draw((Graphics2D)g, dx, dy, dw, dh);
/*     */           else
/* 372 */             __Icon9Factory__.getInstance().getButtonIcon_PressedOrange().draw((Graphics2D)g, dx, dy, dw, dh);
/*     */         }
/* 374 */         else if (model.isSelected())
/*     */         {
/* 376 */           __Icon9Factory__.getInstance().getToggleButtonIcon_CheckedGreen().draw((Graphics2D)g, dx, dy, dw, dh);
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */         try
/*     */         {
/* 391 */           if (((model.isArmed()) && (model.isPressed())) || (model.isSelected())) {
/* 392 */             __Icon9Factory__.getInstance().getButtonIcon_PressedOrange().draw((Graphics2D)g, dx, dy, dw, dh);
/*     */           }
/* 394 */           else if (!model.isEnabled())
/* 395 */             __Icon9Factory__.getInstance().getButtonIcon_DisableGray().draw((Graphics2D)g, dx, dy, dw, dh);
/* 396 */           else if (model.isRollover()) {
/* 397 */             __Icon9Factory__.getInstance().getButtonIcon_rover().draw((Graphics2D)g, dx, dy, dw, dh);
/*     */           }
/* 400 */           else if (nomalColor == NormalColor.green)
/*     */           {
/* 402 */             __Icon9Factory__.getInstance().getButtonIcon_NormalGreen().draw((Graphics2D)g, dx, dy, dw, dh);
/*     */           }
/* 404 */           else if (nomalColor == NormalColor.red)
/*     */           {
/* 406 */             __Icon9Factory__.getInstance().getButtonIcon_NormalRed().draw((Graphics2D)g, dx, dy, dw, dh);
/*     */           }
/* 408 */           else if (nomalColor == NormalColor.blue)
/*     */           {
/* 410 */             __Icon9Factory__.getInstance().getButtonIcon_NormalBlue().draw((Graphics2D)g, dx, dy, dw, dh);
/*     */           }
/* 412 */           else if (nomalColor == NormalColor.lightBlue)
/*     */           {
/* 414 */             __Icon9Factory__.getInstance().getButtonIcon_NormalLightBlue().draw((Graphics2D)g, dx, dy, dw, dh);
/*     */           }
/*     */           else
/*     */           {
/* 425 */             __Icon9Factory__.getInstance().getButtonIcon_NormalGray().draw((Graphics2D)g, dx, dy, dw, dh);
/*     */           }
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 430 */           e.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static Insets getOpaqueInsets(Border b, Component c)
/*     */   {
/* 448 */     if (b == null) {
/* 449 */       return null;
/*     */     }
/* 451 */     if (b.isBorderOpaque())
/* 452 */       return b.getBorderInsets(c);
/* 453 */     if ((b instanceof CompoundBorder)) {
/* 454 */       CompoundBorder cb = (CompoundBorder)b;
/* 455 */       Insets iOut = getOpaqueInsets(cb.getOutsideBorder(), c);
/* 456 */       if ((iOut != null) && (iOut.equals(cb.getOutsideBorder().getBorderInsets(c))))
/*     */       {
/* 458 */         Insets iIn = getOpaqueInsets(cb.getInsideBorder(), c);
/* 459 */         if (iIn == null)
/*     */         {
/* 461 */           return iOut;
/*     */         }
/*     */ 
/* 465 */         return new Insets(iOut.top + iIn.top, iOut.left + iIn.left, 
/* 466 */           iOut.bottom + iIn.bottom, iOut.right + iIn.right);
/*     */       }
/*     */ 
/* 471 */       return iOut;
/*     */     }
/*     */ 
/* 474 */     return null;
/*     */   }
/*     */ 
/*     */   public static enum NormalColor
/*     */   {
/*  65 */     normal, 
/*     */ 
/*  68 */     green, 
/*     */ 
/*  71 */     red, 
/*     */ 
/*  74 */     lightBlue, 
/*     */ 
/*  77 */     blue;
/*     */   }
/*     */ 
/*     */   public static class XPEmptyBorder extends EmptyBorder
/*     */     implements UIResource
/*     */   {
/*     */     public XPEmptyBorder(Insets m)
/*     */     {
/* 491 */       super(m.left + 2, m.bottom + 2, m.right + 2);
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c)
/*     */     {
/* 498 */       return getBorderInsets(c, getBorderInsets());
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c, Insets insets)
/*     */     {
/* 505 */       insets = super.getBorderInsets(c, insets);
/*     */ 
/* 507 */       Insets margin = null;
/* 508 */       if ((c instanceof AbstractButton)) {
/* 509 */         Insets m = ((AbstractButton)c).getMargin();
/*     */ 
/* 512 */         if (((c.getParent() instanceof JToolBar)) && 
/* 513 */           (!(c instanceof JRadioButton)) && 
/* 514 */           (!(c instanceof JCheckBox)) && 
/* 515 */           ((m instanceof InsetsUIResource))) {
/* 516 */           insets.top -= 2;
/* 517 */           insets.left -= 2;
/* 518 */           insets.bottom -= 2;
/* 519 */           insets.right -= 2;
/*     */         } else {
/* 521 */           margin = m;
/*     */         }
/* 523 */       } else if ((c instanceof JToolBar)) {
/* 524 */         margin = ((JToolBar)c).getMargin();
/* 525 */       } else if ((c instanceof JTextComponent)) {
/* 526 */         margin = ((JTextComponent)c).getMargin();
/*     */       }
/* 528 */       if (margin != null) {
/* 529 */         margin.top += 2;
/* 530 */         margin.left += 2;
/* 531 */         margin.bottom += 2;
/* 532 */         margin.right += 2;
/*     */       }
/* 534 */       return insets;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI
 * JD-Core Version:    0.6.2
 */