/*     */ package org.jb2011.lnf.beautyeye.ch2_tab;
/*     */ 
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Stroke;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicTabbedPaneUI;
/*     */ import org.jb2011.lnf.beautyeye.utils.BEUtils;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class BETabbedPaneUI extends BasicTabbedPaneUI
/*     */ {
/*     */   public static ComponentUI createUI(JComponent c)
/*     */   {
/*  46 */     return new BETabbedPaneUI();
/*     */   }
/*     */ 
/*     */   protected void setRolloverTab(int index)
/*     */   {
/*  60 */     int oldRolloverTab = getRolloverTab();
/*  61 */     super.setRolloverTab(index);
/*  62 */     Rectangle r1 = null;
/*  63 */     Rectangle r2 = null;
/*  64 */     if ((oldRolloverTab >= 0) && (oldRolloverTab < this.tabPane.getTabCount())) {
/*  65 */       r1 = getTabBounds(this.tabPane, oldRolloverTab);
/*     */     }
/*  67 */     if (index >= 0) {
/*  68 */       r2 = getTabBounds(this.tabPane, index);
/*     */     }
/*  70 */     if (r1 != null) {
/*  71 */       if (r2 != null)
/*  72 */         this.tabPane.repaint(r1.union(r2));
/*     */       else
/*  74 */         this.tabPane.repaint(r1);
/*     */     }
/*  76 */     else if (r2 != null)
/*  77 */       this.tabPane.repaint(r2);
/*     */   }
/*     */ 
/*     */   protected void paintTabBorder(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/*     */   {
/* 102 */     Graphics2D g2d = (Graphics2D)g.create();
/* 103 */     g2d.translate(x, y);
/*     */ 
/* 107 */     boolean isRover = getRolloverTab() == tabIndex;
/*     */ 
/* 109 */     boolean isEnableAt = this.tabPane.isEnabledAt(tabIndex);
/*     */ 
/* 111 */     switch (tabPlacement)
/*     */     {
/*     */     case 2:
/* 114 */       g2d.scale(-1.0D, 1.0D);
/* 115 */       g2d.rotate(Math.toRadians(90.0D));
/* 116 */       paintTabBorderImpl(g2d, isEnableAt, isSelected, isRover, 0, 0, h, w);
/* 117 */       break;
/*     */     case 4:
/* 119 */       g2d.translate(w, 0);
/* 120 */       g2d.rotate(Math.toRadians(90.0D));
/* 121 */       paintTabBorderImpl(g2d, isEnableAt, isSelected, isRover, 0, 0, h, w);
/* 122 */       break;
/*     */     case 3:
/* 124 */       g2d.translate(0, h);
/* 125 */       g2d.scale(-1.0D, 1.0D);
/* 126 */       g2d.rotate(Math.toRadians(180.0D));
/* 127 */       paintTabBorderImpl(g2d, isEnableAt, isSelected, isRover, 0, 0, w, h);
/* 128 */       break;
/*     */     case 1:
/*     */     default:
/* 131 */       paintTabBorderImpl(g2d, isEnableAt, isSelected, isRover, 0, 0, w, h);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void paintTabBorderImpl(Graphics2D g2d, boolean isEnableAt, boolean isSelected, boolean isRover, int x, int y, int w, int h)
/*     */   {
/* 152 */     if (isSelected) {
/* 153 */       __Icon9Factory__.getInstance().getTabbedPaneBgSelected().draw(g2d, x, y + 1, w, h);
/*     */     }
/* 156 */     else if ((isEnableAt) && (isRover))
/* 157 */       __Icon9Factory__.getInstance().getTabbedPaneBgNormal_rover().draw(g2d, x, y + 1, w, h);
/*     */     else
/* 159 */       __Icon9Factory__.getInstance().getTabbedPaneBgNormal().draw(g2d, x, y + 1, w, h);
/*     */   }
/*     */ 
/*     */   protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex)
/*     */   {
/* 172 */     Stroke oldStroke = ((Graphics2D)g).getStroke();
/* 173 */     Stroke sroke = new BasicStroke(1.0F, 0, 
/* 174 */       2, 0.0F, new float[] { 2.0F, 2.0F }, 0.0F);
/* 175 */     ((Graphics2D)g).setStroke(sroke);
/*     */ 
/* 179 */     super.paintContentBorder(g, tabPlacement, selectedIndex);
/*     */ 
/* 182 */     ((Graphics2D)g).setStroke(oldStroke);
/*     */   }
/*     */ 
/*     */   protected void paintContentBorderTopEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h)
/*     */   {
/* 196 */     if (tabPlacement == 1)
/*     */     {
/* 198 */       super.paintContentBorderTopEdge(g, tabPlacement, selectedIndex, x, y, w, h);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void paintContentBorderLeftEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h)
/*     */   {
/* 210 */     if (tabPlacement == 2)
/*     */     {
/* 212 */       super.paintContentBorderLeftEdge(g, tabPlacement, selectedIndex, x, y, w, h);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void paintContentBorderBottomEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h)
/*     */   {
/* 224 */     if (tabPlacement == 3)
/*     */     {
/* 226 */       super.paintContentBorderBottomEdge(g, tabPlacement, selectedIndex, x, y, w, h);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void paintContentBorderRightEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h)
/*     */   {
/* 238 */     if (tabPlacement == 4)
/*     */     {
/* 240 */       super.paintContentBorderRightEdge(g, tabPlacement, selectedIndex, x, y, w, h);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void paintFocusIndicator(Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected)
/*     */   {
/* 254 */     Rectangle tabRect = rects[tabIndex];
/* 255 */     if ((this.tabPane.hasFocus()) && (isSelected))
/*     */     {
/* 258 */       g.setColor(this.focus);
/*     */       int h;
/*     */       int h;
/*     */       int h;
/*     */       int x;
/*     */       int y;
/*     */       int w;
/*     */       int h;
/* 259 */       switch (tabPlacement) {
/*     */       case 2:
/* 261 */         int x = tabRect.x + 4;
/* 262 */         int y = tabRect.y + 6;
/* 263 */         int w = tabRect.width - 7;
/* 264 */         h = tabRect.height - 12;
/* 265 */         break;
/*     */       case 4:
/* 267 */         int x = tabRect.x + 4;
/* 268 */         int y = tabRect.y + 6;
/* 269 */         int w = tabRect.width - 9;
/* 270 */         h = tabRect.height - 12;
/* 271 */         break;
/*     */       case 3:
/* 273 */         int x = tabRect.x + 6;
/* 274 */         int y = tabRect.y + 4;
/* 275 */         int w = tabRect.width - 12;
/* 276 */         h = tabRect.height - 9;
/* 277 */         break;
/*     */       case 1:
/*     */       default:
/* 281 */         x = tabRect.x + 6;
/*     */ 
/* 283 */         y = tabRect.y + 4;
/*     */ 
/* 285 */         w = tabRect.width - 12;
/*     */ 
/* 287 */         h = tabRect.height - 8;
/*     */       }
/*     */ 
/* 292 */       BEUtils.drawDashedRect(g, x, y, w, h);
/*     */ 
/* 294 */       g.setColor(new Color(255, 255, 255, 255));
/*     */ 
/* 296 */       BEUtils.drawDashedRect(g, x + 1, y + 1, w, h);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected int getTabLabelShiftY(int tabPlacement, int tabIndex, boolean isSelected)
/*     */   {
/* 307 */     Rectangle tabRect = this.rects[tabIndex];
/* 308 */     int nudge = 0;
/* 309 */     switch (tabPlacement) {
/*     */     case 3:
/* 311 */       nudge = isSelected ? 1 : -1;
/* 312 */       break;
/*     */     case 2:
/*     */     case 4:
/* 315 */       nudge = tabRect.height % 2;
/* 316 */       break;
/*     */     case 1:
/*     */     default:
/* 323 */       nudge = -2;
/*     */     }
/* 325 */     return nudge;
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch2_tab.BETabbedPaneUI
 * JD-Core Version:    0.6.2
 */