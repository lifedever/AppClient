/*    */ package org.jb2011.lnf.beautyeye.ch2_tab;
/*    */ 
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.plaf.ColorUIResource;
/*    */ import javax.swing.plaf.InsetsUIResource;
/*    */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*    */ 
/*    */ public class __UI__
/*    */ {
/*    */   public static void uiImpl()
/*    */   {
/* 30 */     UIManager.put("TabbedPane.background", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/* 31 */     UIManager.put("TabbedPane.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/*    */ 
/* 34 */     UIManager.put("TabbedPane.tabsOverlapBorder", Boolean.valueOf(true));
/* 35 */     UIManager.put("TabbedPaneUI", BETabbedPaneUI.class.getName());
/*    */ 
/* 37 */     UIManager.put("TabbedPane.tabAreaInsets", 
/* 38 */       new InsetsUIResource(3, 20, 2, 20));
/*    */ 
/* 40 */     UIManager.put("TabbedPane.contentBorderInsets", 
/* 41 */       new InsetsUIResource(2, 0, 3, 0));
/*    */ 
/* 43 */     UIManager.put("TabbedPane.selectedTabPadInsets", 
/* 44 */       new InsetsUIResource(0, 1, 0, 2));
/*    */ 
/* 46 */     UIManager.put("TabbedPane.tabInsets", new InsetsUIResource(7, 15, 9, 15));
/*    */ 
/* 48 */     UIManager.put("TabbedPane.focus", new ColorUIResource(130, 130, 130));
/* 49 */     ColorUIResource highlight = new ColorUIResource(BeautyEyeLNFHelper.commonFocusedBorderColor);
/*    */ 
/* 51 */     UIManager.put("TabbedPane.highlight", highlight);
/*    */ 
/* 53 */     UIManager.put("TabbedPane.shadow", highlight);
/*    */ 
/* 56 */     UIManager.put("TabbedPane.darkShadow", 
/* 57 */       new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch2_tab.__UI__
 * JD-Core Version:    0.6.2
 */