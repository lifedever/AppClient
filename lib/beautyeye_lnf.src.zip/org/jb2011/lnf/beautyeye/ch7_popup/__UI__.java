/*    */ package org.jb2011.lnf.beautyeye.ch7_popup;
/*    */ 
/*    */ import javax.swing.PopupFactory;
/*    */ 
/*    */ public class __UI__
/*    */ {
/* 23 */   public static PopupFactory popupFactoryDIY = new TranslucentPopupFactory();
/*    */ 
/*    */   public static void uiImpl()
/*    */   {
/* 30 */     PopupFactory.setSharedInstance(popupFactoryDIY);
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch7_popup.__UI__
 * JD-Core Version:    0.6.2
 */