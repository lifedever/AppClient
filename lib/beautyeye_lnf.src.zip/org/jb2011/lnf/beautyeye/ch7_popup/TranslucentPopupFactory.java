/*     */ package org.jb2011.lnf.beautyeye.ch7_popup;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.GraphicsEnvironment;
/*     */ import java.awt.Window;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JToolTip;
/*     */ import javax.swing.JWindow;
/*     */ import javax.swing.MenuElement;
/*     */ import javax.swing.Popup;
/*     */ import javax.swing.PopupFactory;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.plaf.basic.BasicComboPopup;
/*     */ import org.jb2011.lnf.beautyeye.utils.WindowTranslucencyHelper;
/*     */ import org.jb2011.lnf.beautyeye.widget.ImageBgPanel;
/*     */ 
/*     */ public class TranslucentPopupFactory extends PopupFactory
/*     */ {
/*     */   public Popup getPopup(Component owner, Component contents, int x, int y)
/*     */     throws IllegalArgumentException
/*     */   {
/*  55 */     return new TranslucentPopup(owner, contents, x, y);
/*     */   }
/*     */ 
/*     */   protected class TranslucentPopup extends Popup
/*     */   {
/*     */     private Component component;
/*     */ 
/*     */     public TranslucentPopup(Component owner, Component contents, int x, int y)
/*     */     {
/*  96 */       this();
/*  97 */       if (contents == null)
/*     */       {
/*  99 */         throw new IllegalArgumentException("Contents must be non-null");
/*     */       }
/*     */ 
/* 102 */       reset(owner, contents, x, y);
/*     */     }
/*     */ 
/*     */     public TranslucentPopup()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void show()
/*     */     {
/* 123 */       Component component = getComponent();
/*     */ 
/* 125 */       if (component != null)
/*     */       {
/* 127 */         component.setVisible(true);
/*     */ 
/* 132 */         component.repaint();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void hide()
/*     */     {
/* 147 */       Component component = getComponent();
/*     */ 
/* 149 */       if ((component instanceof JWindow))
/*     */       {
/* 151 */         component.hide();
/* 152 */         ((JWindow)component).getContentPane().removeAll();
/*     */       }
/* 154 */       dispose();
/*     */     }
/*     */ 
/*     */     protected void dispose()
/*     */     {
/* 163 */       Component component = getComponent();
/* 164 */       Window window = SwingUtilities.getWindowAncestor(component);
/*     */ 
/* 166 */       if ((component instanceof JWindow))
/*     */       {
/* 168 */         ((Window)component).dispose();
/* 169 */         component = null;
/*     */       }
/*     */ 
/* 172 */       if ((window instanceof DefaultFrame))
/*     */       {
/* 174 */         window.dispose();
/*     */       }
/*     */     }
/*     */ 
/*     */     protected void reset(Component owner, Component contents, int ownerX, int ownerY)
/*     */     {
/* 192 */       if (getComponent() == null)
/*     */       {
/* 194 */         this.component = createComponent(owner);
/*     */       }
/*     */ 
/* 197 */       Component c = getComponent();
/* 198 */       if ((c instanceof JWindow))
/*     */       {
/* 200 */         JWindow component = (JWindow)getComponent();
/* 201 */         component.setLocation(ownerX, ownerY);
/*     */ 
/* 203 */         boolean isTooltip = (JComponent)contents instanceof JToolTip;
/*     */ 
/* 205 */         boolean isComboBoxPopup = contents instanceof BasicComboPopup;
/*     */ 
/* 209 */         WindowTranslucencyHelper.setWindowOpaque(component, false);
/*     */ 
/* 213 */         WindowTranslucencyHelper.setOpacity(component, 
/* 214 */           isComboBoxPopup ? 0.95F : isTooltip ? 1.0F : 0.95F);
/*     */ 
/* 226 */         ImageBgPanel imageContentPane = new ImageBgPanel().setN9(
/* 229 */           isComboBoxPopup ? 
/* 230 */           org.jb2011.lnf.beautyeye.ch4_scroll.__Icon9Factory__.getInstance().getScrollPaneBorderBg() : isTooltip ? 
/* 228 */           __Icon9Factory__.getInstance().getTooltipBg() : 
/* 231 */           __Icon9Factory__.getInstance().getPopupBg());
/*     */ 
/* 233 */         imageContentPane.setLayout(new BorderLayout());
/* 234 */         imageContentPane.add(contents, "Center");
/*     */ 
/* 238 */         if ((contents instanceof JComponent))
/*     */         {
/* 240 */           ((JComponent)contents).setOpaque(false);
/*     */ 
/* 260 */           ((JComponent)contents).setDoubleBuffered(false);
/*     */ 
/* 263 */           ((JComponent)contents).setBorder(
/* 266 */             isComboBoxPopup ? BorderFactory.createEmptyBorder(6, 4, 6, 4) : isTooltip ? 
/* 265 */             BorderFactory.createEmptyBorder(6, 8, 12, 12) : 
/* 267 */             BorderFactory.createEmptyBorder(5, 3, 6, 3));
/*     */         }
/*     */ 
/* 276 */         if (isComboBoxPopup)
/*     */         {
/* 278 */           Component[] cs = ((BasicComboPopup)contents).getComponents();
/*     */ 
/* 280 */           if ((cs != null) && (cs.length > 0))
/*     */           {
/* 283 */             for (Component com : cs)
/*     */             {
/* 285 */               if ((com instanceof JScrollPane)) {
/* 286 */                 ((JScrollPane)com).setOpaque(false);
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/*     */         }
/* 292 */         else if ((contents instanceof JPopupMenu))
/*     */         {
/* 294 */           MenuElement[] mes = ((JPopupMenu)contents).getSubElements();
/* 295 */           for (int i = 0; i < mes.length; i++)
/*     */           {
/* 297 */             if ((mes[i] instanceof JMenuItem)) {
/* 298 */               ((JMenuItem)mes[i]).setOpaque(false);
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 303 */         component.setContentPane(imageContentPane);
/*     */ 
/* 306 */         if (component.isVisible())
/*     */         {
/* 310 */           pack();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     protected void pack()
/*     */     {
/* 322 */       Component component = getComponent();
/*     */ 
/* 324 */       if ((component instanceof Window))
/*     */       {
/* 326 */         ((Window)component).pack();
/*     */       }
/*     */     }
/*     */ 
/*     */     protected Window getParentWindow(Component owner)
/*     */     {
/* 341 */       Window window = null;
/*     */ 
/* 343 */       if ((owner instanceof Window))
/*     */       {
/* 345 */         window = (Window)owner;
/*     */       }
/* 347 */       else if (owner != null)
/*     */       {
/* 349 */         window = SwingUtilities.getWindowAncestor(owner);
/*     */       }
/* 351 */       if (window == null)
/*     */       {
/* 353 */         window = new DefaultFrame();
/*     */       }
/* 355 */       return window;
/*     */     }
/*     */ 
/*     */     protected Component createComponent(Component owner)
/*     */     {
/* 369 */       if (GraphicsEnvironment.isHeadless())
/*     */       {
/* 372 */         return null;
/*     */       }
/*     */ 
/* 375 */       return new HeavyWeightWindow(getParentWindow(owner));
/*     */     }
/*     */ 
/*     */     protected Component getComponent()
/*     */     {
/* 387 */       return this.component;
/*     */     }
/*     */ 
/*     */     protected class DefaultFrame extends Frame
/*     */     {
/*     */       protected DefaultFrame()
/*     */       {
/*     */       }
/*     */     }
/*     */ 
/*     */     protected class HeavyWeightWindow extends JWindow
/*     */     {
/*     */       public HeavyWeightWindow(Window parent)
/*     */       {
/* 414 */         super();
/* 415 */         setFocusableWindowState(false);
/* 416 */         setName("###overrideRedirect###");
/*     */         try
/*     */         {
/* 425 */           setAlwaysOnTop(true);
/*     */         }
/*     */         catch (SecurityException localSecurityException)
/*     */         {
/*     */         }
/*     */       }
/*     */ 
/*     */       public void update(Graphics g)
/*     */       {
/* 439 */         paint(g);
/*     */       }
/*     */ 
/*     */       public void show()
/*     */       {
/* 447 */         pack();
/* 448 */         super.show();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch7_popup.TranslucentPopupFactory
 * JD-Core Version:    0.6.2
 */