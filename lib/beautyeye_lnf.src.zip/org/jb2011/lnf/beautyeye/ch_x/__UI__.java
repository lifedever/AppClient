/*    */ package org.jb2011.lnf.beautyeye.ch_x;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.plaf.BorderUIResource;
/*    */ import javax.swing.plaf.ColorUIResource;
/*    */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*    */ import org.jb2011.lnf.beautyeye.widget.border.BEDashedRoundRecBorder;
/*    */ 
/*    */ public class __UI__
/*    */ {
/*    */   public static void uiImpl()
/*    */   {
/* 36 */     UIManager.put("control", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/* 37 */     UIManager.put("Separator.foreground", new ColorUIResource(new Color(180, 180, 180)));
/* 38 */     UIManager.put("ToolTip.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/*    */ 
/* 40 */     UIManager.put("Separator.background", new ColorUIResource(Color.white));
/* 41 */     UIManager.put("Panel.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/* 42 */     UIManager.put("Panel.background", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/*    */ 
/* 44 */     UIManager.put("Label.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/* 45 */     UIManager.put("Label.background", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/*    */ 
/* 47 */     UIManager.put("ColorChooser.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/* 48 */     UIManager.put("ColorChooser.background", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/* 49 */     UIManager.put("ColorChooser.swatchesDefaultRecentColor", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/*    */ 
/* 51 */     UIManager.put("TitledBorder.titleColor", new ColorUIResource(new Color(58, 135, 173)));
/*    */ 
/* 53 */     UIManager.put("TitledBorder.border", new BorderUIResource(new BEDashedRoundRecBorder(BeautyEyeLNFHelper.commonFocusedBorderColor)));
/*    */ 
/* 59 */     UIManager.put("OptionPane.setButtonMargin", Boolean.valueOf(false));
/* 60 */     UIManager.put("OptionPane.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/* 61 */     UIManager.put("OptionPane.background", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/* 62 */     UIManager.put("OptionPane.questionIcon", __IconFactory__.getInstance().getOptionPaneQUESTIONIcon());
/* 63 */     UIManager.put("OptionPane.warningIcon", __IconFactory__.getInstance().getOptionPaneWARNIcon());
/* 64 */     UIManager.put("OptionPane.informationIcon", __IconFactory__.getInstance().getOptionPaneINFOIcon());
/* 65 */     UIManager.put("OptionPane.errorIcon", __IconFactory__.getInstance().getOptionPaneERRORIcon());
/*    */ 
/* 67 */     UIManager.put("SeparatorUI", BESeparatorUI.class.getName());
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch_x.__UI__
 * JD-Core Version:    0.6.2
 */