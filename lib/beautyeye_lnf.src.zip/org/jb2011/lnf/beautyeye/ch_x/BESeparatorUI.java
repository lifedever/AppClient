/*    */ package org.jb2011.lnf.beautyeye.ch_x;
/*    */ 
/*    */ import java.awt.BasicStroke;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.Stroke;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.JSeparator;
/*    */ import javax.swing.LookAndFeel;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.basic.BasicSeparatorUI;
/*    */ 
/*    */ public class BESeparatorUI extends BasicSeparatorUI
/*    */ {
/*    */   public static ComponentUI createUI(JComponent c)
/*    */   {
/* 33 */     return new BESeparatorUI();
/*    */   }
/*    */ 
/*    */   protected void installDefaults(JSeparator s)
/*    */   {
/* 38 */     LookAndFeel.installColors(s, "Separator.background", "Separator.foreground");
/* 39 */     LookAndFeel.installProperty(s, "opaque", Boolean.FALSE);
/*    */   }
/*    */ 
/*    */   public void paint(Graphics g, JComponent c)
/*    */   {
/* 47 */     Stroke oldStroke = ((Graphics2D)g).getStroke();
/* 48 */     Stroke sroke = new BasicStroke(1.0F, 0, 
/* 49 */       2, 0.0F, new float[] { 2.0F, 2.0F }, 0.0F);
/* 50 */     ((Graphics2D)g).setStroke(sroke);
/*    */ 
/* 53 */     Dimension s = c.getSize();
/*    */ 
/* 55 */     if (((JSeparator)c).getOrientation() == 1)
/*    */     {
/* 58 */       g.setColor(c.getForeground());
/* 59 */       g.drawLine(0, 0, 0, s.height);
/*    */ 
/* 61 */       g.setColor(c.getBackground());
/* 62 */       g.drawLine(1, 0, 1, s.height);
/*    */     }
/*    */     else
/*    */     {
/* 66 */       g.setColor(c.getForeground());
/* 67 */       g.drawLine(0, 0, s.width, 0);
/*    */ 
/* 69 */       g.setColor(c.getBackground());
/* 70 */       g.drawLine(0, 1, s.width, 1);
/*    */     }
/*    */ 
/* 73 */     ((Graphics2D)g).setStroke(oldStroke);
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch_x.BESeparatorUI
 * JD-Core Version:    0.6.2
 */