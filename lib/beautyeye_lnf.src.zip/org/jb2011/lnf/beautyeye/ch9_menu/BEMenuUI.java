/*     */ package org.jb2011.lnf.beautyeye.ch9_menu;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.MenuElement;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.event.MouseInputListener;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicMenuUI;
/*     */ import javax.swing.plaf.basic.BasicMenuUI.MouseInputHandler;
/*     */ import org.jb2011.lnf.beautyeye.utils.BEUtils;
/*     */ import org.jb2011.lnf.beautyeye.winlnfutils.WinUtils;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class BEMenuUI extends BasicMenuUI
/*     */ {
/*     */   public static final int DECORATED_UNDERLINE_HEIGHT = 2;
/*  52 */   public static final Color MENU_SELECTED_UNDERLINE_COLOR = new Color(37, 147, 217);
/*     */ 
/*  55 */   public static final Color MENU_UNSELECTED_UNDERLINE_COLOR = new Color(226, 230, 232);
/*     */   protected Integer menuBarHeight;
/*     */   protected boolean hotTrackingOn;
/*     */ 
/*     */   public static ComponentUI createUI(JComponent x)
/*     */   {
/*  71 */     return new BEMenuUI();
/*     */   }
/*     */ 
/*     */   protected void installDefaults()
/*     */   {
/*  80 */     super.installDefaults();
/*     */ 
/*  83 */     this.menuItem.setRolloverEnabled(true);
/*     */ 
/*  86 */     this.menuBarHeight = Integer.valueOf(UIManager.getInt("MenuBar.height"));
/*  87 */     Object obj = UIManager.get("MenuBar.rolloverEnabled");
/*  88 */     this.hotTrackingOn = ((obj instanceof Boolean) ? ((Boolean)obj).booleanValue() : true);
/*     */   }
/*     */ 
/*     */   protected void paintBackground(Graphics g, JMenuItem menuItem, Color bgColor)
/*     */   {
/* 102 */     JMenu menu = (JMenu)menuItem;
/* 103 */     ButtonModel model = menu.getModel();
/*     */ 
/* 105 */     Color oldColor = g.getColor();
/* 106 */     int menuWidth = menu.getWidth();
/* 107 */     int menuHeight = menu.getHeight();
/*     */ 
/* 113 */     g.setColor(menu.getBackground());
/* 114 */     g.fillRect(0, 0, menuWidth, menuHeight);
/*     */ 
/* 118 */     if (menu.isTopLevelMenu())
/*     */     {
/* 122 */       g.setColor(MENU_UNSELECTED_UNDERLINE_COLOR);
/* 123 */       g.fillRect(0, menuHeight - 2, menuWidth, menuHeight);
/*     */     }
/*     */ 
/* 136 */     if (menu.isTopLevelMenu())
/*     */     {
/* 139 */       if ((model.isArmed()) || (model.isSelected()))
/*     */       {
/* 141 */         Color c = MENU_SELECTED_UNDERLINE_COLOR;
/* 142 */         g.setColor(c);
/*     */ 
/* 148 */         int tW = 7; int tH = 3;
/* 149 */         int x1 = menuWidth / 2 - tW / 2;
/* 150 */         int y1 = menuHeight - 2;
/* 151 */         int x2 = menuWidth / 2;
/* 152 */         int y2 = menuHeight - 2 - tH;
/* 153 */         int x3 = menuWidth / 2 + tW / 2;
/* 154 */         int y3 = menuHeight - 2;
/*     */ 
/* 156 */         BEUtils.setAntiAliasing((Graphics2D)g, true);
/* 157 */         BEUtils.fillTriangle(g, x1, y1, x2, y2, x3, y3, c);
/* 158 */         BEUtils.setAntiAliasing((Graphics2D)g, false);
/*     */ 
/* 161 */         g.fillRect(0, menuHeight - 2, menuWidth, 2);
/*     */       }
/* 163 */       else if ((model.isRollover()) && (model.isEnabled()))
/*     */       {
/* 166 */         boolean otherMenuSelected = false;
/* 167 */         MenuElement[] menus = ((JMenuBar)menu.getParent())
/* 168 */           .getSubElements();
/* 169 */         for (int i = 0; i < menus.length; i++)
/*     */         {
/* 171 */           if (((JMenuItem)menus[i]).isSelected())
/*     */           {
/* 173 */             otherMenuSelected = true;
/* 174 */             break;
/*     */           }
/*     */         }
/*     */ 
/* 178 */         if (!otherMenuSelected)
/*     */         {
/* 180 */           g.setColor(MENU_SELECTED_UNDERLINE_COLOR);
/*     */ 
/* 183 */           g.fillRect(0, menuHeight - 2, menuWidth, 2);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/* 188 */     else if ((model.isArmed()) || (((menuItem instanceof JMenu)) && 
/* 189 */       (model.isSelected())))
/*     */     {
/* 192 */       __Icon9Factory__.getInstance().getBgIcon_ItemSelected()
/* 193 */         .draw((Graphics2D)g, 0, 0, menuWidth, menuHeight);
/*     */     }
/* 195 */     g.setColor(oldColor);
/*     */   }
/*     */ 
/*     */   protected void paintText(Graphics g, JMenuItem menuItem, Rectangle textRect, String text)
/*     */   {
/* 217 */     JMenu menu = (JMenu)menuItem;
/* 218 */     ButtonModel model = menuItem.getModel();
/* 219 */     Color oldColor = g.getColor();
/*     */ 
/* 222 */     boolean paintRollover = model.isRollover();
/* 223 */     if ((paintRollover) && (menu.isTopLevelMenu())) {
/* 224 */       MenuElement[] menus = ((JMenuBar)menu.getParent()).getSubElements();
/* 225 */       for (int i = 0; i < menus.length; i++) {
/* 226 */         if (((JMenuItem)menus[i]).isSelected()) {
/* 227 */           paintRollover = false;
/* 228 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 233 */     if (((model.isSelected()) && 
/* 236 */       (!menu.isTopLevelMenu())) || 
/* 240 */       (paintRollover) || (model.isArmed()) || (model.isSelected()))
/*     */     {
/* 244 */       g.setColor(this.selectionForeground);
/*     */     }
/*     */ 
/* 250 */     if (menu.isTopLevelMenu()) {
/* 251 */       g.setColor(new Color(35, 35, 35));
/*     */     }
/*     */ 
/* 255 */     WinUtils.paintText(g, menuItem, textRect, text, 0);
/*     */ 
/* 257 */     g.setColor(oldColor);
/*     */   }
/*     */ 
/*     */   protected MouseInputListener createMouseInputListener(JComponent c)
/*     */   {
/* 265 */     return new BEMouseInputHandler();
/*     */   }
/*     */ 
/*     */   protected Dimension getPreferredMenuItemSize(JComponent c, Icon checkIcon, Icon arrowIcon, int defaultTextIconGap)
/*     */   {
/* 313 */     Dimension d = super.getPreferredMenuItemSize(c, checkIcon, arrowIcon, 
/* 314 */       defaultTextIconGap);
/*     */ 
/* 319 */     if (((c instanceof JMenu)) && (((JMenu)c).isTopLevelMenu()) && 
/* 320 */       (this.menuBarHeight != null) && (d.height < this.menuBarHeight.intValue()))
/*     */     {
/* 322 */       d.height = this.menuBarHeight.intValue();
/*     */     }
/*     */ 
/* 325 */     return d;
/*     */   }
/*     */ 
/*     */   protected class BEMouseInputHandler extends BasicMenuUI.MouseInputHandler
/*     */   {
/*     */     protected BEMouseInputHandler()
/*     */     {
/* 274 */       super();
/*     */     }
/*     */ 
/*     */     public void mouseEntered(MouseEvent evt)
/*     */     {
/* 280 */       super.mouseEntered(evt);
/*     */ 
/* 282 */       JMenu menu = (JMenu)evt.getSource();
/* 283 */       if ((BEMenuUI.this.hotTrackingOn) && (menu.isTopLevelMenu()) && (menu.isRolloverEnabled())) {
/* 284 */         menu.getModel().setRollover(true);
/* 285 */         BEMenuUI.this.menuItem.repaint();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void mouseExited(MouseEvent evt)
/*     */     {
/* 293 */       super.mouseExited(evt);
/*     */ 
/* 295 */       JMenu menu = (JMenu)evt.getSource();
/* 296 */       ButtonModel model = menu.getModel();
/* 297 */       if (menu.isRolloverEnabled()) {
/* 298 */         model.setRollover(false);
/* 299 */         BEMenuUI.this.menuItem.repaint();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch9_menu.BEMenuUI
 * JD-Core Version:    0.6.2
 */