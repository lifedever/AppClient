/*    */ package org.jb2011.lnf.beautyeye.ch9_menu;
/*    */ 
/*    */ import javax.swing.ImageIcon;
/*    */ import org.jb2011.lnf.beautyeye.utils.RawCache;
/*    */ 
/*    */ public class __IconFactory__ extends RawCache<ImageIcon>
/*    */ {
/*    */   public static final String IMGS_ROOT = "imgs";
/* 30 */   private static __IconFactory__ instance = null;
/*    */ 
/*    */   public static __IconFactory__ getInstance()
/*    */   {
/* 39 */     if (instance == null)
/* 40 */       instance = new __IconFactory__();
/* 41 */     return instance;
/*    */   }
/*    */ 
/*    */   protected ImageIcon getResource(String relativePath, Class baseClass)
/*    */   {
/* 50 */     return new ImageIcon(baseClass.getResource(relativePath));
/*    */   }
/*    */ 
/*    */   public ImageIcon getImage(String relativePath)
/*    */   {
/* 61 */     return (ImageIcon)getRaw(relativePath, getClass());
/*    */   }
/*    */ 
/*    */   public ImageIcon getRadioButtonMenuItemCheckIcon()
/*    */   {
/* 71 */     return getImage("imgs/RadioButtonMenuItemCheckIcon2.png");
/*    */   }
/*    */ 
/*    */   public ImageIcon getRadioButtonMenuItemNormalIcon() {
/* 75 */     return getImage("imgs/RadioButtonMenuItemCheckIcon_none.png");
/*    */   }
/*    */ 
/*    */   public ImageIcon getCheckboxMenuItemSelectedNormalIcon()
/*    */   {
/* 85 */     return getImage("imgs/checkbox_menuitem_selected_normal.png");
/*    */   }
/*    */ 
/*    */   public ImageIcon getCheckboxMenuItemNoneIcon()
/*    */   {
/* 98 */     return getImage("imgs/checkbox_menuitem_none.png");
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch9_menu.__IconFactory__
 * JD-Core Version:    0.6.2
 */