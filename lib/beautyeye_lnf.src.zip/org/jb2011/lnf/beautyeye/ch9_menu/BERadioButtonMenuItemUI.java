/*     */ package org.jb2011.lnf.beautyeye.ch9_menu;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.io.Serializable;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.basic.BasicRadioButtonMenuItemUI;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class BERadioButtonMenuItemUI extends BasicRadioButtonMenuItemUI
/*     */ {
/*     */   public static ComponentUI createUI(JComponent b)
/*     */   {
/*  48 */     return new BERadioButtonMenuItemUI();
/*     */   }
/*     */ 
/*     */   protected void paintBackground(Graphics g, JMenuItem menuItem, Color bgColor)
/*     */   {
/*  62 */     ButtonModel model = menuItem.getModel();
/*  63 */     Color oldColor = g.getColor();
/*  64 */     int menuWidth = menuItem.getWidth();
/*  65 */     int menuHeight = menuItem.getHeight();
/*     */ 
/*  67 */     if (menuItem.isOpaque())
/*     */     {
/*  69 */       if ((model.isArmed()) || (((menuItem instanceof JMenu)) && (model.isSelected())))
/*     */       {
/*  71 */         g.setColor(bgColor);
/*  72 */         g.fillRect(0, 0, menuWidth, menuHeight);
/*     */       }
/*     */       else
/*     */       {
/*  76 */         g.setColor(menuItem.getBackground());
/*  77 */         g.fillRect(0, 0, menuWidth, menuHeight);
/*     */       }
/*  79 */       g.setColor(oldColor);
/*     */     }
/*  81 */     else if ((model.isArmed()) || (((menuItem instanceof JMenu)) && 
/*  82 */       (model.isSelected())))
/*     */     {
/*  89 */       __Icon9Factory__.getInstance().getBgIcon_ItemSelected()
/*  90 */         .draw((Graphics2D)g, 0, 0, menuWidth, menuHeight);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class RadioButtonMenuItemIcon
/*     */     implements Icon, UIResource, Serializable
/*     */   {
/* 107 */     private boolean usedForVista = false;
/*     */ 
/* 111 */     private Image selectedImg = __IconFactory__.getInstance()
/* 111 */       .getRadioButtonMenuItemCheckIcon().getImage();
/*     */ 
/* 114 */     private Image normalImg = __IconFactory__.getInstance()
/* 114 */       .getRadioButtonMenuItemNormalIcon().getImage();
/*     */ 
/*     */     public void paintIcon(Component c, Graphics g, int x, int y)
/*     */     {
/* 121 */       AbstractButton b = (AbstractButton)c;
/*     */ 
/* 123 */       if (b.isSelected())
/*     */       {
/* 126 */         g.drawImage(this.selectedImg, 
/* 127 */           x + (this.usedForVista ? 5 : -4), 
/* 128 */           y + (this.usedForVista ? -3 : -4), null);
/*     */       }
/*     */       else
/*     */       {
/* 132 */         g.drawImage(this.normalImg, 
/* 133 */           x + (this.usedForVista ? 5 : -4), 
/* 134 */           y + (this.usedForVista ? -3 : -4), null);
/*     */       }
/*     */     }
/*     */ 
/*     */     public int getIconWidth()
/*     */     {
/* 141 */       return 16;
/*     */     }
/*     */ 
/*     */     public int getIconHeight()
/*     */     {
/* 146 */       return 16;
/*     */     }
/*     */ 
/*     */     public boolean isUsedForVista()
/*     */     {
/* 155 */       return this.usedForVista;
/*     */     }
/*     */ 
/*     */     public RadioButtonMenuItemIcon setUsedForVista(boolean usedForVista)
/*     */     {
/* 166 */       this.usedForVista = usedForVista;
/* 167 */       return this;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch9_menu.BERadioButtonMenuItemUI
 * JD-Core Version:    0.6.2
 */