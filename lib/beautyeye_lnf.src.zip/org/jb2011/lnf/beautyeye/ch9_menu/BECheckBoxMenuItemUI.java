/*     */ package org.jb2011.lnf.beautyeye.ch9_menu;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.io.Serializable;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.basic.BasicCheckBoxMenuItemUI;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class BECheckBoxMenuItemUI extends BasicCheckBoxMenuItemUI
/*     */ {
/*  40 */   private static boolean enforceTransparent = true;
/*     */ 
/*     */   public static ComponentUI createUI(JComponent b)
/*     */   {
/*  50 */     return new BECheckBoxMenuItemUI();
/*     */   }
/*     */ 
/*     */   protected void paintBackground(Graphics g, JMenuItem menuItem, Color bgColor)
/*     */   {
/*  65 */     ButtonModel model = menuItem.getModel();
/*  66 */     Color oldColor = g.getColor();
/*  67 */     int menuWidth = menuItem.getWidth();
/*  68 */     int menuHeight = menuItem.getHeight();
/*     */ 
/*  70 */     Graphics2D g2 = (Graphics2D)g;
/*     */ 
/*  72 */     if ((model.isArmed()) || (
/*  73 */       ((menuItem instanceof JMenu)) && (model.isSelected())))
/*     */     {
/*  75 */       g.setColor(bgColor);
/*     */ 
/*  77 */       __Icon9Factory__.getInstance().getBgIcon_ItemSelected()
/*  78 */         .draw(g2, 0, 0, menuWidth, menuHeight);
/*     */     }
/*  95 */     else if (!enforceTransparent)
/*     */     {
/*  97 */       g.setColor(menuItem.getBackground());
/*  98 */       g.fillRect(0, 0, menuWidth, menuHeight);
/*     */     }
/*     */ 
/* 101 */     g.setColor(oldColor);
/*     */   }
/*     */ 
/*     */   public static class CheckBoxMenuItemIcon
/*     */     implements Icon, UIResource, Serializable
/*     */   {
/* 117 */     private boolean usedForVista = false;
/*     */ 
/*     */     public void paintIcon(Component c, Graphics g, int x, int y)
/*     */     {
/* 124 */       AbstractButton b = (AbstractButton)c;
/* 125 */       ButtonModel model = b.getModel();
/*     */ 
/* 127 */       Image selectedImg = __IconFactory__.getInstance().getCheckboxMenuItemSelectedNormalIcon().getImage();
/* 128 */       boolean isSelected = model.isSelected();
/*     */ 
/* 130 */       if (!isSelected)
/*     */       {
/* 136 */         selectedImg = __IconFactory__.getInstance().getCheckboxMenuItemNoneIcon().getImage();
/*     */       }
/* 138 */       g.drawImage(selectedImg, 
/* 139 */         x + (this.usedForVista ? 5 : -4), 
/* 140 */         y - 3, 
/* 141 */         null);
/*     */     }
/*     */ 
/*     */     public int getIconWidth()
/*     */     {
/* 147 */       return 16;
/*     */     }
/*     */ 
/*     */     public int getIconHeight()
/*     */     {
/* 152 */       return 16;
/*     */     }
/*     */ 
/*     */     public boolean isUsedForVista()
/*     */     {
/* 161 */       return this.usedForVista;
/*     */     }
/*     */ 
/*     */     public CheckBoxMenuItemIcon setUsedForVista(boolean usedForVista)
/*     */     {
/* 172 */       this.usedForVista = usedForVista;
/* 173 */       return this;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch9_menu.BECheckBoxMenuItemUI
 * JD-Core Version:    0.6.2
 */