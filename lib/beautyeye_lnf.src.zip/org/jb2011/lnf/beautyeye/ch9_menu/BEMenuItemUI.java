/*    */ package org.jb2011.lnf.beautyeye.ch9_menu;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Graphics2D;
/*    */ import javax.swing.ButtonModel;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.JMenu;
/*    */ import javax.swing.JMenuItem;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.basic.BasicMenuItemUI;
/*    */ import org.jb2011.ninepatch4j.NinePatch;
/*    */ 
/*    */ public class BEMenuItemUI extends BasicMenuItemUI
/*    */ {
/* 41 */   private static boolean enforceTransparent = true;
/*    */ 
/*    */   public static ComponentUI createUI(JComponent c)
/*    */   {
/* 51 */     return new BEMenuItemUI();
/*    */   }
/*    */ 
/*    */   protected void paintBackground(Graphics g, JMenuItem menuItem, Color bgColor)
/*    */   {
/* 62 */     ButtonModel model = menuItem.getModel();
/* 63 */     Color oldColor = g.getColor();
/* 64 */     int menuWidth = menuItem.getWidth();
/* 65 */     int menuHeight = menuItem.getHeight();
/*    */ 
/* 67 */     Graphics2D g2 = (Graphics2D)g;
/*    */ 
/* 69 */     if ((model.isArmed()) || (
/* 70 */       ((menuItem instanceof JMenu)) && (model.isSelected())))
/*    */     {
/* 73 */       __Icon9Factory__.getInstance().getBgIcon_ItemSelected()
/* 74 */         .draw(g2, 0, 0, menuWidth, menuHeight);
/*    */     }
/* 78 */     else if (!enforceTransparent)
/*    */     {
/* 80 */       g.setColor(menuItem.getBackground());
/* 81 */       g.fillRect(0, 0, menuWidth, menuHeight);
/*    */     }
/*    */ 
/* 84 */     g.setColor(oldColor);
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch9_menu.BEMenuItemUI
 * JD-Core Version:    0.6.2
 */