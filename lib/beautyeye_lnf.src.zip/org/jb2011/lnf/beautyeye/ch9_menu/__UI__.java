/*     */ package org.jb2011.lnf.beautyeye.ch9_menu;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.BorderUIResource;
/*     */ import javax.swing.plaf.ColorUIResource;
/*     */ import javax.swing.plaf.InsetsUIResource;
/*     */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*     */ 
/*     */ public class __UI__
/*     */ {
/*     */   public static void uiImpl()
/*     */   {
/*  38 */     UIManager.put("MenuBar.border", BorderFactory.createEmptyBorder());
/*     */ 
/*  43 */     UIManager.put("CheckBoxMenuItem.margin", new InsetsUIResource(0, 0, 0, 0));
/*  44 */     UIManager.put("RadioButtonMenuItem.margin", new InsetsUIResource(0, 0, 0, 0));
/*  45 */     UIManager.put("Menu.margin", new InsetsUIResource(0, 0, 0, 0));
/*  46 */     UIManager.put("MenuItem.margin", new InsetsUIResource(0, 0, 0, 0));
/*     */ 
/*  50 */     UIManager.put("Menu.border", new BorderUIResource(BorderFactory.createEmptyBorder(4, 3, 5, 3)));
/*  51 */     UIManager.put("MenuItem.border", new BorderUIResource(BorderFactory.createEmptyBorder(4, 3, 5, 3)));
/*  52 */     UIManager.put("CheckBoxMenuItem.border", new BorderUIResource(BorderFactory.createEmptyBorder(4, 3, 5, 3)));
/*  53 */     UIManager.put("RadioButtonMenuItem.border", new BorderUIResource(BorderFactory.createEmptyBorder(4, 3, 5, 3)));
/*     */ 
/*  58 */     UIManager.put("MenuBar.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/*  59 */     UIManager.put("RadioButtonMenuItem.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/*  60 */     UIManager.put("Menu.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/*  61 */     UIManager.put("PopupMenu.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/*  62 */     UIManager.put("CheckBoxMenuItem.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/*  63 */     UIManager.put("MenuItem.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/*     */ 
/*  65 */     UIManager.put("MenuBar.background", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/*  66 */     UIManager.put("Menu.background", new ColorUIResource(new Color(255, 255, 255, 0)));
/*  67 */     UIManager.put("PopupMenu.background", new ColorUIResource(new Color(255, 255, 255, 0)));
/*     */ 
/*  69 */     UIManager.put("RadioButtonMenuItem.disabledForeground", new ColorUIResource(BeautyEyeLNFHelper.commonDisabledForegroundColor));
/*  70 */     UIManager.put("MenuItem.disabledForeground", new ColorUIResource(BeautyEyeLNFHelper.commonDisabledForegroundColor));
/*     */ 
/*  72 */     UIManager.put("Menu.selectionForeground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionForegroundColor));
/*  73 */     UIManager.put("MenuItem.selectionForeground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionForegroundColor));
/*  74 */     UIManager.put("CheckBoxMenuItem.selectionForeground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionForegroundColor));
/*  75 */     UIManager.put("RadioButtonMenuItem.selectionForeground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionForegroundColor));
/*     */ 
/*  77 */     UIManager.put("Menu.selectionBackground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionBackgroundColor));
/*  78 */     UIManager.put("MenuItem.selectionBackground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionBackgroundColor));
/*  79 */     UIManager.put("CheckBoxMenuItem.selectionBackground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionBackgroundColor));
/*  80 */     UIManager.put("RadioButtonMenuItem.selectionBackground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionBackgroundColor));
/*     */ 
/*  85 */     UIManager.put("Menu.menuPopupOffsetX", Integer.valueOf(-3));
/*     */ 
/*  87 */     UIManager.put("Menu.menuPopupOffsetY", Integer.valueOf(2));
/*     */ 
/*  89 */     UIManager.put("Menu.submenuPopupOffsetX", Integer.valueOf(-2));
/*     */ 
/*  91 */     UIManager.put("Menu.submenuPopupOffsetY", Integer.valueOf(-5));
/*     */ 
/*  94 */     UIManager.put("CheckBoxMenuItem.checkIcon", new BECheckBoxMenuItemUI.CheckBoxMenuItemIcon());
/*     */ 
/*  96 */     UIManager.put("RadioButtonMenuItem.checkIcon", new BERadioButtonMenuItemUI.RadioButtonMenuItemIcon());
/*     */ 
/*  99 */     UIManager.put("MenuBar.height", Integer.valueOf(30));
/*     */ 
/* 103 */     UIManager.put("MenuItem.disabledAreNavigable", Boolean.valueOf(false));
/*     */ 
/* 107 */     UIManager.put("MenuBarUI", BEMenuBarUI.class.getName());
/* 108 */     UIManager.put("MenuUI", BEMenuUI.class.getName());
/* 109 */     UIManager.put("MenuItemUI", BEMenuItemUI.class.getName());
/* 110 */     UIManager.put("RadioButtonMenuItemUI", BERadioButtonMenuItemUI.class.getName());
/* 111 */     UIManager.put("CheckBoxMenuItemUI", BECheckBoxMenuItemUI.class.getName());
/* 112 */     UIManager.put("PopupMenuSeparatorUI", BEPopupMenuSeparatorUI.class.getName());
/* 113 */     UIManager.put("PopupMenuUI", BEPopupMenuUI.class.getName());
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch9_menu.__UI__
 * JD-Core Version:    0.6.2
 */