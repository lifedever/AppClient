/*     */ package org.jb2011.lnf.beautyeye.ch9_menu;
/*     */ 
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Stroke;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JSeparator;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.SeparatorUI;
/*     */ 
/*     */ public class BEPopupMenuSeparatorUI extends SeparatorUI
/*     */ {
/*     */   public static ComponentUI createUI(JComponent c)
/*     */   {
/*  43 */     return new BEPopupMenuSeparatorUI();
/*     */   }
/*     */ 
/*     */   public void installUI(JComponent c)
/*     */   {
/*  51 */     installDefaults((JSeparator)c);
/*  52 */     installListeners((JSeparator)c);
/*     */   }
/*     */ 
/*     */   public void uninstallUI(JComponent c)
/*     */   {
/*  60 */     uninstallDefaults((JSeparator)c);
/*  61 */     uninstallListeners((JSeparator)c);
/*     */   }
/*     */ 
/*     */   protected void installDefaults(JSeparator s)
/*     */   {
/*  71 */     LookAndFeel.installColors(s, "Separator.background", "Separator.foreground");
/*  72 */     LookAndFeel.installProperty(s, "opaque", Boolean.FALSE);
/*     */   }
/*     */ 
/*     */   protected void uninstallDefaults(JSeparator s)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void installListeners(JSeparator s)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void uninstallListeners(JSeparator s)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void paint(Graphics g, JComponent c)
/*     */   {
/* 107 */     int w = c.getWidth(); int h = c.getHeight();
/* 108 */     Graphics2D g2 = (Graphics2D)g;
/*     */ 
/* 110 */     if (((JSeparator)c).getOrientation() == 1)
/*     */     {
/* 114 */       g.setColor(c.getForeground());
/* 115 */       g.drawLine(0, 0, 0, c.getHeight());
/* 116 */       g.setColor(c.getBackground());
/* 117 */       g.drawLine(1, 0, 1, c.getHeight());
/*     */     }
/*     */     else
/*     */     {
/* 121 */       drawHorizonal(g2, c, w, h);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void drawHorizonal(Graphics2D g2, JComponent c, int w, int h)
/*     */   {
/* 137 */     Stroke oldStroke = g2.getStroke();
/* 138 */     Stroke sroke = new BasicStroke(1.0F, 0, 
/* 139 */       2, 0.0F, new float[] { 2.0F, 2.0F }, 0.0F);
/* 140 */     g2.setStroke(sroke);
/*     */ 
/* 143 */     g2.setColor(c.getForeground());
/* 144 */     g2.drawLine(0, h - 2, w - 1, h - 2);
/*     */ 
/* 148 */     g2.setColor(c.getBackground());
/* 149 */     g2.drawLine(0, h - 1, w - 1, h - 1);
/*     */ 
/* 151 */     g2.setStroke(oldStroke);
/*     */   }
/*     */ 
/*     */   public Dimension getPreferredSize(JComponent c)
/*     */   {
/* 159 */     if (((JSeparator)c).getOrientation() == 1) {
/* 160 */       return new Dimension(2, 0);
/*     */     }
/* 162 */     return new Dimension(0, 3);
/*     */   }
/*     */ 
/*     */   public Dimension getMinimumSize(JComponent c)
/*     */   {
/* 168 */     return null;
/*     */   }
/*     */ 
/*     */   public Dimension getMaximumSize(JComponent c)
/*     */   {
/* 173 */     return null;
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch9_menu.BEPopupMenuSeparatorUI
 * JD-Core Version:    0.6.2
 */