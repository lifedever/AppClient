/*    */ package org.jb2011.lnf.beautyeye.ch9_menu;
/*    */ 
/*    */ import java.awt.Graphics;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.basic.BasicMenuBarUI;
/*    */ 
/*    */ public class BEMenuBarUI extends BasicMenuBarUI
/*    */ {
/*    */   public static ComponentUI createUI(JComponent x)
/*    */   {
/* 39 */     return new BEMenuBarUI();
/*    */   }
/*    */ 
/*    */   public void paint(Graphics g, JComponent c)
/*    */   {
/* 48 */     int width = c.getWidth();
/* 49 */     int height = c.getHeight();
/*    */ 
/* 52 */     g.setColor(BEMenuUI.MENU_UNSELECTED_UNDERLINE_COLOR);
/* 53 */     g.fillRect(0, height - 2, width, height);
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch9_menu.BEMenuBarUI
 * JD-Core Version:    0.6.2
 */