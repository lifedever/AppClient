/*     */ package org.jb2011.lnf.beautyeye;
/*     */ 
/*     */ import com.sun.java.swing.plaf.windows.WindowsLookAndFeel;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.UIDefaults;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.BorderUIResource;
/*     */ import javax.swing.plaf.InsetsUIResource;
/*     */ import org.jb2011.lnf.beautyeye.ch20_filechooser.__UI__;
/*     */ import org.jb2011.lnf.beautyeye.ch9_menu.BECheckBoxMenuItemUI.CheckBoxMenuItemIcon;
/*     */ import org.jb2011.lnf.beautyeye.ch9_menu.BERadioButtonMenuItemUI.RadioButtonMenuItemIcon;
/*     */ import org.jb2011.lnf.beautyeye.winlnfutils.WinUtils;
/*     */ 
/*     */ public class BeautyEyeLookAndFeelWin extends WindowsLookAndFeel
/*     */ {
/*     */   static
/*     */   {
/*  39 */     initLookAndFeelDecorated();
/*     */   }
/*     */ 
/*     */   public BeautyEyeLookAndFeelWin()
/*     */   {
/*  53 */     BeautyEyeLNFHelper.implLNF();
/*     */ 
/*  56 */     __UI__.uiImpl_win();
/*     */ 
/*  59 */     initForVista();
/*     */   }
/*     */ 
/*     */   protected void initForVista()
/*     */   {
/*  75 */     if (WinUtils.isOnVista())
/*     */     {
/*  77 */       UIManager.put("CheckBoxMenuItem.margin", new InsetsUIResource(0, 0, 0, 0));
/*  78 */       UIManager.put("RadioButtonMenuItem.margin", new InsetsUIResource(0, 0, 0, 0));
/*  79 */       UIManager.put("Menu.margin", new InsetsUIResource(0, 0, 0, 0));
/*  80 */       UIManager.put("MenuItem.margin", new InsetsUIResource(0, 0, 0, 0));
/*     */ 
/*  82 */       UIManager.put("Menu.border", new BorderUIResource(BorderFactory.createEmptyBorder(1, 3, 2, 3)));
/*  83 */       UIManager.put("MenuItem.border", new BorderUIResource(BorderFactory.createEmptyBorder(1, 0, 2, 0)));
/*  84 */       UIManager.put("CheckBoxMenuItem.border", new BorderUIResource(BorderFactory.createEmptyBorder(4, 2, 4, 2)));
/*  85 */       UIManager.put("RadioButtonMenuItem.border", new BorderUIResource(BorderFactory.createEmptyBorder(4, 0, 4, 0)));
/*     */ 
/*  88 */       UIManager.put("CheckBoxMenuItem.checkIcon", 
/*  89 */         new BECheckBoxMenuItemUI.CheckBoxMenuItemIcon().setUsedForVista(true));
/*  90 */       UIManager.put("RadioButtonMenuItem.checkIcon", 
/*  91 */         new BERadioButtonMenuItemUI.RadioButtonMenuItemIcon().setUsedForVista(true));
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 101 */     return "BeautyEyeWin";
/*     */   }
/*     */ 
/*     */   public String getID()
/*     */   {
/* 110 */     return "BeautyEyeWin";
/*     */   }
/*     */ 
/*     */   public String getDescription()
/*     */   {
/* 119 */     return "BeautyEye windows-platform L&F developed by Jack Jiang(jb2011@163.com).";
/*     */   }
/*     */ 
/*     */   public boolean getSupportsWindowDecorations()
/*     */   {
/* 131 */     return true;
/*     */   }
/*     */ 
/*     */   protected void initComponentDefaults(UIDefaults table)
/*     */   {
/* 139 */     super.initComponentDefaults(table);
/* 140 */     initOtherResourceBundle(table);
/*     */   }
/*     */ 
/*     */   protected void initOtherResourceBundle(UIDefaults table)
/*     */   {
/* 148 */     table.addResourceBundle("org.jb2011.lnf.beautyeye.resources.beautyeye");
/*     */   }
/*     */ 
/*     */   static void initLookAndFeelDecorated()
/*     */   {
/* 157 */     if (BeautyEyeLNFHelper.frameBorderStyle == BeautyEyeLNFHelper.FrameBorderStyle.osLookAndFeelDecorated)
/*     */     {
/* 159 */       JFrame.setDefaultLookAndFeelDecorated(false);
/* 160 */       JDialog.setDefaultLookAndFeelDecorated(false);
/*     */     }
/*     */     else
/*     */     {
/* 164 */       JFrame.setDefaultLookAndFeelDecorated(true);
/* 165 */       JDialog.setDefaultLookAndFeelDecorated(true);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.BeautyEyeLookAndFeelWin
 * JD-Core Version:    0.6.2
 */