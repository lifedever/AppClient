/*     */ package org.jb2011.lnf.beautyeye.ch6_textcoms;
/*     */ 
/*     */ import java.awt.Graphics;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.basic.BasicTextAreaUI;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.__UseParentPaintSurported;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class BETextAreaUI extends BasicTextAreaUI
/*     */   implements __UI__.BgSwitchable, BeautyEyeLNFHelper.__UseParentPaintSurported
/*     */ {
/*  35 */   private NinePatch bg = __Icon9Factory__.getInstance().getNullWhiteBg();
/*     */ 
/*     */   public static ComponentUI createUI(JComponent c)
/*     */   {
/*  45 */     BETextFieldUI.addOtherListener(c);
/*     */ 
/*  47 */     return new BETextAreaUI();
/*     */   }
/*     */ 
/*     */   public boolean isUseParentPaint()
/*     */   {
/*  66 */     return (getComponent() != null) && (
/*  65 */       (!(getComponent().getBorder() instanceof UIResource)) || 
/*  66 */       (!(getComponent().getBackground() instanceof UIResource)));
/*     */   }
/*     */ 
/*     */   protected void paintBackground(Graphics g)
/*     */   {
/*  82 */     super.paintBackground(g);
/*     */ 
/*  85 */     if (!isUseParentPaint())
/*     */     {
/*  88 */       JTextComponent editor = getComponent();
/*  89 */       BETextFieldUI.paintBg(g, 0, 0, editor.getWidth(), editor.getHeight(), 
/*  90 */         editor.isEnabled(), this.bg);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void switchBgToNomal()
/*     */   {
/* 101 */     this.bg = __Icon9Factory__.getInstance().getNullWhiteBg();
/*     */   }
/*     */ 
/*     */   public void switchBgToFocused()
/*     */   {
/* 109 */     this.bg = __Icon9Factory__.getInstance().getTextFieldBgFocused();
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch6_textcoms.BETextAreaUI
 * JD-Core Version:    0.6.2
 */