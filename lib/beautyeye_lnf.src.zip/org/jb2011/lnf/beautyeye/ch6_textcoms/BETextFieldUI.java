/*     */ package org.jb2011.lnf.beautyeye.ch6_textcoms;
/*     */ 
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.basic.BasicTextFieldUI;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.__UseParentPaintSurported;
/*     */ import org.jb2011.lnf.beautyeye.widget.FocusListenerImpl;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class BETextFieldUI extends BasicTextFieldUI
/*     */   implements __UI__.BgSwitchable, BeautyEyeLNFHelper.__UseParentPaintSurported
/*     */ {
/*  35 */   private NinePatch bg = __Icon9Factory__.getInstance().getTextFieldBgNormal();
/*     */ 
/*     */   public static BETextFieldUI createUI(JComponent c)
/*     */   {
/*  46 */     addOtherListener(c);
/*  47 */     return new BETextFieldUI();
/*     */   }
/*     */ 
/*     */   public boolean isUseParentPaint()
/*     */   {
/*  66 */     return (getComponent() != null) && (
/*  65 */       (!(getComponent().getBorder() instanceof UIResource)) || 
/*  66 */       (!(getComponent().getBackground() instanceof UIResource)));
/*     */   }
/*     */ 
/*     */   protected void paintBackground(Graphics g)
/*     */   {
/* 100 */     super.paintBackground(g);
/*     */ 
/* 103 */     if (!isUseParentPaint())
/*     */     {
/* 106 */       JTextComponent editor = getComponent();
/* 107 */       paintBg(g, 0, 0, editor.getWidth(), editor.getHeight(), 
/* 108 */         editor.isEnabled(), this.bg);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void switchBgToNomal()
/*     */   {
/* 174 */     this.bg = __Icon9Factory__.getInstance().getTextFieldBgNormal();
/*     */   }
/*     */ 
/*     */   public void switchBgToFocused()
/*     */   {
/* 182 */     this.bg = __Icon9Factory__.getInstance().getTextFieldBgFocused();
/*     */   }
/*     */ 
/*     */   public static void paintBg(Graphics g, int x, int y, int w, int h, boolean enabled, NinePatch bg)
/*     */   {
/* 199 */     if (enabled)
/*     */     {
/* 202 */       bg.draw((Graphics2D)g, x, y, w, h);
/*     */     }
/* 204 */     else __Icon9Factory__.getInstance().getTextFieldBgDisabled()
/* 205 */         .draw((Graphics2D)g, x, y, w, h);
/*     */   }
/*     */ 
/*     */   public static void addOtherListener(JComponent c)
/*     */   {
/* 216 */     c.addFocusListener(FocusListenerImpl.getInstance());
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch6_textcoms.BETextFieldUI
 * JD-Core Version:    0.6.2
 */