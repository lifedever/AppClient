/*     */ package org.jb2011.lnf.beautyeye.ch6_textcoms;
/*     */ 
/*     */ import java.awt.Graphics;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.basic.BasicPasswordFieldUI;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.__UseParentPaintSurported;
/*     */ import org.jb2011.lnf.beautyeye.widget.FocusListenerImpl;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class BEPasswordFieldUI extends BasicPasswordFieldUI
/*     */   implements __UI__.BgSwitchable, BeautyEyeLNFHelper.__UseParentPaintSurported
/*     */ {
/*  36 */   private NinePatch bg = __Icon9Factory__.getInstance().getTextFieldBgNormal();
/*     */ 
/*     */   public static ComponentUI createUI(JComponent c)
/*     */   {
/*  46 */     c.addFocusListener(FocusListenerImpl.getInstance());
/*     */ 
/*  48 */     return new BEPasswordFieldUI();
/*     */   }
/*     */ 
/*     */   public boolean isUseParentPaint()
/*     */   {
/*  67 */     return (getComponent() != null) && (
/*  66 */       (!(getComponent().getBorder() instanceof UIResource)) || 
/*  67 */       (!(getComponent().getBackground() instanceof UIResource)));
/*     */   }
/*     */ 
/*     */   protected void paintBackground(Graphics g)
/*     */   {
/*  83 */     super.paintBackground(g);
/*     */ 
/*  86 */     if (!isUseParentPaint())
/*     */     {
/*  89 */       JTextComponent editor = getComponent();
/*  90 */       BETextFieldUI.paintBg(g, 0, 0, editor.getWidth(), editor.getHeight(), 
/*  91 */         editor.isEnabled(), this.bg);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void switchBgToNomal()
/*     */   {
/* 100 */     this.bg = __Icon9Factory__.getInstance().getTextFieldBgNormal();
/*     */   }
/*     */ 
/*     */   public void switchBgToFocused()
/*     */   {
/* 108 */     this.bg = __Icon9Factory__.getInstance().getTextFieldBgFocused();
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch6_textcoms.BEPasswordFieldUI
 * JD-Core Version:    0.6.2
 */