/*    */ package org.jb2011.lnf.beautyeye.ch6_textcoms;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.plaf.BorderUIResource;
/*    */ import javax.swing.plaf.ColorUIResource;
/*    */ import javax.swing.plaf.InsetsUIResource;
/*    */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*    */ import org.jb2011.lnf.beautyeye.widget.border.BERoundBorder;
/*    */ 
/*    */ public class __UI__
/*    */ {
/*    */   public static void uiImpl()
/*    */   {
/* 36 */     InsetsUIResource iuir = new InsetsUIResource(4, 3, 4, 3);
/*    */ 
/* 38 */     UIManager.put("TextField.margin", iuir);
/* 39 */     UIManager.put("TextField.border", new BorderUIResource(new BERoundBorder().setLineColor(new Color(0, 0, 0, 0))));
/* 40 */     UIManager.put("TextField.selectionForeground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionForegroundColor));
/* 41 */     UIManager.put("TextField.selectionBackground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionBackgroundColor));
/* 42 */     UIManager.put("TextField.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/* 43 */     UIManager.put("TextFieldUI", BETextFieldUI.class.getName());
/*    */ 
/* 45 */     UIManager.put("FormattedTextField.margin", iuir);
/* 46 */     UIManager.put("FormattedTextField.border", new BorderUIResource(new BERoundBorder(1).setArcWidth(10).setLineColor(new Color(0, 0, 0, 0))));
/* 47 */     UIManager.put("FormattedTextField.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/* 48 */     UIManager.put("FormattedTextField.inactiveBackground", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/* 49 */     UIManager.put("FormattedTextField.selectionForeground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionForegroundColor));
/* 50 */     UIManager.put("FormattedTextField.selectionBackground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionBackgroundColor));
/*    */ 
/* 52 */     UIManager.put("PasswordField.margin", iuir);
/* 53 */     UIManager.put("PasswordField.border", new BorderUIResource(new BERoundBorder().setLineColor(new Color(0, 0, 0, 0))));
/* 54 */     UIManager.put("PasswordField.selectionForeground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionForegroundColor));
/* 55 */     UIManager.put("PasswordField.selectionBackground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionBackgroundColor));
/* 56 */     UIManager.put("PasswordField.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/* 57 */     UIManager.put("PasswordFieldUI", BEPasswordFieldUI.class.getName());
/*    */ 
/* 59 */     UIManager.put("TextArea.margin", iuir);
/* 60 */     UIManager.put("TextArea.border", new BorderUIResource(new BERoundBorder().setLineColor(new Color(0, 0, 0, 0))));
/* 61 */     UIManager.put("TextArea.selectionForeground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionForegroundColor));
/* 62 */     UIManager.put("TextArea.selectionBackground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionBackgroundColor));
/* 63 */     UIManager.put("TextArea.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/* 64 */     UIManager.put("TextAreaUI", BETextAreaUI.class.getName());
/*    */ 
/* 67 */     UIManager.put("TextPane.border", new BorderUIResource(new BERoundBorder().setLineColor(new Color(0, 0, 0, 0))));
/* 68 */     UIManager.put("TextPane.selectionBackground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionBackgroundColor));
/* 69 */     UIManager.put("TextPane.selectionForeground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionForegroundColor));
/* 70 */     UIManager.put("TextPane.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/* 71 */     UIManager.put("TextPaneUI", BETextPaneUI.class.getName());
/*    */ 
/* 74 */     UIManager.put("EditorPane.border", new BorderUIResource(new BERoundBorder().setLineColor(new Color(0, 0, 0, 0))));
/* 75 */     UIManager.put("EditorPane.selectionForeground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionForegroundColor));
/* 76 */     UIManager.put("EditorPane.selectionBackground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionBackgroundColor));
/* 77 */     UIManager.put("EditorPane.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/* 78 */     UIManager.put("EditorPaneUI", BEEditorPaneUI.class.getName());
/*    */   }
/*    */ 
/*    */   public static abstract interface BgSwitchable
/*    */   {
/*    */     public abstract void switchBgToNomal();
/*    */ 
/*    */     public abstract void switchBgToFocused();
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch6_textcoms.__UI__
 * JD-Core Version:    0.6.2
 */