/*     */ package org.jb2011.lnf.beautyeye.ch6_textcoms;
/*     */ 
/*     */ import java.awt.Graphics;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.basic.BasicEditorPaneUI;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.__UseParentPaintSurported;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class BEEditorPaneUI extends BasicEditorPaneUI
/*     */   implements __UI__.BgSwitchable, BeautyEyeLNFHelper.__UseParentPaintSurported
/*     */ {
/*  38 */   private NinePatch bg = __Icon9Factory__.getInstance().getNullWhiteBg();
/*     */ 
/*     */   public static ComponentUI createUI(JComponent c)
/*     */   {
/*  48 */     BETextFieldUI.addOtherListener(c);
/*     */ 
/*  50 */     return new BEEditorPaneUI();
/*     */   }
/*     */ 
/*     */   public boolean isUseParentPaint()
/*     */   {
/*  69 */     return (getComponent() != null) && (
/*  68 */       (!(getComponent().getBorder() instanceof UIResource)) || 
/*  69 */       (!(getComponent().getBackground() instanceof UIResource)));
/*     */   }
/*     */ 
/*     */   protected void paintBackground(Graphics g)
/*     */   {
/*  85 */     super.paintBackground(g);
/*     */ 
/*  88 */     if (!isUseParentPaint())
/*     */     {
/*  91 */       JTextComponent editor = getComponent();
/*  92 */       BETextFieldUI.paintBg(g, 0, 0, editor.getWidth(), editor.getHeight(), 
/*  93 */         editor.isEnabled(), this.bg);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void switchBgToNomal()
/*     */   {
/* 104 */     this.bg = __Icon9Factory__.getInstance().getNullWhiteBg();
/*     */   }
/*     */ 
/*     */   public void switchBgToFocused()
/*     */   {
/* 112 */     this.bg = __Icon9Factory__.getInstance().getTextFieldBgFocused();
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch6_textcoms.BEEditorPaneUI
 * JD-Core Version:    0.6.2
 */