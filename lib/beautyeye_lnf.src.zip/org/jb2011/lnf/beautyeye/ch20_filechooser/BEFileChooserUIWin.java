/*     */ package org.jb2011.lnf.beautyeye.ch20_filechooser;
/*     */ 
/*     */ import com.sun.java.swing.plaf.windows.WindowsFileChooserUI;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JViewport;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ 
/*     */ public class BEFileChooserUIWin extends WindowsFileChooserUI
/*     */ {
/*     */   public BEFileChooserUIWin(JFileChooser filechooser)
/*     */   {
/*  49 */     super(filechooser);
/*     */   }
/*     */ 
/*     */   public static ComponentUI createUI(JComponent c)
/*     */   {
/*  63 */     return new BEFileChooserUIWin((JFileChooser)c);
/*     */   }
/*     */ 
/*     */   public void paint(Graphics g, JComponent c)
/*     */   {
/*  75 */     g.setColor(c.getBackground());
/*  76 */     g.fillRect(0, 0, c.getWidth(), c.getHeight());
/*     */   }
/*     */ 
/*     */   protected JPanel createList(JFileChooser fc)
/*     */   {
/*  94 */     JPanel p = super.createList(fc);
/*     */ 
/*  98 */     if (p.getComponentCount() > 0)
/*     */     {
/* 100 */       Component scollPane = p.getComponent(0);
/* 101 */       if ((scollPane != null) && ((scollPane instanceof JScrollPane)))
/*     */       {
/* 103 */         JViewport vp = ((JScrollPane)scollPane).getViewport();
/* 104 */         if (vp != null)
/*     */         {
/* 106 */           Component fileListView = vp.getView();
/*     */ 
/* 108 */           if ((fileListView != null) && ((fileListView instanceof JList)))
/*     */           {
/* 122 */             ((JList)fileListView).setFixedCellHeight(-1);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 128 */     return p;
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch20_filechooser.BEFileChooserUIWin
 * JD-Core Version:    0.6.2
 */