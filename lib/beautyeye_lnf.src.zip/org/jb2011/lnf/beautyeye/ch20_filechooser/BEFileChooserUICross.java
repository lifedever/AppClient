/*     */ package org.jb2011.lnf.beautyeye.ch20_filechooser;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JViewport;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.metal.MetalFileChooserUI;
/*     */ 
/*     */ public class BEFileChooserUICross extends MetalFileChooserUI
/*     */ {
/*     */   public BEFileChooserUICross(JFileChooser filechooser)
/*     */   {
/*  43 */     super(filechooser);
/*     */   }
/*     */ 
/*     */   public static ComponentUI createUI(JComponent c)
/*     */   {
/*  57 */     return new BEFileChooserUICross((JFileChooser)c);
/*     */   }
/*     */ 
/*     */   protected JPanel createList(JFileChooser fc)
/*     */   {
/*  75 */     JPanel p = super.createList(fc);
/*     */ 
/*  79 */     if (p.getComponentCount() > 0)
/*     */     {
/*  81 */       Component scollPane = p.getComponent(0);
/*  82 */       if ((scollPane != null) && ((scollPane instanceof JScrollPane)))
/*     */       {
/*  84 */         JViewport vp = ((JScrollPane)scollPane).getViewport();
/*  85 */         if (vp != null)
/*     */         {
/*  87 */           Component fileListView = vp.getView();
/*     */ 
/*  89 */           if ((fileListView != null) && ((fileListView instanceof JList)))
/*     */           {
/* 103 */             ((JList)fileListView).setFixedCellHeight(-1);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 109 */     return p;
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch20_filechooser.BEFileChooserUICross
 * JD-Core Version:    0.6.2
 */