/*    */ package org.jb2011.lnf.beautyeye.ch20_filechooser;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.plaf.BorderUIResource;
/*    */ import javax.swing.plaf.ColorUIResource;
/*    */ import org.jb2011.lnf.beautyeye.ch4_scroll.ScrollPaneBorder;
/*    */ 
/*    */ public class __UI__
/*    */ {
/*    */   public static void uiImpl()
/*    */   {
/* 31 */     UIManager.put("FileChooser.listViewBorder", 
/* 32 */       new BorderUIResource(new ScrollPaneBorder()));
/*    */ 
/* 34 */     UIManager.put("ToolBar.shadow", new ColorUIResource(new Color(249, 248, 243)));
/*    */   }
/*    */ 
/*    */   public static void uiImpl_win()
/*    */   {
/* 44 */     UIManager.put("FileChooserUI", 
/* 45 */       BEFileChooserUIWin.class.getName());
/*    */   }
/*    */ 
/*    */   public static void uiImpl_cross()
/*    */   {
/* 54 */     UIManager.put("FileChooserUI", 
/* 55 */       BEFileChooserUICross.class.getName());
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch20_filechooser.__UI__
 * JD-Core Version:    0.6.2
 */