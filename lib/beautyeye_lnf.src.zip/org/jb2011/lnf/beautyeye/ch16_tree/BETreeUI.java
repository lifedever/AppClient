/*     */ package org.jb2011.lnf.beautyeye.ch16_tree;
/*     */ 
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicTreeUI;
/*     */ import javax.swing.tree.DefaultTreeCellRenderer;
/*     */ import javax.swing.tree.TreeCellRenderer;
/*     */ 
/*     */ public class BETreeUI extends BasicTreeUI
/*     */ {
/*     */   public static ComponentUI createUI(JComponent c)
/*     */   {
/*  42 */     return new BETreeUI();
/*     */   }
/*     */ 
/*     */   protected TreeCellRenderer createDefaultCellRenderer()
/*     */   {
/* 108 */     return new WindowsTreeCellRenderer();
/*     */   }
/*     */ 
/*     */   public class WindowsTreeCellRenderer extends DefaultTreeCellRenderer
/*     */   {
/*     */     public WindowsTreeCellRenderer()
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch16_tree.BETreeUI
 * JD-Core Version:    0.6.2
 */