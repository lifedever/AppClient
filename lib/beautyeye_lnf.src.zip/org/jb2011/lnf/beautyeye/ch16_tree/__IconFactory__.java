/*     */ package org.jb2011.lnf.beautyeye.ch16_tree;
/*     */ 
/*     */ import javax.swing.ImageIcon;
/*     */ import org.jb2011.lnf.beautyeye.utils.RawCache;
/*     */ 
/*     */ public class __IconFactory__ extends RawCache<ImageIcon>
/*     */ {
/*     */   public static final String IMGS_ROOT = "imgs";
/*  31 */   private static __IconFactory__ instance = null;
/*     */ 
/*     */   public static __IconFactory__ getInstance()
/*     */   {
/*  40 */     if (instance == null)
/*  41 */       instance = new __IconFactory__();
/*  42 */     return instance;
/*     */   }
/*     */ 
/*     */   protected ImageIcon getResource(String relativePath, Class baseClass)
/*     */   {
/*  51 */     return new ImageIcon(baseClass.getResource(relativePath));
/*     */   }
/*     */ 
/*     */   public ImageIcon getImage(String relativePath)
/*     */   {
/*  62 */     return (ImageIcon)getRaw(relativePath, getClass());
/*     */   }
/*     */ 
/*     */   public ImageIcon getTreeDefaultOpenIcon_16_16()
/*     */   {
/*  72 */     return getImage("imgs/treeDefaultOpen1.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getTreeDefaultClosedIcon_16_16()
/*     */   {
/*  82 */     return getImage("imgs/treeDefaultClosed1.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getTreeDefaultLeafIcon_16_16()
/*     */   {
/*  92 */     return getImage("imgs/leaf1.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getTreeA()
/*     */   {
/* 102 */     return getImage("imgs/a.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getTreeB()
/*     */   {
/* 112 */     return getImage("imgs/b.png");
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch16_tree.__IconFactory__
 * JD-Core Version:    0.6.2
 */