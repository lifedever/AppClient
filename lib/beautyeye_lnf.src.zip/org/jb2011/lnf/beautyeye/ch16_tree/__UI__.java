/*    */ package org.jb2011.lnf.beautyeye.ch16_tree;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import javax.swing.BorderFactory;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.plaf.BorderUIResource;
/*    */ import javax.swing.plaf.ColorUIResource;
/*    */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*    */ 
/*    */ public class __UI__
/*    */ {
/*    */   public static void uiImpl()
/*    */   {
/* 34 */     UIManager.put("Tree.background", new ColorUIResource(Color.white));
/* 35 */     UIManager.put("Tree.textBackground", new ColorUIResource(Color.white));
/*    */ 
/* 37 */     UIManager.put("Tree.selectionForeground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionForegroundColor));
/* 38 */     UIManager.put("Tree.selectionBackground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionBackgroundColor));
/* 39 */     UIManager.put("Tree.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/* 40 */     UIManager.put("Tree.selectionBorderColor", new ColorUIResource(BeautyEyeLNFHelper.commonFocusedBorderColor));
/*    */ 
/* 42 */     UIManager.put("Tree.openIcon", __IconFactory__.getInstance().getTreeDefaultOpenIcon_16_16());
/* 43 */     UIManager.put("Tree.closedIcon", __IconFactory__.getInstance().getTreeDefaultClosedIcon_16_16());
/* 44 */     UIManager.put("Tree.leafIcon", __IconFactory__.getInstance().getTreeDefaultLeafIcon_16_16());
/* 45 */     UIManager.put("Tree.expandedIcon", __IconFactory__.getInstance().getTreeA());
/*    */ 
/* 47 */     UIManager.put("Tree.collapsedIcon", __IconFactory__.getInstance().getTreeB());
/*    */ 
/* 51 */     UIManager.put("Tree.paintLines", Boolean.valueOf(false));
/*    */ 
/* 53 */     UIManager.put("Tree.rowHeight", Integer.valueOf(18));
/*    */ 
/* 55 */     UIManager.put("Tree.textForeground", new ColorUIResource(70, 70, 70));
/*    */ 
/* 58 */     UIManager.put("Tree.editorBorder", 
/* 59 */       new BorderUIResource(BorderFactory.createEmptyBorder(1, 5, 1, 5)));
/*    */ 
/* 61 */     UIManager.put("TreeUI", BETreeUI.class.getName());
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch16_tree.__UI__
 * JD-Core Version:    0.6.2
 */