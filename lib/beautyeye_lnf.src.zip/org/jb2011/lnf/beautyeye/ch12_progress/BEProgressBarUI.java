/*     */ package org.jb2011.lnf.beautyeye.ch12_progress;
/*     */ 
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JProgressBar;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.basic.BasicProgressBarUI;
/*     */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.__UseParentPaintSurported;
/*     */ import org.jb2011.lnf.beautyeye.utils.ReflectHelper;
/*     */ import org.jb2011.lnf.beautyeye.winlnfutils.WinUtils;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class BEProgressBarUI extends BasicProgressBarUI
/*     */   implements BeautyEyeLNFHelper.__UseParentPaintSurported
/*     */ {
/*     */   public static ComponentUI createUI(JComponent x)
/*     */   {
/*  47 */     return new BEProgressBarUI();
/*     */   }
/*     */ 
/*     */   public boolean isUseParentPaint()
/*     */   {
/*  66 */     return (this.progressBar != null) && (
/*  65 */       (!(this.progressBar.getForeground() instanceof UIResource)) || 
/*  66 */       (!(this.progressBar.getBackground() instanceof UIResource)));
/*     */   }
/*     */ 
/*     */   protected void paintDeterminate(Graphics g, JComponent c)
/*     */   {
/*  85 */     if (!(g instanceof Graphics2D))
/*     */     {
/*  87 */       return;
/*     */     }
/*     */ 
/*  91 */     if (isUseParentPaint())
/*     */     {
/*  93 */       super.paintDeterminate(g, c);
/*  94 */       return;
/*     */     }
/*     */ 
/*  97 */     Insets b = this.progressBar.getInsets();
/*  98 */     int barRectWidth = this.progressBar.getWidth() - (b.right + b.left);
/*  99 */     int barRectHeight = this.progressBar.getHeight() - (b.top + b.bottom);
/*     */ 
/* 103 */     paintProgressBarBgImpl(this.progressBar.getOrientation() == 0, 
/* 104 */       g, b, barRectWidth, barRectHeight);
/*     */ 
/* 107 */     if ((barRectWidth <= 0) || (barRectHeight <= 0))
/*     */     {
/* 109 */       return;
/*     */     }
/*     */ 
/* 112 */     int amountFull = getAmountFull(b, barRectWidth, barRectHeight);
/* 113 */     Graphics2D g2 = (Graphics2D)g;
/* 114 */     g2.setColor(this.progressBar.getForeground());
/*     */ 
/* 116 */     if (this.progressBar.getOrientation() == 0)
/*     */     {
/* 118 */       if (WinUtils.isLeftToRight(c))
/*     */       {
/* 120 */         paintProgressBarContentImpl(true, g, b.left, b.top, 
/* 121 */           amountFull, barRectHeight, -1);
/*     */       }
/*     */       else
/*     */       {
/* 126 */         paintProgressBarContentImpl(true, g, barRectWidth + b.left, b.top, 
/* 127 */           barRectWidth + b.left - amountFull, barRectHeight, -1);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 132 */       paintProgressBarContentImpl(false, g, b.left, b.top + barRectHeight - amountFull, 
/* 133 */         barRectWidth, amountFull, barRectHeight);
/*     */     }
/*     */ 
/* 137 */     if (this.progressBar.isStringPainted())
/*     */     {
/* 139 */       paintString(g, b.left, b.top, barRectWidth, barRectHeight, amountFull, b);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void paintIndeterminate(Graphics g, JComponent c)
/*     */   {
/* 158 */     if (!(g instanceof Graphics2D))
/*     */     {
/* 160 */       return;
/*     */     }
/*     */ 
/* 164 */     if (isUseParentPaint())
/*     */     {
/* 166 */       super.paintIndeterminate(g, c);
/* 167 */       return;
/*     */     }
/*     */ 
/* 170 */     Insets b = this.progressBar.getInsets();
/* 171 */     int barRectWidth = this.progressBar.getWidth() - (b.right + b.left);
/* 172 */     int barRectHeight = this.progressBar.getHeight() - (b.top + b.bottom);
/*     */ 
/* 174 */     if ((barRectWidth <= 0) || (barRectHeight <= 0)) {
/* 175 */       return;
/*     */     }
/*     */ 
/* 180 */     paintProgressBarBgImpl(this.progressBar.getOrientation() == 0, g, b, barRectWidth, barRectHeight);
/*     */ 
/* 183 */     Graphics2D g2 = (Graphics2D)g;
/*     */ 
/* 186 */     this.boxRect = getBox(this.boxRect);
/* 187 */     if (this.boxRect != null)
/*     */     {
/* 189 */       g2.setColor(this.progressBar.getForeground());
/*     */ 
/* 192 */       paintProgressBarContentImpl(this.progressBar.getOrientation() == 0, 
/* 193 */         g, this.boxRect.x, this.boxRect.y, this.boxRect.width, this.boxRect.height, this.boxRect.height);
/*     */     }
/*     */ 
/* 197 */     if (this.progressBar.isStringPainted())
/*     */     {
/* 199 */       if (this.progressBar.getOrientation() == 0)
/*     */       {
/* 201 */         paintString(g2, b.left, b.top, barRectWidth, barRectHeight, this.boxRect.x, this.boxRect.width, b);
/*     */       }
/*     */       else
/*     */       {
/* 205 */         paintString(g2, b.left, b.top, barRectWidth, barRectHeight, this.boxRect.y, this.boxRect.height, b);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void paintProgressBarContentImpl(boolean isHorizontal, Graphics g, int x, int y, int amountFull, int barContentRectHeight, int barSumHeightForVertival)
/*     */   {
/* 232 */     int n9min = 17;
/*     */     NinePatch np;
/*     */     NinePatch np;
/* 233 */     if (isHorizontal)
/*     */     {
/* 236 */       if ((amountFull > 0) && (amountFull < 17))
/*     */       {
/* 238 */         amountFull = 17;
/*     */       }
/* 240 */       np = __Icon9Factory__.getInstance().getProgressBar_green();
/*     */     }
/*     */     else
/*     */     {
/* 245 */       if ((barContentRectHeight > 0) && (barContentRectHeight < 17))
/*     */       {
/* 247 */         y = barSumHeightForVertival - 17;
/* 248 */         barContentRectHeight = 17;
/*     */       }
/* 250 */       np = __Icon9Factory__.getInstance().getProgressBar_blue_v();
/*     */     }
/*     */ 
/* 253 */     np.draw((Graphics2D)g, x, y, amountFull, barContentRectHeight);
/*     */   }
/*     */ 
/*     */   protected void paintProgressBarBgImpl(boolean isHorizontal, Graphics g, Insets b, int barRectWidth, int barRectHeight)
/*     */   {
/*     */     NinePatch np;
/*     */     NinePatch np;
/* 269 */     if (isHorizontal)
/* 270 */       np = __Icon9Factory__.getInstance().getProgressBarBg();
/*     */     else
/* 272 */       np = __Icon9Factory__.getInstance().getProgressBarBg_v();
/* 273 */     np.draw((Graphics2D)g, b.left, b.top, barRectWidth, barRectHeight);
/*     */   }
/*     */ 
/*     */   private void paintString(Graphics g, int x, int y, int width, int height, int fillStart, int amountFull, Insets b)
/*     */   {
/* 298 */     ReflectHelper.invokeMethod(BasicProgressBarUI.class, this, "paintString", 
/* 299 */       new Class[] { Graphics.class, Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE, Insets.class }, 
/* 300 */       new Object[] { g, Integer.valueOf(x), Integer.valueOf(y), Integer.valueOf(width), Integer.valueOf(height), Integer.valueOf(fillStart), Integer.valueOf(amountFull), b });
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch12_progress.BEProgressBarUI
 * JD-Core Version:    0.6.2
 */