/*    */ package org.jb2011.lnf.beautyeye.ch12_progress;
/*    */ 
/*    */ import javax.swing.BorderFactory;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.plaf.BorderUIResource;
/*    */ import javax.swing.plaf.ColorUIResource;
/*    */ import javax.swing.plaf.DimensionUIResource;
/*    */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*    */ 
/*    */ public class __UI__
/*    */ {
/*    */   public static void uiImpl()
/*    */   {
/* 33 */     UIManager.put("ProgressBar.background", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/* 34 */     UIManager.put("ProgressBar.selectionForeground", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/*    */ 
/* 37 */     UIManager.put("ProgressBar.horizontalSize", new DimensionUIResource(146, 15));
/*    */ 
/* 40 */     UIManager.put("ProgressBar.verticalSize", new DimensionUIResource(15, 146));
/* 41 */     UIManager.put("ProgressBar.border", new BorderUIResource(BorderFactory.createEmptyBorder(0, 0, 0, 0)));
/* 42 */     UIManager.put("ProgressBarUI", BEProgressBarUI.class.getName());
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch12_progress.__UI__
 * JD-Core Version:    0.6.2
 */