/*     */ package org.jb2011.lnf.beautyeye.ch18_spinner;
/*     */ 
/*     */ import org.jb2011.lnf.beautyeye.utils.NinePatchHelper;
/*     */ import org.jb2011.lnf.beautyeye.utils.RawCache;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class __Icon9Factory__ extends RawCache<NinePatch>
/*     */ {
/*     */   public static final String IMGS_ROOT = "imgs/np";
/*  30 */   private static __Icon9Factory__ instance = null;
/*     */ 
/*     */   public static __Icon9Factory__ getInstance()
/*     */   {
/*  39 */     if (instance == null)
/*  40 */       instance = new __Icon9Factory__();
/*  41 */     return instance;
/*     */   }
/*     */ 
/*     */   protected NinePatch getResource(String relativePath, Class baseClass)
/*     */   {
/*  50 */     return NinePatchHelper.createNinePatch(baseClass.getResource(relativePath), false);
/*     */   }
/*     */ 
/*     */   public NinePatch getRaw(String relativePath)
/*     */   {
/*  61 */     return (NinePatch)getRaw(relativePath, getClass());
/*     */   }
/*     */ 
/*     */   public NinePatch getSpinnerBg()
/*     */   {
/*  71 */     return getRaw("imgs/np/spinner1_bg.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getUpButtonBg()
/*     */   {
/*  81 */     return getRaw("imgs/np/spinner1_btn_up_bg.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getDownButtonBg()
/*     */   {
/*  91 */     return getRaw("imgs/np/spinner1_btn_down_bg.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getSpinnerDisableBg()
/*     */   {
/* 101 */     return getRaw("imgs/np/spinner1_disable_bg.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getUpButtonBg_pressed()
/*     */   {
/* 111 */     return getRaw("imgs/np/spinner1_btn_up_pressed_bg.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getDownButtonBg_pressed()
/*     */   {
/* 121 */     return getRaw("imgs/np/spinner1_btn_down_pressed_bg.9.png");
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch18_spinner.__Icon9Factory__
 * JD-Core Version:    0.6.2
 */