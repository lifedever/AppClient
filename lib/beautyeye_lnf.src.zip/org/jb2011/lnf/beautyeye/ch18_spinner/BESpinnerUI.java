/*     */ package org.jb2011.lnf.beautyeye.ch18_spinner;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicSpinnerUI;
/*     */ import org.jb2011.lnf.beautyeye.utils.BEUtils;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class BESpinnerUI extends BasicSpinnerUI
/*     */ {
/*     */   public static ComponentUI createUI(JComponent c)
/*     */   {
/*  48 */     return new BESpinnerUI();
/*     */   }
/*     */ 
/*     */   protected JComponent createEditor()
/*     */   {
/*  56 */     JComponent e = super.createEditor();
/*  57 */     e.setOpaque(false);
/*     */ 
/*  63 */     Component[] childs = e.getComponents();
/*  64 */     BEUtils.componentsOpaque(childs, false);
/*     */ 
/*  66 */     return e;
/*     */   }
/*     */ 
/*     */   public void paint(Graphics g, JComponent c)
/*     */   {
/*  80 */     paintXPBackground(g, c);
/*     */ 
/*  82 */     super.paint(g, c);
/*     */   }
/*     */ 
/*     */   private void paintXPBackground(Graphics g, JComponent c)
/*     */   {
/* 108 */     if ((this.spinner != null) && (!this.spinner.isEnabled()))
/* 109 */       __Icon9Factory__.getInstance().getSpinnerDisableBg()
/* 110 */         .draw((Graphics2D)g, 0, 0, c.getWidth(), c.getHeight());
/*     */     else
/* 112 */       __Icon9Factory__.getInstance().getSpinnerBg()
/* 113 */         .draw((Graphics2D)g, 0, 0, c.getWidth(), c.getHeight());
/*     */   }
/*     */ 
/*     */   protected Component createPreviousButton()
/*     */   {
/* 122 */     JButton xpButton = new GlyphButton(this.spinner, BESpinnerUI.GlyphButton.Type.down);
/* 123 */     Dimension size = UIManager.getDimension("Spinner.arrowButtonSize");
/* 124 */     xpButton.setPreferredSize(size);
/* 125 */     xpButton.setRequestFocusEnabled(false);
/* 126 */     installPreviousButtonListeners(xpButton);
/* 127 */     return xpButton;
/*     */   }
/*     */ 
/*     */   protected Component createNextButton()
/*     */   {
/* 138 */     JButton xpButton = new GlyphButton(this.spinner, BESpinnerUI.GlyphButton.Type.up);
/* 139 */     Dimension size = UIManager.getDimension("Spinner.arrowButtonSize");
/* 140 */     xpButton.setPreferredSize(size);
/* 141 */     xpButton.setRequestFocusEnabled(false);
/* 142 */     installNextButtonListeners(xpButton);
/* 143 */     return xpButton;
/*     */   }
/*     */ 
/*     */   static class GlyphButton extends JButton
/*     */   {
/* 155 */     private Type type = null;
/*     */ 
/*     */     public GlyphButton(Component parent, Type type)
/*     */     {
/* 179 */       this.type = type;
/* 180 */       setBorder(null);
/* 181 */       setContentAreaFilled(false);
/* 182 */       setMinimumSize(new Dimension(5, 5));
/* 183 */       setPreferredSize(new Dimension(16, 16));
/* 184 */       setMaximumSize(new Dimension(2147483647, 2147483647));
/*     */     }
/*     */ 
/*     */     public boolean isFocusTraversable()
/*     */     {
/* 191 */       return false;
/*     */     }
/*     */ 
/*     */     public void paintComponent(Graphics g)
/*     */     {
/* 210 */       Dimension d = getSize();
/*     */ 
/* 215 */       if (this.type == Type.up)
/*     */       {
/* 217 */         if ((!isEnabled()) || (getModel().isPressed()))
/* 218 */           __Icon9Factory__.getInstance().getUpButtonBg_pressed()
/* 219 */             .draw((Graphics2D)g, 0, 0, d.width, d.height);
/*     */         else
/* 221 */           __Icon9Factory__.getInstance().getUpButtonBg()
/* 222 */             .draw((Graphics2D)g, 0, 0, d.width, d.height);
/*     */       }
/* 224 */       else if (this.type == Type.down)
/*     */       {
/* 226 */         if ((!isEnabled()) || (getModel().isPressed()))
/* 227 */           __Icon9Factory__.getInstance().getDownButtonBg_pressed()
/* 228 */             .draw((Graphics2D)g, 0, 0, d.width, d.height);
/*     */         else
/* 230 */           __Icon9Factory__.getInstance().getDownButtonBg()
/* 231 */             .draw((Graphics2D)g, 0, 0, d.width, d.height);
/*     */       }
/*     */     }
/*     */ 
/*     */     protected void paintBorder(Graphics g)
/*     */     {
/*     */     }
/*     */ 
/*     */     public static enum Type
/*     */     {
/* 164 */       down, 
/*     */ 
/* 167 */       up;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch18_spinner.BESpinnerUI
 * JD-Core Version:    0.6.2
 */