/*    */ package org.jb2011.lnf.beautyeye.ch18_spinner;
/*    */ 
/*    */ import java.awt.Dimension;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.border.EmptyBorder;
/*    */ import javax.swing.plaf.BorderUIResource;
/*    */ import javax.swing.plaf.ColorUIResource;
/*    */ import javax.swing.plaf.InsetsUIResource;
/*    */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*    */ 
/*    */ public class __UI__
/*    */ {
/*    */   public static void uiImpl()
/*    */   {
/* 35 */     UIManager.put("Spinner.background", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/* 36 */     UIManager.put("Spinner.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/* 37 */     UIManager.put("SpinnerUI", BESpinnerUI.class.getName());
/*    */ 
/* 40 */     UIManager.put("Spinner.border", new BorderUIResource(new EmptyBorder(5, 5, 10, 5)));
/*    */ 
/* 42 */     UIManager.put("Spinner.arrowButtonInsets", new InsetsUIResource(1, 0, 2, 2));
/*    */ 
/* 44 */     UIManager.put("Spinner.arrowButtonSize", new Dimension(17, 9));
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch18_spinner.__UI__
 * JD-Core Version:    0.6.2
 */