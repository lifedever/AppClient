/*    */ package org.jb2011.lnf.beautyeye.ch5_table;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.border.AbstractBorder;
/*    */ import org.jb2011.lnf.beautyeye.utils.BEUtils;
/*    */ 
/*    */ class FocusCellHighlightBorder extends AbstractBorder
/*    */ {
/*    */   public Insets getBorderInsets(Component c)
/*    */   {
/* 39 */     return new Insets(2, 2, 2, 2);
/*    */   }
/*    */ 
/*    */   public Insets getBorderInsets(Component c, Insets insets)
/*    */   {
/* 47 */     return getBorderInsets(c);
/*    */   }
/*    */ 
/*    */   public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/*    */   {
/* 66 */     BEUtils.draw4RecCorner(g, x, y, width - 2, height - 2, 5, 
/* 67 */       UIManager.getColor("Table.focusCellHighlightBorderColor"));
/* 68 */     BEUtils.draw4RecCorner(g, x + 1, y + 1, width - 2, height - 2, 5, 
/* 69 */       UIManager.getColor("Table.focusCellHighlightBorderHighlightColor"));
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch5_table.FocusCellHighlightBorder
 * JD-Core Version:    0.6.2
 */