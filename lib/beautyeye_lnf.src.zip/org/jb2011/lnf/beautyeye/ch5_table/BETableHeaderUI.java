/*     */ package org.jb2011.lnf.beautyeye.ch5_table;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.SortOrder;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.basic.BasicTableHeaderUI;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import org.jb2011.lnf.beautyeye.utils.ReflectHelper;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ import sun.swing.table.DefaultTableCellHeaderRenderer;
/*     */ 
/*     */ public class BETableHeaderUI extends BasicTableHeaderUI
/*     */ {
/*     */   private TableCellRenderer originalHeaderRenderer;
/*     */ 
/*     */   public static ComponentUI createUI(JComponent h)
/*     */   {
/*  62 */     return new BETableHeaderUI();
/*     */   }
/*     */ 
/*     */   public void installUI(JComponent c)
/*     */   {
/*  70 */     super.installUI(c);
/*     */ 
/*  73 */     this.originalHeaderRenderer = this.header.getDefaultRenderer();
/*  74 */     if ((this.originalHeaderRenderer instanceof UIResource))
/*     */     {
/*  76 */       this.header.setDefaultRenderer(new XPDefaultRenderer());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void uninstallUI(JComponent c)
/*     */   {
/*  86 */     if ((this.header.getDefaultRenderer() instanceof XPDefaultRenderer))
/*     */     {
/*  88 */       this.header.setDefaultRenderer(this.originalHeaderRenderer);
/*     */     }
/*  90 */     super.uninstallUI(c);
/*     */   }
/*     */ 
/*     */   protected void rolloverColumnUpdated(int oldColumn, int newColumn)
/*     */   {
/* 101 */     this.header.repaint(this.header.getHeaderRect(oldColumn));
/* 102 */     this.header.repaint(this.header.getHeaderRect(newColumn));
/*     */   }
/*     */ 
/*     */   public static void paintHeadCell(Graphics g, Dimension headCellSize)
/*     */   {
/* 115 */     int w = headCellSize.width; int h = headCellSize.height - 1;
/*     */ 
/* 136 */     __Icon9Factory__.getInstance().getTableHeaderCellBg1()
/* 137 */       .draw((Graphics2D)g, 0, 0, w, h);
/* 138 */     __Icon9Factory__.getInstance().getTableHeaderCellSeparator1()
/* 139 */       .draw((Graphics2D)g, w - 2, 0, 4, h - 1);
/*     */   }
/*     */ 
/*     */   private static class IconBorder
/*     */     implements Border, UIResource
/*     */   {
/*     */     private final Icon icon;
/*     */     private final int top;
/*     */     private final int left;
/*     */     private final int bottom;
/*     */     private final int right;
/*     */ 
/*     */     public IconBorder(Icon icon, int top, int left, int bottom, int right)
/*     */     {
/* 376 */       this.icon = icon;
/* 377 */       this.top = top;
/* 378 */       this.left = left;
/* 379 */       this.bottom = bottom;
/* 380 */       this.right = right;
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c)
/*     */     {
/* 391 */       return new Insets(this.top, this.left, this.bottom, this.right);
/*     */     }
/*     */ 
/*     */     public boolean isBorderOpaque()
/*     */     {
/* 399 */       return false;
/*     */     }
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/*     */     {
/* 407 */       this.icon.paintIcon(c, g, 
/* 413 */         x + this.left + width - this.right - this.icon.getIconWidth() - 2, y);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class XPDefaultRenderer extends DefaultTableCellHeaderRenderer
/*     */   {
/*     */     XPDefaultRenderer()
/*     */     {
/* 156 */       setHorizontalAlignment(10);
/* 157 */       setVerticalAlignment(0);
/*     */     }
/*     */ 
/*     */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
/*     */     {
/* 169 */       super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
/*     */ 
/* 179 */       Insets margins = UIManager.getInsets("TableHeader.cellMargin");
/* 180 */       Border border = null;
/* 181 */       int contentTop = 0;
/* 182 */       int contentLeft = 0;
/* 183 */       int contentBottom = 0;
/* 184 */       int contentRight = 0;
/* 185 */       if (margins != null)
/*     */       {
/* 187 */         contentTop = margins.top;
/* 188 */         contentLeft = margins.left;
/* 189 */         contentBottom = margins.bottom;
/* 190 */         contentRight = margins.right;
/*     */       }
/*     */ 
/* 198 */       contentLeft += 5;
/* 199 */       contentBottom += 4;
/* 200 */       contentRight += 5;
/*     */       Icon sortIcon;
/* 216 */       if ((((sortIcon = getIcon()) instanceof UIResource)) || (sortIcon == null))
/*     */       {
/* 222 */         setIcon(null);
/* 223 */         sortIcon = null;
/*     */ 
/* 229 */         SortOrder sortOrder = (SortOrder)ReflectHelper.invokeMethod(DefaultTableCellHeaderRenderer.class, 
/* 230 */           this, "getColumnSortOrder", 
/* 231 */           new Class[] { JTable.class, Integer.TYPE }, new Object[] { table, Integer.valueOf(column) });
/* 232 */         if (sortOrder != null)
/*     */         {
/* 234 */           switch (sortOrder)
/*     */           {
/*     */           case ASCENDING:
/* 237 */             sortIcon = 
/* 238 */               UIManager.getIcon("Table.ascendingSortIcon");
/* 239 */             break;
/*     */           case DESCENDING:
/* 241 */             sortIcon = 
/* 242 */               UIManager.getIcon("Table.descendingSortIcon");
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 247 */         if (sortIcon != null)
/*     */         {
/* 251 */           border = new BETableHeaderUI.IconBorder(sortIcon, contentTop, contentLeft, 
/* 252 */             contentBottom, contentRight);
/*     */         }
/*     */         else
/*     */         {
/* 256 */           sortIcon = UIManager.getIcon("Table.ascendingSortIcon");
/* 257 */           int sortIconHeight = sortIcon != null ? sortIcon.getIconHeight() : 0;
/*     */ 
/* 263 */           border = new EmptyBorder(
/* 267 */             contentTop, contentLeft, contentBottom, contentRight);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 272 */         contentTop += 3;
/* 273 */         border = new EmptyBorder(contentTop, contentLeft, contentBottom, contentRight);
/*     */       }
/* 275 */       setBorder(border);
/*     */ 
/* 282 */       return this;
/*     */     }
/*     */ 
/*     */     public void paint(Graphics g)
/*     */     {
/* 290 */       Dimension size = getSize();
/*     */ 
/* 335 */       BETableHeaderUI.paintHeadCell(g, size);
/*     */ 
/* 338 */       super.paint(g);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch5_table.BETableHeaderUI
 * JD-Core Version:    0.6.2
 */