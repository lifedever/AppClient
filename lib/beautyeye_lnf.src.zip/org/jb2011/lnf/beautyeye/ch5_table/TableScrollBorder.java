/*    */ package org.jb2011.lnf.beautyeye.ch5_table;
/*    */ 
/*    */ import java.awt.Insets;
/*    */ import org.jb2011.lnf.beautyeye.widget.border.NinePatchBorder;
/*    */ 
/*    */ class TableScrollBorder extends NinePatchBorder
/*    */ {
/*    */   public TableScrollBorder()
/*    */   {
/* 33 */     super(new Insets(3, 5, 10, 5), 
/* 33 */       __Icon9Factory__.getInstance().getTableScrollBorder1());
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch5_table.TableScrollBorder
 * JD-Core Version:    0.6.2
 */