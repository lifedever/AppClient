/*     */ package org.jb2011.lnf.beautyeye.ch5_table;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.AbstractBorder;
/*     */ import javax.swing.plaf.BorderUIResource;
/*     */ import javax.swing.plaf.ColorUIResource;
/*     */ import javax.swing.plaf.InsetsUIResource;
/*     */ import javax.swing.plaf.basic.BasicTableHeaderUI;
/*     */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*     */ import org.jb2011.lnf.beautyeye.ch_x.__IconFactory__;
/*     */ import org.jb2011.lnf.beautyeye.utils.JVM;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class __UI__
/*     */ {
/*     */   public static void uiImpl()
/*     */   {
/*  42 */     UIManager.put("Table.scrollPaneBorder", new BorderUIResource(new TableScrollBorder()));
/*  43 */     UIManager.put("Table.focusCellHighlightBorder", new BorderUIResource(new FocusCellHighlightBorder()));
/*     */ 
/*  45 */     UIManager.put("Table.focusCellHighlightBorderColor", new ColorUIResource(Color.white));
/*     */ 
/*  47 */     UIManager.put("Table.focusCellHighlightBorderHighlightColor", 
/*  48 */       new ColorUIResource(new Color(255, 255, 255, 70)));
/*  49 */     UIManager.put("Table.background", new ColorUIResource(Color.white));
/*     */ 
/*  51 */     UIManager.put("Table.descendingSortIcon", __IconFactory__.getInstance().getTableDescendingSortIcon());
/*  52 */     UIManager.put("Table.ascendingSortIcon", __IconFactory__.getInstance().getTableAscendingSortIcon());
/*  53 */     UIManager.put("Table.selectionForeground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionForegroundColor));
/*  54 */     UIManager.put("Table.gridColor", new ColorUIResource(new Color(220, 220, 220)));
/*  55 */     UIManager.put("Table.selectionBackground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionBackgroundColor));
/*  56 */     UIManager.put("Table.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/*  57 */     UIManager.put("TableUI", BETableUI.class.getName());
/*     */ 
/*  61 */     UIManager.put("TableHeader.background", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/*  62 */     UIManager.put("TableHeader.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/*     */ 
/*  65 */     if (JVM.current().isOrLater(16))
/*     */     {
/*  70 */       UIManager.put("TableHeaderUI", "org.jb2011.lnf.beautyeye.ch5_table.BETableHeaderUI");
/*     */ 
/*  75 */       UIManager.put("TableHeader.cellMargin", new InsetsUIResource(7, 0, 7, 0));
/*     */     }
/*     */     else
/*     */     {
/*  81 */       UIManager.put("TableHeader.cellBorder", 
/*  83 */         new BorderUIResource(new TableHeaderBorder()));
/*     */ 
/*  85 */       UIManager.put("TableHeaderUI", BasicTableHeaderUI.class.getName());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class TableHeaderBorder extends AbstractBorder
/*     */   {
/*  97 */     protected Insets editorBorderInsets = new Insets(7, 0, 7, 0);
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/*     */     {
/* 104 */       g.translate(x, y);
/*     */ 
/* 115 */       g.setColor(UIManager.getColor("Table.gridColor"));
/* 116 */       g.drawLine(0, h - 1, w, h - 1);
/*     */ 
/* 119 */       __Icon9Factory__.getInstance().getTableHeaderCellSeparator1()
/* 120 */         .draw((Graphics2D)g, w - 4, 0, 4, h);
/*     */ 
/* 123 */       g.translate(-x, -y);
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c)
/*     */     {
/* 131 */       return this.editorBorderInsets;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch5_table.__UI__
 * JD-Core Version:    0.6.2
 */