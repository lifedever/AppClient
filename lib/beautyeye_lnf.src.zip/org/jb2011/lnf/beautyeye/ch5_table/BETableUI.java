/*    */ package org.jb2011.lnf.beautyeye.ch5_table;
/*    */ 
/*    */ import java.awt.Dimension;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.JTable;
/*    */ import javax.swing.UIDefaults;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.basic.BasicTableUI;
/*    */ 
/*    */ public class BETableUI extends BasicTableUI
/*    */ {
/*    */   UIDefaults defaultRenderersByColumnClass;
/*    */ 
/*    */   public static ComponentUI createUI(JComponent c)
/*    */   {
/* 40 */     return new BETableUI();
/*    */   }
/*    */ 
/*    */   protected void installDefaults()
/*    */   {
/* 54 */     super.installDefaults();
/*    */ 
/* 56 */     this.table.setRowHeight(25);
/*    */ 
/* 58 */     this.table.setShowVerticalLines(false);
/*    */ 
/* 63 */     this.table.setIntercellSpacing(new Dimension(0, 1));
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch5_table.BETableUI
 * JD-Core Version:    0.6.2
 */