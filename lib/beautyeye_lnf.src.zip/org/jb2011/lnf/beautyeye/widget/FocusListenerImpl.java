/*     */ package org.jb2011.lnf.beautyeye.widget;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.FocusListener;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JPasswordField;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.JTextPane;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import org.jb2011.lnf.beautyeye.ch6_textcoms.__UI__.BgSwitchable;
/*     */ import org.jb2011.lnf.beautyeye.utils.BEUtils;
/*     */ import org.jb2011.lnf.beautyeye.widget.border.BERoundBorder;
/*     */ 
/*     */ public class FocusListenerImpl
/*     */   implements FocusListener
/*     */ {
/*  45 */   public static int defaultFocusedThikness = 2;
/*     */ 
/*  59 */   protected int focusedThikness = defaultFocusedThikness;
/*     */ 
/*     */   public static FocusListenerImpl getInstance()
/*     */   {
/*  55 */     return new FocusListenerImpl();
/*     */   }
/*     */ 
/*     */   public int getFocusedThikness()
/*     */   {
/*  68 */     return this.focusedThikness;
/*     */   }
/*     */ 
/*     */   public FocusListenerImpl setFocusedThikness(int focusedThikness)
/*     */   {
/*  79 */     this.focusedThikness = focusedThikness;
/*  80 */     return this;
/*     */   }
/*     */ 
/*     */   public void focusGained(FocusEvent e)
/*     */   {
/*  88 */     if ((e.getSource() instanceof JComponent))
/*     */     {
/*  90 */       JComponent com = (JComponent)e.getSource();
/*  91 */       Border orignalBorder = com.getBorder();
/*     */ 
/*  93 */       if (orignalBorder != null)
/*     */       {
/*  96 */         Color focusedColor = getTextFieldFocusedColor();
/*     */ 
/*  99 */         if (((com instanceof JPasswordField)) || 
/* 100 */           ((com instanceof JTextField)))
/*     */         {
/* 104 */           ComponentUI ui = ((JTextField)com).getUI();
/* 105 */           if ((ui instanceof __UI__.BgSwitchable))
/*     */           {
/* 107 */             ((__UI__.BgSwitchable)ui).switchBgToFocused();
/* 108 */             com.repaint();
/* 109 */             return;
/*     */           }
/* 111 */           if ((ui instanceof __UI__.BgSwitchable))
/*     */           {
/* 113 */             ((__UI__.BgSwitchable)ui).switchBgToFocused();
/* 114 */             com.repaint();
/*     */           }
/*     */ 
/*     */         }
/* 118 */         else if ((com instanceof JTextArea))
/*     */         {
/* 121 */           ComponentUI ui = ((JTextArea)com).getUI();
/* 122 */           if ((ui instanceof __UI__.BgSwitchable))
/*     */           {
/* 124 */             ((__UI__.BgSwitchable)ui).switchBgToFocused();
/* 125 */             com.repaint();
/*     */           }
/*     */ 
/*     */         }
/* 129 */         else if ((com instanceof JTextPane))
/*     */         {
/* 132 */           ComponentUI ui = ((JTextPane)com).getUI();
/* 133 */           if ((ui instanceof __UI__.BgSwitchable))
/*     */           {
/* 135 */             ((__UI__.BgSwitchable)ui).switchBgToFocused();
/* 136 */             com.repaint();
/*     */           }
/*     */ 
/*     */         }
/* 140 */         else if ((com instanceof JEditorPane))
/*     */         {
/* 143 */           ComponentUI ui = ((JEditorPane)com).getUI();
/* 144 */           if ((ui instanceof __UI__.BgSwitchable))
/*     */           {
/* 146 */             ((__UI__.BgSwitchable)ui).switchBgToFocused();
/* 147 */             com.repaint();
/*     */           }
/*     */ 
/*     */         }
/* 152 */         else if ((com instanceof JComboBox)) {
/* 153 */           focusedColor = getComboBoxFocusedColor();
/*     */         }
/*     */         BERoundBorder cc;
/*     */         BERoundBorder cc;
/* 158 */         if ((orignalBorder instanceof BERoundBorder))
/* 159 */           cc = (BERoundBorder)((BERoundBorder)orignalBorder).clone();
/*     */         else
/* 161 */           cc = new BERoundBorder(1).setArcWidth(0);
/* 162 */         cc.setLineColor(focusedColor);
/* 163 */         cc.setThickness(this.focusedThikness);
/*     */ 
/* 167 */         Dimension oldDm = null;
/* 168 */         if ((com instanceof JTextField))
/* 169 */           oldDm = com.getSize();
/* 170 */         com.setBorder(cc);
/* 171 */         if ((com instanceof JTextField))
/* 172 */           com.setPreferredSize(oldDm);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void focusLost(FocusEvent e)
/*     */   {
/* 182 */     if ((e.getSource() instanceof JComponent))
/*     */     {
/* 184 */       JComponent com = (JComponent)e.getSource();
/*     */ 
/* 187 */       if (((com instanceof JPasswordField)) || ((com instanceof JTextField)))
/*     */       {
/* 190 */         ComponentUI ui = ((JTextField)com).getUI();
/* 191 */         if ((ui instanceof __UI__.BgSwitchable))
/*     */         {
/* 193 */           ((__UI__.BgSwitchable)ui).switchBgToNomal();
/* 194 */           com.repaint();
/* 195 */           return;
/*     */         }
/* 197 */         if ((ui instanceof __UI__.BgSwitchable))
/*     */         {
/* 199 */           ((__UI__.BgSwitchable)ui).switchBgToNomal();
/* 200 */           com.repaint();
/*     */         }
/*     */ 
/*     */       }
/* 204 */       else if ((com instanceof JTextArea))
/*     */       {
/* 206 */         ComponentUI ui = ((JTextArea)com).getUI();
/* 207 */         if ((ui instanceof __UI__.BgSwitchable))
/*     */         {
/* 209 */           ((__UI__.BgSwitchable)ui).switchBgToNomal();
/* 210 */           com.repaint();
/*     */         }
/*     */ 
/*     */       }
/* 214 */       else if ((com instanceof JTextPane))
/*     */       {
/* 216 */         ComponentUI ui = ((JTextPane)com).getUI();
/* 217 */         if ((ui instanceof __UI__.BgSwitchable))
/*     */         {
/* 219 */           ((__UI__.BgSwitchable)ui).switchBgToNomal();
/* 220 */           com.repaint();
/*     */         }
/*     */ 
/*     */       }
/* 224 */       else if ((com instanceof JEditorPane))
/*     */       {
/* 226 */         ComponentUI ui = ((JEditorPane)com).getUI();
/* 227 */         if ((ui instanceof __UI__.BgSwitchable))
/*     */         {
/* 229 */           ((__UI__.BgSwitchable)ui).switchBgToNomal();
/* 230 */           com.repaint();
/* 231 */           return;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 237 */       Border orignalBorder = com.getBorder();
/* 238 */       if ((orignalBorder != null) && 
/* 239 */         ((orignalBorder instanceof BERoundBorder)))
/*     */       {
/* 241 */         BERoundBorder cc = (BERoundBorder)((BERoundBorder)orignalBorder).clone();
/* 242 */         cc.setLineColor(BERoundBorder.defaultLineColor);
/* 243 */         cc.setThickness(1);
/* 244 */         com.setBorder(cc);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Color getTextFieldFocusedColor()
/*     */   {
/* 256 */     return BEUtils.getColor(UIManager.getColor("TextField.selectionBackground"), 30, 30, 30);
/*     */   }
/*     */ 
/*     */   public static Color getComboBoxFocusedColor()
/*     */   {
/* 273 */     return BEUtils.getColor(UIManager.getColor("ComboBox.selectionBackground"), 30, 30, 30);
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.widget.FocusListenerImpl
 * JD-Core Version:    0.6.2
 */