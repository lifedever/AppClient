/*     */ package org.jb2011.lnf.beautyeye.widget;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JPanel;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class ImageBgPanel extends JPanel
/*     */ {
/*  31 */   private boolean drawBg = true;
/*     */ 
/*  34 */   private NinePatch n9 = null;
/*     */ 
/*     */   public ImageBgPanel()
/*     */   {
/*  41 */     setOpaque(false);
/*     */   }
/*     */ 
/*     */   public void paintChildren(Graphics g)
/*     */   {
/*  49 */     if ((this.drawBg) && (this.n9 != null))
/*  50 */       this.n9.draw((Graphics2D)g, 0, 0, getWidth(), getHeight());
/*  51 */     super.paintChildren(g);
/*     */   }
/*     */ 
/*     */   protected void addImpl(Component comp, Object constraints, int index)
/*     */   {
/*  63 */     if ((comp != null) && ((comp instanceof JComponent)))
/*  64 */       ((JComponent)comp).setOpaque(false);
/*  65 */     super.addImpl(comp, constraints, index);
/*     */   }
/*     */ 
/*     */   public boolean isDrawBg()
/*     */   {
/*  75 */     return this.drawBg;
/*     */   }
/*     */ 
/*     */   public ImageBgPanel setDrawBg(boolean drawBg)
/*     */   {
/*  86 */     this.drawBg = drawBg;
/*  87 */     return this;
/*     */   }
/*     */ 
/*     */   public NinePatch getN9()
/*     */   {
/*  97 */     return this.n9;
/*     */   }
/*     */ 
/*     */   public ImageBgPanel setN9(NinePatch n9)
/*     */   {
/* 108 */     this.n9 = n9;
/* 109 */     return this;
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.widget.ImageBgPanel
 * JD-Core Version:    0.6.2
 */