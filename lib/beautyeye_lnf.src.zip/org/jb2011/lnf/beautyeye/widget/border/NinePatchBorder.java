/*    */ package org.jb2011.lnf.beautyeye.widget.border;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.border.AbstractBorder;
/*    */ import org.jb2011.ninepatch4j.NinePatch;
/*    */ 
/*    */ public class NinePatchBorder extends AbstractBorder
/*    */ {
/* 34 */   private Insets insets = null;
/*    */ 
/* 37 */   private NinePatch np = null;
/*    */ 
/*    */   public NinePatchBorder(Insets insets, NinePatch np)
/*    */   {
/* 47 */     this.insets = insets;
/* 48 */     this.np = np;
/*    */   }
/*    */ 
/*    */   public Insets getBorderInsets(Component c)
/*    */   {
/* 56 */     return this.insets;
/*    */   }
/*    */ 
/*    */   public Insets getBorderInsets(Component c, Insets insets)
/*    */   {
/* 64 */     return insets;
/*    */   }
/*    */ 
/*    */   public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/*    */   {
/* 72 */     this.np.draw((Graphics2D)g, x, y, width, height);
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.widget.border.NinePatchBorder
 * JD-Core Version:    0.6.2
 */