/*    */ package org.jb2011.lnf.beautyeye.widget.border;
/*    */ 
/*    */ import java.awt.Insets;
/*    */ import org.jb2011.lnf.beautyeye.widget.__Icon9Factory__;
/*    */ 
/*    */ public class PlainGrayBorder extends NinePatchBorder
/*    */ {
/*    */   private static final int IS = 5;
/*    */ 
/*    */   public PlainGrayBorder()
/*    */   {
/* 39 */     super(new Insets(5, 5, 5, 5), 
/* 39 */       __Icon9Factory__.getInstance().getBorderIcon_plainGray());
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.widget.border.PlainGrayBorder
 * JD-Core Version:    0.6.2
 */