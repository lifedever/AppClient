/*    */ package org.jb2011.lnf.beautyeye.widget.border;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics;
/*    */ import javax.swing.border.LineBorder;
/*    */ import javax.swing.plaf.UIResource;
/*    */ import org.jb2011.lnf.beautyeye.utils.BEUtils;
/*    */ 
/*    */ public class BEDashedBorder extends LineBorder
/*    */   implements UIResource
/*    */ {
/* 32 */   private int step = 3;
/*    */ 
/* 35 */   private boolean top = true; private boolean left = true; private boolean bottom = true; private boolean right = true;
/*    */ 
/*    */   public BEDashedBorder(Color color, boolean top, boolean left, boolean bottom, boolean right)
/*    */   {
/* 48 */     super(color);
/* 49 */     this.top = top;
/* 50 */     this.left = left;
/* 51 */     this.bottom = bottom;
/* 52 */     this.right = right;
/*    */   }
/*    */ 
/*    */   public BEDashedBorder(Color color, int thickness, int step, boolean top, boolean left, boolean bottom, boolean right)
/*    */   {
/* 69 */     super(color, thickness);
/* 70 */     this.step = step;
/* 71 */     this.top = top;
/* 72 */     this.left = left;
/* 73 */     this.bottom = bottom;
/* 74 */     this.right = right;
/*    */   }
/*    */ 
/*    */   public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/*    */   {
/* 82 */     Color oldColor = g.getColor();
/*    */ 
/* 85 */     g.setColor(this.lineColor);
/* 86 */     for (int i = 0; i < this.thickness; i++)
/* 87 */       BEUtils.drawDashedRect(g, x + i, y + i, width - i - i, height - i - i, this.step, this.top, this.left, this.bottom, this.right);
/* 88 */     g.setColor(oldColor);
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.widget.border.BEDashedBorder
 * JD-Core Version:    0.6.2
 */