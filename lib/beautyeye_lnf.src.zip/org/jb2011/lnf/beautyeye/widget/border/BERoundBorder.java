/*     */ package org.jb2011.lnf.beautyeye.widget.border;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.JToolBar;
/*     */ import javax.swing.border.LineBorder;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import org.jb2011.lnf.beautyeye.utils.BEUtils;
/*     */ 
/*     */ public class BERoundBorder extends LineBorder
/*     */   implements UIResource
/*     */ {
/*  36 */   public static final Color defaultLineColor = new Color(188, 188, 188);
/*     */ 
/*  39 */   protected int arcWidth = 0;
/*     */ 
/*     */   public BERoundBorder()
/*     */   {
/*  46 */     this(defaultLineColor, 1);
/*     */   }
/*     */ 
/*     */   public BERoundBorder(Color color)
/*     */   {
/*  56 */     this(color, 1);
/*     */   }
/*     */ 
/*     */   public BERoundBorder(int thickness)
/*     */   {
/*  66 */     this(defaultLineColor, thickness);
/*     */   }
/*     */ 
/*     */   public BERoundBorder(Color color, int thickness)
/*     */   {
/*  77 */     super(color, thickness);
/*     */   }
/*     */ 
/*     */   public Insets getBorderInsets(Component c)
/*     */   {
/*  85 */     return getBorderInsets(c, new Insets(0, 0, 0, 0));
/*     */   }
/*     */ 
/*     */   public Insets getBorderInsets(Component c, Insets insets)
/*     */   {
/*  93 */     Insets margin = null;
/*     */ 
/*  95 */     if ((c instanceof AbstractButton))
/*     */     {
/*  97 */       margin = ((AbstractButton)c).getMargin();
/*     */     }
/*  99 */     else if ((c instanceof JToolBar))
/*     */     {
/* 101 */       margin = ((JToolBar)c).getMargin();
/*     */     }
/* 103 */     else if ((c instanceof JTextComponent))
/*     */     {
/* 105 */       margin = ((JTextComponent)c).getMargin();
/*     */     }
/* 107 */     insets.top = ((margin != null ? margin.top : 0) + this.thickness);
/* 108 */     insets.left = ((margin != null ? margin.left : 0) + this.thickness);
/* 109 */     insets.bottom = ((margin != null ? margin.bottom : 0) + this.thickness);
/* 110 */     insets.right = ((margin != null ? margin.right : 0) + this.thickness);
/*     */ 
/* 112 */     return insets;
/*     */   }
/*     */ 
/*     */   public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/*     */   {
/* 121 */     Color oldColor = g.getColor();
/*     */ 
/* 123 */     BEUtils.setAntiAliasing((Graphics2D)g, true);
/*     */ 
/* 126 */     Component cp = c.getParent();
/*     */ 
/* 136 */     g.setColor(this.lineColor);
/*     */ 
/* 138 */     for (int i = 0; i < this.thickness; i++)
/*     */     {
/* 140 */       g.drawRoundRect(x + i, y + i, width - i - i - 1, height - i - i - 1, this.arcWidth, this.arcWidth);
/* 141 */       if (this.thickness > 1) {
/* 142 */         g.setColor(BEUtils.getColor(g.getColor(), 70, 70, 70, -50));
/*     */       }
/*     */     }
/* 145 */     g.setColor(oldColor);
/*     */ 
/* 148 */     BEUtils.setAntiAliasing((Graphics2D)g, false);
/*     */   }
/*     */ 
/*     */   public BERoundBorder setLineColor(Color c)
/*     */   {
/* 159 */     this.lineColor = c;
/* 160 */     return this;
/*     */   }
/*     */ 
/*     */   public Color getLineColor()
/*     */   {
/* 168 */     return this.lineColor;
/*     */   }
/*     */ 
/*     */   public BERoundBorder setThickness(int t)
/*     */   {
/* 179 */     this.thickness = t;
/* 180 */     return this;
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 188 */     BERoundBorder bb = new BERoundBorder(getLineColor(), getThickness());
/* 189 */     return bb;
/*     */   }
/*     */ 
/*     */   public int getArcWidth()
/*     */   {
/* 199 */     return this.arcWidth;
/*     */   }
/*     */ 
/*     */   public BERoundBorder setArcWidth(int arcWidth)
/*     */   {
/* 210 */     this.arcWidth = arcWidth;
/* 211 */     return this;
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.widget.border.BERoundBorder
 * JD-Core Version:    0.6.2
 */