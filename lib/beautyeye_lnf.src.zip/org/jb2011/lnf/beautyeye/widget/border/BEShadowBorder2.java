/*    */ package org.jb2011.lnf.beautyeye.widget.border;
/*    */ 
/*    */ import java.awt.Insets;
/*    */ import org.jb2011.lnf.beautyeye.widget.__Icon9Factory__;
/*    */ 
/*    */ /** @deprecated */
/*    */ public class BEShadowBorder2 extends NinePatchBorder
/*    */ {
/*    */   private static final int TOP = 14;
/*    */   private static final int LEFT = 15;
/*    */   private static final int RIGHT = 15;
/*    */   private static final int BOTTOM = 16;
/*    */ 
/*    */   public BEShadowBorder2()
/*    */   {
/* 34 */     super(new Insets(14, 15, 16, 15), 
/* 34 */       __Icon9Factory__.getInstance().getBorderIcon_Shadow2());
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.widget.border.BEShadowBorder2
 * JD-Core Version:    0.6.2
 */