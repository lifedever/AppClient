/*     */ package org.jb2011.lnf.beautyeye.widget.border;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import javax.swing.border.LineBorder;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import org.jb2011.lnf.beautyeye.utils.BEUtils;
/*     */ 
/*     */ public class BEDashedRoundRecBorder extends LineBorder
/*     */   implements UIResource
/*     */ {
/*  34 */   private int arcWidth = 6; private int arcHeight = 6; private int separatorSolid = 2; private int separatorSpace = 2;
/*     */ 
/*     */   public BEDashedRoundRecBorder(Color color)
/*     */   {
/*  43 */     super(color);
/*     */   }
/*     */ 
/*     */   public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/*     */   {
/*  51 */     Color oldColor = g.getColor();
/*  52 */     g.setColor(this.lineColor);
/*  53 */     BEUtils.drawDashedRect(g, x, y, width, height, this.arcWidth, this.arcHeight, this.separatorSolid, this.separatorSpace);
/*  54 */     g.setColor(oldColor);
/*     */   }
/*     */ 
/*     */   public int getArcWidth()
/*     */   {
/*  64 */     return this.arcWidth;
/*     */   }
/*     */ 
/*     */   public BEDashedRoundRecBorder setArcWidth(int arcWidth)
/*     */   {
/*  75 */     this.arcWidth = arcWidth;
/*  76 */     return this;
/*     */   }
/*     */ 
/*     */   public int getArcHeight()
/*     */   {
/*  86 */     return this.arcHeight;
/*     */   }
/*     */ 
/*     */   public BEDashedRoundRecBorder setArcHeight(int arcHeight)
/*     */   {
/*  97 */     this.arcHeight = arcHeight;
/*  98 */     return this;
/*     */   }
/*     */ 
/*     */   public int getSeparatorSolid()
/*     */   {
/* 108 */     return this.separatorSolid;
/*     */   }
/*     */ 
/*     */   public BEDashedRoundRecBorder setSeparatorSolid(int separatorSolid)
/*     */   {
/* 119 */     this.separatorSolid = separatorSolid;
/* 120 */     return this;
/*     */   }
/*     */ 
/*     */   public int getSeparatorSpace()
/*     */   {
/* 130 */     return this.separatorSpace;
/*     */   }
/*     */ 
/*     */   public BEDashedRoundRecBorder setSeparatorSpace(int separatorSpace)
/*     */   {
/* 141 */     this.separatorSpace = separatorSpace;
/* 142 */     return this;
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.widget.border.BEDashedRoundRecBorder
 * JD-Core Version:    0.6.2
 */