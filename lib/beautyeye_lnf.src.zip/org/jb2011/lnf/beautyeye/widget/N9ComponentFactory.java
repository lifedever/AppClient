/*     */ package org.jb2011.lnf.beautyeye.widget;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JLabel;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class N9ComponentFactory extends JLabel
/*     */ {
/*     */   public static JLabel createLabel_root(String text, final NinePatch n9, Insets is, Color foregroundColor, Font f)
/*     */   {
/*  49 */     JLabel l = new JLabel(text) {
/*     */       public void paintComponent(Graphics g) {
/*  51 */         n9.draw((Graphics2D)g, 0, 0, getWidth(), getHeight());
/*  52 */         super.paintComponent(g);
/*     */       }
/*     */     };
/*  55 */     if (is != null)
/*  56 */       l.setBorder(BorderFactory.createEmptyBorder(is.top, is.left, is.bottom, is.right));
/*  57 */     if (foregroundColor != null)
/*  58 */       l.setForeground(foregroundColor);
/*  59 */     if (f != null) {
/*  60 */       l.setFont(f);
/*     */     }
/*  62 */     return l;
/*     */   }
/*     */ 
/*     */   public static JLabel createLabel_style1(String txt)
/*     */   {
/*  73 */     return createLabel_root(txt, __Icon9Factory__.getInstance().getHintBgLightBlue(), 
/*  74 */       new Insets(1, 6, 1, 6), Color.white, new Font("宋体", 1, 12));
/*     */   }
/*     */ 
/*     */   public static JLabel createLabel_style2(String txt)
/*     */   {
/*  85 */     return createLabel_root(txt, __Icon9Factory__.getInstance().getTipsBg(), 
/*  86 */       new Insets(15, 3, 28, 3), new Color(139, 119, 75), 
/*  87 */       null);
/*     */   }
/*     */ 
/*     */   public static JLabel createLabel_style3(String txt)
/*     */   {
/*  98 */     return createLabel_root(txt, __Icon9Factory__.getInstance().getOrangeBaloon(), 
/*  99 */       new Insets(4, 9, 9, 9), 
/* 100 */       new Color(255, 255, 255), 
/* 101 */       null);
/*     */   }
/*     */ 
/*     */   public static JLabel createLabel_style4(String txt)
/*     */   {
/* 112 */     return createLabel_root(txt, __Icon9Factory__.getInstance().getHintBgLightGray(), 
/* 113 */       new Insets(2, 8, 2, 8), Color.white, new Font("宋体", 0, 12));
/*     */   }
/*     */ 
/*     */   public static ImageBgPanel createPanel_style1()
/*     */   {
/* 123 */     return createPanel_style1(new Insets(8, 0, 26, 10));
/*     */   }
/*     */ 
/*     */   public static ImageBgPanel createPanel_style1(Insets is)
/*     */   {
/* 134 */     ImageBgPanel p = new ImageBgPanel().setN9(__Icon9Factory__.getInstance().getPanelBg());
/* 135 */     if (is != null)
/* 136 */       p.setBorder(BorderFactory.createEmptyBorder(is.top, is.left, is.bottom, is.right));
/* 137 */     return p;
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.widget.N9ComponentFactory
 * JD-Core Version:    0.6.2
 */