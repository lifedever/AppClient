/*     */ package org.jb2011.lnf.beautyeye.utils;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.GraphicsConfiguration;
/*     */ import java.awt.GraphicsDevice;
/*     */ import java.awt.GraphicsEnvironment;
/*     */ import java.awt.Insets;
/*     */ import java.awt.KeyboardFocusManager;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.Window;
/*     */ import java.util.Locale;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.SwingUtilities;
/*     */ 
/*     */ public class Platform
/*     */ {
/*     */   public static final int OS_WINNT = 1;
/*     */   public static final int OS_WIN95 = 2;
/*     */   public static final int OS_WIN98 = 4;
/*     */   public static final int OS_SOLARIS = 8;
/*     */   public static final int OS_LINUX = 16;
/*     */   public static final int OS_HP = 32;
/*     */   public static final int OS_AIX = 64;
/*     */   public static final int OS_IRIX = 128;
/*     */   public static final int OS_SUNOS = 256;
/*     */   public static final int OS_TRU64 = 512;
/*     */   public static final int OS_OS2 = 2048;
/*     */   public static final int OS_MAC = 4096;
/*     */   public static final int OS_WIN2000 = 8192;
/*     */   public static final int OS_VMS = 16384;
/*     */   public static final int OS_WIN_OTHER = 32768;
/*     */   public static final int OS_OTHER = 65536;
/*     */   public static final int OS_FREEBSD = 131072;
/*     */   public static final int OS_WINDOWS_MASK = 40967;
/*     */   public static final int OS_UNIX_MASK = 136184;
/*  95 */   private static int operatingSystem = -1;
/*     */ 
/*     */   public static int getOperatingSystem()
/*     */   {
/* 101 */     if (operatingSystem == -1) {
/* 102 */       String osName = System.getProperty("os.name");
/*     */ 
/* 104 */       if ("Windows NT".equals(osName))
/* 105 */         operatingSystem = 1;
/* 106 */       else if ("Windows 95".equals(osName))
/* 107 */         operatingSystem = 2;
/* 108 */       else if ("Windows 98".equals(osName))
/* 109 */         operatingSystem = 4;
/* 110 */       else if ("Windows 2000".equals(osName))
/* 111 */         operatingSystem = 8192;
/* 112 */       else if (osName.startsWith("Windows "))
/* 113 */         operatingSystem = 32768;
/* 114 */       else if ("Solaris".equals(osName))
/* 115 */         operatingSystem = 8;
/* 116 */       else if (osName.startsWith("SunOS")) {
/* 117 */         operatingSystem = 8;
/*     */       }
/* 120 */       else if (osName.endsWith("Linux"))
/* 121 */         operatingSystem = 16;
/* 122 */       else if ("HP-UX".equals(osName))
/* 123 */         operatingSystem = 32;
/* 124 */       else if ("AIX".equals(osName))
/* 125 */         operatingSystem = 64;
/* 126 */       else if ("Irix".equals(osName))
/* 127 */         operatingSystem = 128;
/* 128 */       else if ("SunOS".equals(osName))
/* 129 */         operatingSystem = 256;
/* 130 */       else if ("Digital UNIX".equals(osName))
/* 131 */         operatingSystem = 512;
/* 132 */       else if ("OS/2".equals(osName))
/* 133 */         operatingSystem = 2048;
/* 134 */       else if ("OpenVMS".equals(osName))
/* 135 */         operatingSystem = 16384;
/* 136 */       else if (osName.equals("Mac OS X"))
/* 137 */         operatingSystem = 4096;
/* 138 */       else if (osName.startsWith("Darwin"))
/* 139 */         operatingSystem = 4096;
/* 140 */       else if (osName.toLowerCase(Locale.US).startsWith("freebsd"))
/* 141 */         operatingSystem = 131072;
/*     */       else {
/* 143 */         operatingSystem = 65536;
/*     */       }
/*     */     }
/* 146 */     return operatingSystem;
/*     */   }
/*     */ 
/*     */   public static boolean isWindows()
/*     */   {
/* 153 */     return (getOperatingSystem() & 0xA007) != 0;
/*     */   }
/*     */ 
/*     */   public static boolean isUnix()
/*     */   {
/* 161 */     return (getOperatingSystem() & 0x213F8) != 0;
/*     */   }
/*     */ 
/*     */   public static boolean isLargeFrameIcons()
/*     */   {
/* 169 */     return (getOperatingSystem() == 8) || (getOperatingSystem() == 32);
/*     */   }
/*     */ 
/*     */   private static GraphicsConfiguration getCurrentGraphicsConfiguration()
/*     */   {
/* 181 */     Component focusOwner = KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner();
/* 182 */     if (focusOwner != null) {
/* 183 */       Window w = SwingUtilities.getWindowAncestor(focusOwner);
/* 184 */       if (w != null) {
/* 185 */         return w.getGraphicsConfiguration();
/*     */       }
/*     */     }
/*     */ 
/* 189 */     return GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration();
/*     */   }
/*     */ 
/*     */   public static Rectangle getUsableScreenBounds()
/*     */   {
/* 204 */     return getUsableScreenBounds(getCurrentGraphicsConfiguration());
/*     */   }
/*     */ 
/*     */   public static Rectangle getUsableScreenBounds(GraphicsConfiguration gconf)
/*     */   {
/* 218 */     if (gconf == null) {
/* 219 */       gconf = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration();
/*     */     }
/*     */ 
/* 222 */     Rectangle bounds = new Rectangle(gconf.getBounds());
/*     */ 
/* 226 */     String str = System.getProperty("netbeans.screen.insets");
/*     */ 
/* 228 */     if (str != null) {
/* 229 */       StringTokenizer st = new StringTokenizer(str, ", ");
/*     */ 
/* 231 */       if (st.countTokens() == 4) {
/*     */         try {
/* 233 */           bounds.y = Integer.parseInt(st.nextToken());
/* 234 */           bounds.x = Integer.parseInt(st.nextToken());
/* 235 */           bounds.height -= bounds.y + Integer.parseInt(st.nextToken());
/* 236 */           bounds.width -= bounds.x + Integer.parseInt(st.nextToken());
/*     */         } catch (NumberFormatException ex) {
/* 238 */           Logger.getAnonymousLogger().log(Level.WARNING, null, ex);
/*     */         }
/*     */       }
/*     */ 
/* 242 */       return bounds;
/*     */     }
/*     */ 
/* 245 */     str = System.getProperty("netbeans.taskbar.height");
/*     */ 
/* 247 */     if (str != null) {
/* 248 */       bounds.height -= Integer.getInteger(str, 0).intValue();
/*     */ 
/* 250 */       return bounds;
/*     */     }
/*     */     try
/*     */     {
/* 254 */       Toolkit toolkit = Toolkit.getDefaultToolkit();
/* 255 */       Insets insets = toolkit.getScreenInsets(gconf);
/* 256 */       bounds.y += insets.top;
/* 257 */       bounds.x += insets.left;
/* 258 */       bounds.height -= insets.top + insets.bottom;
/* 259 */       bounds.width -= insets.left + insets.right;
/*     */     } catch (Exception ex) {
/* 261 */       Logger.getAnonymousLogger().log(Level.WARNING, null, ex);
/*     */     }
/*     */ 
/* 264 */     return bounds;
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.utils.Platform
 * JD-Core Version:    0.6.2
 */