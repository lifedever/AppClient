/*    */ package org.jb2011.lnf.beautyeye.utils;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public abstract class RawCache<T>
/*    */ {
/* 27 */   private HashMap<String, T> rawCache = new HashMap();
/*    */ 
/*    */   public T getRaw(String relativePath, Class baseClass)
/*    */   {
/* 39 */     Object ic = null;
/*    */ 
/* 41 */     String key = relativePath + baseClass.getCanonicalName();
/* 42 */     if (this.rawCache.containsKey(key)) {
/* 43 */       ic = this.rawCache.get(key);
/*    */     }
/*    */     else {
/*    */       try
/*    */       {
/* 48 */         ic = getResource(relativePath, baseClass);
/* 49 */         this.rawCache.put(key, ic);
/*    */       }
/*    */       catch (Exception e)
/*    */       {
/* 53 */         System.out.println("取本地磁盘资源文件出错,path=" + key + "," + e.getMessage());
/* 54 */         e.printStackTrace();
/*    */       }
/*    */     }
/* 57 */     return ic;
/*    */   }
/*    */ 
/*    */   protected abstract T getResource(String paramString, Class paramClass);
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.utils.RawCache
 * JD-Core Version:    0.6.2
 */