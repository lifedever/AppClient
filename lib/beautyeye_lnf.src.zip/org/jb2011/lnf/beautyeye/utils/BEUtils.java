/*     */ package org.jb2011.lnf.beautyeye.utils;
/*     */ 
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.GradientPaint;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.Paint;
/*     */ import java.awt.Polygon;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.TexturePaint;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.RescaleOp;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.UIManager;
/*     */ 
/*     */ public class BEUtils
/*     */ {
/*     */   public static ImageIcon filterWithRescaleOp(ImageIcon iconBottom, float redFilter, float greenFilter, float blueFilter, float alphaFilter)
/*     */   {
/*     */     try
/*     */     {
/*  59 */       int w = iconBottom.getIconWidth(); int h = iconBottom.getIconHeight();
/*     */ 
/*  62 */       BufferedImage bi = new BufferedImage(w, h, 2);
/*  63 */       Graphics2D gg = (Graphics2D)bi.getGraphics();
/*  64 */       gg.drawImage(iconBottom.getImage(), 0, 0, w, h, null);
/*     */ 
/*  67 */       float[] scales = { redFilter, greenFilter, blueFilter, alphaFilter };
/*  68 */       float[] offsets = new float[4];
/*  69 */       RescaleOp rop = new RescaleOp(scales, offsets, null);
/*     */ 
/*  73 */       rop.filter(bi, bi);
/*  74 */       return new ImageIcon(bi);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  79 */       LogHelper.error("filterWithRescaleOp出错了，" + e.getMessage() + ",iconBottom=" + iconBottom);
/*  80 */     }return new ImageIcon();
/*     */   }
/*     */ 
/*     */   public static void draw4RecCorner(Graphics g, int x, int y, int w, int h, int β, Color c)
/*     */   {
/* 111 */     Color oldColor = g.getColor();
/*     */ 
/* 113 */     g.setColor(c);
/*     */ 
/* 115 */     g.drawLine(x, y, x + β, y);
/* 116 */     g.drawLine(x + (w - β), y, x + w, y);
/*     */ 
/* 119 */     g.drawLine(x, y, x, y + β);
/* 120 */     g.drawLine(x, y + (h - β), x, y + h);
/*     */ 
/* 123 */     g.drawLine(x, y + h, x + β, y + h);
/* 124 */     g.drawLine(x + (w - β), y + h, x + w, y + h);
/*     */ 
/* 127 */     g.drawLine(x + w, y + h, x + w, y + (h - β));
/* 128 */     g.drawLine(x + w, y + β, x + w, y);
/* 129 */     g.setColor(oldColor);
/*     */   }
/*     */ 
/*     */   public static void componentsOpaque(Component[] comps, boolean opaque)
/*     */   {
/* 142 */     if (comps == null)
/* 143 */       return;
/* 144 */     Component[] arrayOfComponent = comps; int j = comps.length; for (int i = 0; i < j; i++) { Component c = arrayOfComponent[i];
/*     */ 
/* 147 */       if ((c instanceof Container))
/*     */       {
/* 149 */         if ((c instanceof JComponent))
/* 150 */           ((JComponent)c).setOpaque(opaque);
/* 151 */         componentsOpaque(((Container)c).getComponents(), opaque);
/*     */       }
/* 155 */       else if ((c instanceof JComponent)) {
/* 156 */         ((JComponent)c).setOpaque(opaque);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void setAntiAliasing(Graphics2D g2, boolean antiAliasing)
/*     */   {
/* 169 */     if (antiAliasing)
/* 170 */       g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
/* 171 */         RenderingHints.VALUE_ANTIALIAS_ON);
/*     */     else
/* 173 */       g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
/* 174 */         RenderingHints.VALUE_ANTIALIAS_OFF);
/*     */   }
/*     */ 
/*     */   public static void fillTriangle(Graphics g, int x1, int y1, int x2, int y2, int x3, int y3, Color c)
/*     */   {
/* 193 */     int[] x = new int[3]; int[] y = new int[3];
/*     */ 
/* 195 */     x[0] = x1; x[1] = x2; x[2] = x3;
/* 196 */     y[0] = y1; y[1] = y2; y[2] = y3;
/* 197 */     int n = 3;
/*     */ 
/* 199 */     Polygon p = new Polygon(x, y, n);
/*     */ 
/* 201 */     g.setColor(c);
/* 202 */     g.fillPolygon(p);
/*     */   }
/*     */ 
/*     */   public static void drawDashedRect(Graphics g, int x, int y, int width, int height)
/*     */   {
/* 217 */     drawDashedRect(g, x, y, width, height, 6, 6, 2, 2);
/*     */   }
/*     */ 
/*     */   public static void drawDashedRect(Graphics g, int x, int y, int width, int height, int arcWidth, int arcHeight, int separator_solid, int separator_space)
/*     */   {
/* 239 */     setAntiAliasing((Graphics2D)g, true);
/*     */ 
/* 242 */     Stroke oldStroke = ((Graphics2D)g).getStroke();
/* 243 */     Stroke sroke = new BasicStroke(1.0F, 0, 
/* 244 */       2, 0.0F, new float[] { separator_solid, separator_space }, 0.0F);
/* 245 */     ((Graphics2D)g).setStroke(sroke);
/*     */ 
/* 247 */     g.drawRoundRect(x, y, 
/* 248 */       width - 1, height - 1, 
/* 251 */       arcWidth, arcHeight);
/*     */ 
/* 253 */     ((Graphics2D)g).setStroke(oldStroke);
/* 254 */     setAntiAliasing((Graphics2D)g, false);
/*     */   }
/*     */ 
/*     */   public static void drawDashedRect(Graphics g, int x, int y, int width, int height, int step, boolean top, boolean left, boolean bottom, boolean right)
/*     */   {
/* 276 */     int drawStep = step == 0 ? 1 : 2 * step;
/* 277 */     int drawLingStep = step == 0 ? 1 : step;
/*     */ 
/* 279 */     for (int vx = x; vx < x + width; vx += drawStep)
/*     */     {
/* 281 */       if (top)
/* 282 */         g.fillRect(vx, y, drawLingStep, 1);
/* 283 */       if (bottom) {
/* 284 */         g.fillRect(vx, y + height - 1, drawLingStep, 1);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 289 */     for (int vy = y; vy < y + height; vy += drawStep)
/*     */     {
/* 291 */       if (left)
/* 292 */         g.fillRect(x, vy, 1, drawLingStep);
/* 293 */       if (right)
/* 294 */         g.fillRect(x + width - 1, vy, 1, drawLingStep);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Color getColor(Color basic, int r, int g, int b)
/*     */   {
/* 309 */     return new Color(getColorInt(basic.getRed() + r), 
/* 310 */       getColorInt(basic.getGreen() + g), 
/* 311 */       getColorInt(basic.getBlue() + b), 
/* 312 */       getColorInt(basic.getAlpha()));
/*     */   }
/*     */ 
/*     */   public static Color getColor(Color basic, int r, int g, int b, int a)
/*     */   {
/* 327 */     return new Color(getColorInt(basic.getRed() + r), 
/* 328 */       getColorInt(basic.getGreen() + g), 
/* 329 */       getColorInt(basic.getBlue() + b), 
/* 330 */       getColorInt(basic.getAlpha() + a));
/*     */   }
/*     */ 
/*     */   public static int getColorInt(int rgb)
/*     */   {
/* 341 */     return rgb > 255 ? 255 : rgb < 0 ? 0 : rgb;
/*     */   }
/*     */ 
/*     */   public static int getStrPixWidth(FontMetrics fm, String str)
/*     */   {
/* 354 */     return fm.stringWidth(str);
/*     */   }
/*     */ 
/*     */   public static int getStrPixWidth(Font f, String str)
/*     */   {
/* 367 */     return getStrPixWidth(Toolkit.getDefaultToolkit().getFontMetrics(f), str);
/*     */   }
/*     */ 
/*     */   public static TexturePaint createTexturePaint(Image image)
/*     */   {
/* 394 */     int imageWidth = image.getWidth(null);
/* 395 */     int imageHeight = image.getHeight(null);
/* 396 */     BufferedImage bi = new BufferedImage(imageWidth, imageHeight, 2);
/* 397 */     Graphics2D g2d = bi.createGraphics();
/* 398 */     g2d.drawImage(image, 0, 0, null);
/* 399 */     g2d.dispose();
/* 400 */     return new TexturePaint(bi, new Rectangle(0, 0, imageWidth, imageHeight));
/*     */   }
/*     */ 
/*     */   public static int getInt(Object key, int defaultValue)
/*     */   {
/* 412 */     Object value = UIManager.get(key);
/*     */ 
/* 414 */     if ((value instanceof Integer))
/*     */     {
/* 416 */       return ((Integer)value).intValue();
/*     */     }
/* 418 */     if ((value instanceof String))
/*     */     {
/*     */       try
/*     */       {
/* 422 */         return Integer.parseInt((String)value);
/*     */       }
/*     */       catch (NumberFormatException localNumberFormatException)
/*     */       {
/*     */       }
/*     */     }
/* 428 */     return defaultValue;
/*     */   }
/*     */ 
/*     */   public static void fillTextureRoundRec(Graphics2D g2, Color baseColor, int x, int y, int w, int h, int arc)
/*     */   {
/* 445 */     fillTextureRoundRec(g2, baseColor, 
/* 446 */       x, y, w, h, arc, 35);
/*     */   }
/*     */ 
/*     */   public static void fillTextureRoundRec(Graphics2D g2, Color baseColor, int x, int y, int w, int h, int arc, int colorDelta)
/*     */   {
/* 464 */     setAntiAliasing(g2, true);
/*     */ 
/* 466 */     Paint oldpaint = g2.getPaint();
/* 467 */     GradientPaint gp = new GradientPaint(x, y, 
/* 469 */       getColor(baseColor, colorDelta, colorDelta, colorDelta), 
/* 470 */       x, y + h, baseColor);
/*     */ 
/* 472 */     g2.setPaint(gp);
/* 473 */     g2.fillRoundRect(x, y, w, h, arc, arc);
/* 474 */     g2.setPaint(oldpaint);
/* 475 */     setAntiAliasing(g2, false);
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.utils.BEUtils
 * JD-Core Version:    0.6.2
 */