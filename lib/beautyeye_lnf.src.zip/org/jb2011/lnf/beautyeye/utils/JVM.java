/*     */ package org.jb2011.lnf.beautyeye.utils;
/*     */ 
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.UIManager.LookAndFeelInfo;
/*     */ 
/*     */ public class JVM
/*     */ {
/*     */   public static final int JDK1_0 = 10;
/*     */   public static final int JDK1_1 = 11;
/*     */   public static final int JDK1_2 = 12;
/*     */   public static final int JDK1_3 = 13;
/*     */   public static final int JDK1_4 = 14;
/*     */   public static final int JDK1_5 = 15;
/*     */   public static final int JDK1_6 = 16;
/*     */   public static final int JDK1_6_U10_AND_AFTER = 17;
/*  47 */   public static boolean isJDK1_6_U10 = false;
/*     */ 
/*  50 */   public static boolean isJDK1_6_U11 = false;
/*     */   public static final int JDK1_7 = 30;
/*     */   public static final int JDK1_8 = 31;
/*     */   public static final int JDK1_9 = 32;
/*  64 */   private static JVM current = new JVM();
/*     */   private int jdkVersion;
/*     */ 
/*     */   public static JVM current()
/*     */   {
/*  73 */     return current;
/*     */   }
/*     */ 
/*     */   public JVM()
/*     */   {
/*  85 */     this(System.getProperty("java.version"));
/*     */   }
/*     */ 
/*     */   public JVM(String p_JavaVersion)
/*     */   {
/*  94 */     if (p_JavaVersion.startsWith("1.9.")) {
/*  95 */       this.jdkVersion = 32;
/*     */     }
/*  97 */     else if (p_JavaVersion.startsWith("1.8.")) {
/*  98 */       this.jdkVersion = 31;
/*     */     }
/* 100 */     else if (p_JavaVersion.startsWith("1.7.")) {
/* 101 */       this.jdkVersion = 30;
/*     */     }
/* 103 */     else if (p_JavaVersion.startsWith("1.6."))
/*     */     {
/* 105 */       for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
/* 106 */         if (("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel".equals(info.getClassName())) || 
/* 107 */           ("javax.swing.plaf.nimbus.NimbusLookAndFeel".equals(info.getClassName())))
/*     */         {
/* 109 */           this.jdkVersion = 17;
/* 110 */           break;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 115 */       if (this.jdkVersion == 17)
/*     */       {
/* 117 */         if (p_JavaVersion.startsWith("1.6.0_10"))
/* 118 */           isJDK1_6_U10 = true;
/* 119 */         if (p_JavaVersion.startsWith("1.6.0_11")) {
/* 120 */           isJDK1_6_U11 = true;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 125 */       this.jdkVersion = (this.jdkVersion == 0 ? 16 : this.jdkVersion);
/* 126 */     } else if (p_JavaVersion.startsWith("1.5.")) {
/* 127 */       this.jdkVersion = 15;
/* 128 */     } else if (p_JavaVersion.startsWith("1.4.")) {
/* 129 */       this.jdkVersion = 14;
/* 130 */     } else if (p_JavaVersion.startsWith("1.3.")) {
/* 131 */       this.jdkVersion = 13;
/* 132 */     } else if (p_JavaVersion.startsWith("1.2.")) {
/* 133 */       this.jdkVersion = 12;
/* 134 */     } else if (p_JavaVersion.startsWith("1.1.")) {
/* 135 */       this.jdkVersion = 11;
/* 136 */     } else if (p_JavaVersion.startsWith("1.0.")) {
/* 137 */       this.jdkVersion = 10;
/*     */     }
/*     */     else {
/* 140 */       this.jdkVersion = 13;
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isOrLater(int p_Version)
/*     */   {
/* 151 */     return this.jdkVersion >= p_Version;
/*     */   }
/*     */ 
/*     */   public boolean isOneDotOne()
/*     */   {
/* 160 */     return this.jdkVersion == 11;
/*     */   }
/*     */ 
/*     */   public boolean isOneDotTwo()
/*     */   {
/* 169 */     return this.jdkVersion == 12;
/*     */   }
/*     */ 
/*     */   public boolean isOneDotThree()
/*     */   {
/* 178 */     return this.jdkVersion == 13;
/*     */   }
/*     */ 
/*     */   public boolean isOneDotFour()
/*     */   {
/* 187 */     return this.jdkVersion == 14;
/*     */   }
/*     */ 
/*     */   public boolean isOneDotFive()
/*     */   {
/* 196 */     return this.jdkVersion == 15;
/*     */   }
/*     */ 
/*     */   public boolean isOneDotSix()
/*     */   {
/* 206 */     return (this.jdkVersion == 16) || 
/* 206 */       (this.jdkVersion == 17);
/*     */   }
/*     */ 
/*     */   public boolean isOneDotSixUpdate12OrAfter()
/*     */   {
/* 239 */     return ((this.jdkVersion == 17) && 
/* 238 */       (!isJDK1_6_U10) && (!isJDK1_6_U11)) || 
/* 239 */       (this.jdkVersion >= 30);
/*     */   }
/*     */ 
/*     */   public boolean isOneDotSeven()
/*     */   {
/* 248 */     return this.jdkVersion == 30;
/*     */   }
/*     */ 
/*     */   public boolean isOneDotEight()
/*     */   {
/* 257 */     return this.jdkVersion == 31;
/*     */   }
/*     */ 
/*     */   public boolean isOneDotNine()
/*     */   {
/* 266 */     return this.jdkVersion == 32;
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.utils.JVM
 * JD-Core Version:    0.6.2
 */