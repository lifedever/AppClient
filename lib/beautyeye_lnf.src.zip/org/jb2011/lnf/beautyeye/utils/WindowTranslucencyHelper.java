/*     */ package org.jb2011.lnf.beautyeye.utils;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.GraphicsDevice;
/*     */ import java.awt.GraphicsEnvironment;
/*     */ import java.awt.Window;
/*     */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*     */ 
/*     */ public class WindowTranslucencyHelper
/*     */ {
/*     */   private static final String UN_WINDOWS_SORRY = "I'm sorry, the Linux platform does not support transparency, please pay attention to the next version of BeautyEye.";
/*     */ 
/*     */   public static boolean isTranslucencySupported()
/*     */   {
/*  78 */     boolean isTranslucencySupported = false;
/*     */     try
/*     */     {
/*  82 */       if (JVM.current().isOrLater(30))
/*     */       {
/*  93 */         GraphicsEnvironment ge = 
/*  94 */           GraphicsEnvironment.getLocalGraphicsEnvironment();
/*  95 */         GraphicsDevice gd = ge.getDefaultScreenDevice();
/*     */ 
/*  97 */         Class _WindowTranslucency = Class.forName("java.awt.GraphicsDevice$WindowTranslucency");
/*  98 */         isTranslucencySupported = ((Boolean)ReflectHelper.invokeMethod(GraphicsDevice.class, gd, "isWindowTranslucencySupported", 
/*  99 */           new Class[] { _WindowTranslucency }, 
/* 100 */           new Object[] { Enum.valueOf(_WindowTranslucency, "TRANSLUCENT") })).booleanValue();
/*     */       }
/* 102 */       else if (JVM.current().isOrLater(16))
/*     */       {
/* 108 */         Class _WindowTranslucency = Class.forName("com.sun.awt.AWTUtilities$Translucency");
/* 109 */         isTranslucencySupported = ((Boolean)ReflectHelper.invokeMethod(Class.forName("com.sun.awt.AWTUtilities"), _WindowTranslucency, "isTranslucencySupported", 
/* 110 */           new Class[] { _WindowTranslucency }, 
/* 111 */           new Object[] { Enum.valueOf(_WindowTranslucency, "TRANSLUCENT") })).booleanValue();
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 116 */       if (BeautyEyeLNFHelper.debug)
/* 117 */         e.printStackTrace();
/* 118 */       LogHelper.debug("Exception at WindowTranslucencyHelper.isTranslucencySupported()," + e.getMessage());
/*     */     }
/*     */ 
/* 121 */     return isTranslucencySupported;
/*     */   }
/*     */ 
/*     */   public static void setOpacity(Window w, float opacity)
/*     */   {
/*     */     try
/*     */     {
/* 144 */       if (JVM.current().isOneDotSixUpdate12OrAfter())
/*     */       {
/* 146 */         if (!isTranslucencySupported())
/*     */         {
/* 148 */           LogHelper.debug("Your OS can't supported translucency.");
/* 149 */           return;
/*     */         }
/*     */ 
/* 153 */         if (JVM.current().isOrLater(30))
/* 154 */           ReflectHelper.invokeMethod(Window.class, w, "setOpacity", 
/* 155 */             new Class[] { Float.TYPE }, new Object[] { Float.valueOf(opacity) });
/*     */         else
/* 157 */           ReflectHelper.invokeStaticMethod("com.sun.awt.AWTUtilities", "setWindowOpacity", 
/* 158 */             new Class[] { Window.class, Float.TYPE }, new Object[] { w, Float.valueOf(opacity) });
/*     */       }
/*     */       else {
/* 161 */         LogHelper.debug("您的JRE版本不支持每像素半透明(需jre1.6_u12及以上版本)，BeautyEye外观将不能达到最佳视觉效果哦.");
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 165 */       if (BeautyEyeLNFHelper.debug)
/* 166 */         e.printStackTrace();
/* 167 */       LogHelper.debug("您的JRE版本不支持每像素半透明(需jre1.6_u12及以上版本)，BeautyEye外观将不能达到最佳视觉效果哦." + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void setWindowOpaque(Window w, boolean opaque)
/*     */   {
/*     */     try
/*     */     {
/* 191 */       if (JVM.current().isOneDotSixUpdate12OrAfter())
/*     */       {
/* 193 */         if (!isTranslucencySupported())
/*     */         {
/* 195 */           LogHelper.debug("Your OS can't supported translucency.");
/* 196 */           return;
/*     */         }
/*     */ 
/* 200 */         if (JVM.current().isOrLater(30))
/*     */         {
/* 203 */           Color bgc = w.getBackground();
/*     */ 
/* 207 */           if (bgc == null)
/* 208 */             bgc = Color.black;
/* 209 */           Color newBgn = new Color(bgc.getRed(), bgc.getGreen(), bgc.getBlue(), opaque ? 255 : 0);
/* 210 */           w.setBackground(newBgn);
/*     */         }
/*     */         else {
/* 213 */           ReflectHelper.invokeStaticMethod("com.sun.awt.AWTUtilities", "setWindowOpaque", 
/* 214 */             new Class[] { Window.class, Boolean.TYPE }, new Object[] { w, Boolean.valueOf(opaque) });
/*     */         }
/*     */       } else {
/* 217 */         LogHelper.debug("您的JRE版本不支持窗口透明(需jre1.6_u12及以上版本)，BeautyEye外观将不能达到最佳视觉效果哦.");
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 221 */       if (BeautyEyeLNFHelper.debug)
/* 222 */         e.printStackTrace();
/* 223 */       LogHelper.debug("您的JRE版本不支持窗口透明(需jre1.6_u12及以上版本)，BeautyEye外观将不能达到最佳视觉效果哦." + e.getMessage());
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.utils.WindowTranslucencyHelper
 * JD-Core Version:    0.6.2
 */