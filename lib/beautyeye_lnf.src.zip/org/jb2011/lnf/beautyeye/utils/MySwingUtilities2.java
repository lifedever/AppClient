/*     */ package org.jb2011.lnf.beautyeye.utils;
/*     */ 
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import javax.swing.JComponent;
/*     */ 
/*     */ public class MySwingUtilities2
/*     */ {
/*     */   public static FontMetrics getFontMetrics(JComponent c, Graphics g)
/*     */   {
/*  57 */     return (FontMetrics)invokeSwingUtilities2StaticMethod("getFontMetrics", 
/*  58 */       new Class[] { JComponent.class, Graphics.class }, 
/*  59 */       new Object[] { c, g });
/*     */   }
/*     */ 
/*     */   public static FontMetrics getFontMetrics(JComponent c, Graphics g, Font font)
/*     */   {
/*  90 */     return (FontMetrics)invokeSwingUtilities2StaticMethod("getFontMetrics", 
/*  91 */       new Class[] { JComponent.class, Graphics.class, Font.class }, 
/*  92 */       new Object[] { c, g, font });
/*     */   }
/*     */ 
/*     */   public static int stringWidth(JComponent c, FontMetrics fm, String string)
/*     */   {
/* 105 */     return ((Integer)invokeSwingUtilities2StaticMethod("stringWidth", 
/* 106 */       new Class[] { JComponent.class, FontMetrics.class, String.class }, 
/* 107 */       new Object[] { c, fm, string })).intValue();
/*     */   }
/*     */ 
/*     */   public static void drawString(JComponent c, Graphics g, String text, int x, int y)
/*     */   {
/* 121 */     invokeSwingUtilities2StaticMethod("drawString", 
/* 122 */       new Class[] { JComponent.class, Graphics.class, String.class, Integer.TYPE, Integer.TYPE }, 
/* 123 */       new Object[] { c, g, text, Integer.valueOf(x), Integer.valueOf(y) });
/*     */   }
/*     */ 
/*     */   static boolean isPrinting(Graphics g)
/*     */   {
/* 182 */     return ((Boolean)invokeSwingUtilities2StaticMethod("isPrinting", 
/* 183 */       new Class[] { Graphics.class }, 
/* 184 */       new Object[] { g })).booleanValue();
/*     */   }
/*     */ 
/*     */   private static boolean drawTextAntialiased(JComponent c)
/*     */   {
/* 207 */     return ((Boolean)invokeSwingUtilities2StaticMethod("drawTextAntialiased", 
/* 208 */       new Class[] { JComponent.class }, 
/* 209 */       new Object[] { c })).booleanValue();
/*     */   }
/*     */ 
/*     */   public static boolean drawTextAntialiased(boolean aaText)
/*     */   {
/* 227 */     return ((Boolean)invokeSwingUtilities2StaticMethod("drawTextAntialiased", 
/* 228 */       new Class[] { Boolean.TYPE }, 
/* 229 */       new Object[] { Boolean.valueOf(aaText) })).booleanValue();
/*     */   }
/*     */ 
/*     */   public static Graphics2D getGraphics2D(Graphics g)
/*     */   {
/* 251 */     return (Graphics2D)invokeSwingUtilities2StaticMethod("getGraphics2D", 
/* 252 */       new Class[] { Graphics.class }, 
/* 253 */       new Object[] { g });
/*     */   }
/*     */ 
/*     */   public static void drawStringUnderlineCharAt(JComponent c, Graphics g, String text, int underlinedIndex, int x, int y)
/*     */   {
/* 282 */     invokeSwingUtilities2StaticMethod("drawStringUnderlineCharAt", 
/* 283 */       new Class[] { JComponent.class, Graphics.class, String.class, Integer.TYPE, Integer.TYPE, Integer.TYPE }, 
/* 284 */       new Object[] { c, g, text, Integer.valueOf(underlinedIndex), Integer.valueOf(x), Integer.valueOf(y) });
/*     */   }
/*     */ 
/*     */   public static String clipStringIfNecessary(JComponent c, FontMetrics fm, String string, int availTextWidth)
/*     */   {
/* 306 */     string = (String)invokeSwingUtilities2StaticMethod("clipStringIfNecessary", 
/* 307 */       new Class[] { JComponent.class, FontMetrics.class, String.class, Integer.TYPE }, 
/* 308 */       new Object[] { c, fm, string, Integer.valueOf(availTextWidth) });
/* 309 */     return string;
/*     */   }
/*     */ 
/*     */   public static String clipString(JComponent c, FontMetrics fm, String string, int availTextWidth)
/*     */   {
/* 324 */     string = (String)invokeSwingUtilities2StaticMethod("clipString", 
/* 325 */       new Class[] { JComponent.class, FontMetrics.class, String.class, Integer.TYPE }, 
/* 326 */       new Object[] { c, fm, string, Integer.valueOf(availTextWidth) });
/*     */ 
/* 328 */     return string;
/*     */   }
/*     */ 
/*     */   public static Object invokeSwingUtilities2StaticMethod(String methodName, Class[] paramsType, Object[] paramsValue)
/*     */   {
/* 342 */     return ReflectHelper.invokeStaticMethod(ReflectHelper.getClass(getSwingUtilities2ClassName()), 
/* 343 */       methodName, paramsType, paramsValue);
/*     */   }
/*     */ 
/*     */   public static String getSwingUtilities2ClassName()
/*     */   {
/* 356 */     if (JVM.current().isOrLater(16)) {
/* 357 */       return "sun.swing.SwingUtilities2";
/*     */     }
/*     */ 
/* 360 */     return "com.sun.java.swing.SwingUtilities2";
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.utils.MySwingUtilities2
 * JD-Core Version:    0.6.2
 */