/*     */ package org.jb2011.lnf.beautyeye.utils;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*     */ 
/*     */ public class ReflectHelper
/*     */ {
/*     */   public static Object invokeStaticMethod(String theClassFullName, String methodName, Class[] paramsType, Object[] paramsValue)
/*     */   {
/*  38 */     return invokeStaticMethod(getClass(theClassFullName), methodName, paramsType, paramsValue);
/*     */   }
/*     */ 
/*     */   public static Object invokeStaticMethod(Class theClass, String methodName, Class[] paramsType, Object[] paramsValue)
/*     */   {
/*  52 */     return invokeMethod(theClass, theClass, methodName, paramsType, paramsValue);
/*     */   }
/*     */ 
/*     */   public static Object invokeMethod(String theClassFullName, Object theObject, String methodName, Class[] paramsType, Object[] paramsValue)
/*     */   {
/*  68 */     Class theClass = getClass(theClassFullName);
/*     */ 
/*  70 */     return invokeMethod(theClass, theClass, methodName, paramsType, paramsValue);
/*     */   }
/*     */ 
/*     */   public static Object invokeMethod(Class theClass, Object theObject, String methodName, Class[] paramsType, Object[] paramsValue)
/*     */   {
/*  85 */     Object ret = null;
/*  86 */     if (theClass != null)
/*     */     {
/*     */       try
/*     */       {
/*  90 */         Method m = theClass.getMethod(methodName, paramsType);
/*  91 */         ret = m.invoke(theObject, paramsValue);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*  97 */         if (BeautyEyeLNFHelper.debug) {
/*  98 */           e.printStackTrace();
/*     */         }
/* 100 */         LogHelper.error("通过反射调用方法" + theClass.getName() + "." + methodName + 
/* 101 */           "(" + Arrays.toString(paramsType) + ")失败，您的JRE版本可能需要更新，" + e.getMessage());
/*     */       }
/*     */     }
/* 104 */     return ret;
/*     */   }
/*     */ 
/*     */   public static Class getClass(String className)
/*     */   {
/*     */     try
/*     */     {
/* 117 */       return Class.forName(className);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 121 */       LogHelper.error("通过反射获得" + className + "的Class对象失败，您的JRE版本可能需要更新，" + e.getMessage());
/* 122 */     }return null;
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.utils.ReflectHelper
 * JD-Core Version:    0.6.2
 */