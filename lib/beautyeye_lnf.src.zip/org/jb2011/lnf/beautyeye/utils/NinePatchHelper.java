/*    */ package org.jb2011.lnf.beautyeye.utils;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import org.jb2011.ninepatch4j.NinePatch;
/*    */ 
/*    */ public class NinePatchHelper
/*    */ {
/*    */   public static NinePatch createNinePatch(URL fileUrl, boolean convert)
/*    */   {
/*    */     try
/*    */     {
/* 40 */       return NinePatch.load(fileUrl, convert);
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 44 */       e.printStackTrace();
/* 45 */     }return null;
/*    */   }
/*    */ 
/*    */   public static NinePatch createNinePatch(InputStream stream, boolean is9Patch, boolean convert)
/*    */     throws IOException
/*    */   {
/* 61 */     return NinePatch.load(stream, is9Patch, convert);
/*    */   }
/*    */ 
/*    */   public static NinePatch createNinePatch(BufferedImage image, boolean is9Patch, boolean convert)
/*    */   {
/* 75 */     return NinePatch.load(image, is9Patch, convert);
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.utils.NinePatchHelper
 * JD-Core Version:    0.6.2
 */