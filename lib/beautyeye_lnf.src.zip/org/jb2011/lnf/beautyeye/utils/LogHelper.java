/*    */ package org.jb2011.lnf.beautyeye.utils;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*    */ 
/*    */ public class LogHelper
/*    */ {
/*    */   public static void error(String msg)
/*    */   {
/* 21 */     if (BeautyEyeLNFHelper.debug)
/* 22 */       System.err.println("[BE-ERROR] - " + msg);
/*    */   }
/*    */ 
/*    */   public static void debug(String msg)
/*    */   {
/* 32 */     if (BeautyEyeLNFHelper.debug)
/* 33 */       System.err.println("[BE-DEBUG] - " + msg);
/*    */   }
/*    */ 
/*    */   public static void info(String msg)
/*    */   {
/* 43 */     System.err.println("[BE-INFO] - " + msg);
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.utils.LogHelper
 * JD-Core Version:    0.6.2
 */