/*     */ package org.jb2011.lnf.beautyeye.ch10_internalframe;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.ActionMap;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.basic.BasicInternalFrameUI;
/*     */ 
/*     */ public class BEInternalFrameUI extends BasicInternalFrameUI
/*     */ {
/*     */   private BEInternalFrameTitlePane titlePane;
/*  45 */   private static final PropertyChangeListener metalPropertyChangeListener = new XZCMetalPropertyChangeHandler(null);
/*     */ 
/*  48 */   private static final Border handyEmptyBorder = new EmptyBorder(0, 0, 0, 0);
/*     */ 
/*  53 */   private static String FRAME_TYPE = "JInternalFrame.frameType";
/*     */ 
/*  56 */   private static String NORMAL_FRAME = "normal";
/*     */ 
/*  59 */   private static String OPTION_DIALOG = "optionDialog";
/*     */ 
/*     */   public BEInternalFrameUI(JInternalFrame b)
/*     */   {
/*  68 */     super(b);
/*     */   }
/*     */ 
/*     */   public static ComponentUI createUI(JComponent c)
/*     */   {
/*  79 */     return new BEInternalFrameUI((JInternalFrame)c);
/*     */   }
/*     */ 
/*     */   public void installUI(JComponent c)
/*     */   {
/*  87 */     super.installUI(c);
/*     */ 
/*  95 */     Container content = this.frame.getContentPane();
/*  96 */     stripContentBorder(content);
/*     */ 
/*  99 */     this.frame.setOpaque(false);
/*     */   }
/*     */ 
/*     */   public void uninstallUI(JComponent c)
/*     */   {
/* 107 */     this.frame = ((JInternalFrame)c);
/*     */ 
/* 109 */     Container cont = ((JInternalFrame)c).getContentPane();
/* 110 */     if ((cont instanceof JComponent))
/*     */     {
/* 112 */       JComponent content = (JComponent)cont;
/* 113 */       if (content.getBorder() == handyEmptyBorder)
/*     */       {
/* 115 */         content.setBorder(null);
/*     */       }
/*     */     }
/* 118 */     super.uninstallUI(c);
/*     */   }
/*     */ 
/*     */   protected void installListeners()
/*     */   {
/* 126 */     super.installListeners();
/* 127 */     this.frame.addPropertyChangeListener(metalPropertyChangeListener);
/*     */   }
/*     */ 
/*     */   protected void uninstallListeners()
/*     */   {
/* 135 */     this.frame.removePropertyChangeListener(metalPropertyChangeListener);
/* 136 */     super.uninstallListeners();
/*     */   }
/*     */ 
/*     */   protected void installKeyboardActions()
/*     */   {
/* 144 */     super.installKeyboardActions();
/* 145 */     ActionMap map = SwingUtilities.getUIActionMap(this.frame);
/* 146 */     if (map != null)
/*     */     {
/* 150 */       map.remove("showSystemMenu");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void uninstallKeyboardActions()
/*     */   {
/* 159 */     super.uninstallKeyboardActions();
/*     */   }
/*     */ 
/*     */   protected void uninstallComponents()
/*     */   {
/* 167 */     this.titlePane = null;
/* 168 */     super.uninstallComponents();
/*     */   }
/*     */ 
/*     */   private void stripContentBorder(Object c)
/*     */   {
/* 178 */     if ((c instanceof JComponent))
/*     */     {
/* 180 */       JComponent contentComp = (JComponent)c;
/* 181 */       Border contentBorder = contentComp.getBorder();
/* 182 */       if ((contentBorder == null) || ((contentBorder instanceof UIResource)))
/*     */       {
/* 184 */         contentComp.setBorder(handyEmptyBorder);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected JComponent createNorthPane(JInternalFrame w)
/*     */   {
/* 194 */     this.titlePane = new BEInternalFrameTitlePane(w);
/* 195 */     return this.titlePane;
/*     */   }
/*     */ 
/*     */   private void setFrameType(String frameType)
/*     */   {
/* 205 */     if (frameType.equals(OPTION_DIALOG))
/*     */     {
/* 207 */       LookAndFeel.installBorder(this.frame, "InternalFrame.optionDialogBorder");
/*     */     }
/*     */     else
/*     */     {
/* 217 */       LookAndFeel.installBorder(this.frame, "InternalFrame.border");
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class XZCMetalPropertyChangeHandler
/*     */     implements PropertyChangeListener
/*     */   {
/*     */     public void propertyChange(PropertyChangeEvent e)
/*     */     {
/* 248 */       String name = e.getPropertyName();
/* 249 */       JInternalFrame jif = (JInternalFrame)e.getSource();
/*     */ 
/* 251 */       if (!(jif.getUI() instanceof BEInternalFrameUI))
/*     */       {
/* 253 */         return;
/*     */       }
/*     */ 
/* 256 */       BEInternalFrameUI ui = (BEInternalFrameUI)jif.getUI();
/* 257 */       if (name.equals(BEInternalFrameUI.FRAME_TYPE))
/*     */       {
/* 259 */         if ((e.getNewValue() instanceof String))
/*     */         {
/* 261 */           ui.setFrameType((String)e.getNewValue());
/*     */         }
/*     */ 
/*     */       }
/* 275 */       else if (name.equals("contentPane"))
/*     */       {
/* 277 */         ui.stripContentBorder(e.getNewValue());
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch10_internalframe.BEInternalFrameUI
 * JD-Core Version:    0.6.2
 */