/*     */ package org.jb2011.lnf.beautyeye.ch10_internalframe;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LayoutManager;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JInternalFrame.JDesktopIcon;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicDesktopIconUI;
/*     */ 
/*     */ public class BEDesktopIconUI extends BasicDesktopIconUI
/*     */ {
/*     */   private int width;
/*     */ 
/*     */   public static ComponentUI createUI(JComponent c)
/*     */   {
/*  45 */     return new BEDesktopIconUI();
/*     */   }
/*     */ 
/*     */   public void installDefaults()
/*     */   {
/*  54 */     super.installDefaults();
/*  55 */     this.width = UIManager.getInt("DesktopIcon.width");
/*     */   }
/*     */ 
/*     */   public void installUI(JComponent c)
/*     */   {
/*  63 */     super.installUI(c);
/*     */ 
/*  67 */     c.setOpaque(false);
/*     */   }
/*     */ 
/*     */   public void uninstallUI(JComponent c)
/*     */   {
/*  76 */     BEInternalFrameTitlePane thePane = (BEInternalFrameTitlePane)this.iconPane;
/*  77 */     super.uninstallUI(c);
/*  78 */     thePane.uninstallListeners();
/*     */   }
/*     */ 
/*     */   protected void installComponents()
/*     */   {
/*  86 */     this.iconPane = new BEInternalFrameTitlePane(this.frame)
/*     */     {
/*     */       protected void paintTitlePaneImpl(Insets frameInsets, Graphics g, int width, int height, boolean isSelected)
/*     */       {
/*  93 */         Insets instes = new Insets(0, 0, 0, 0);
/*  94 */         super.paintTitlePaneImpl(instes, g, width, height, isSelected);
/*     */       }
/*     */     };
/*  97 */     this.desktopIcon.setLayout(new BorderLayout());
/*  98 */     this.desktopIcon.add(this.iconPane, "Center");
/*     */ 
/* 105 */     this.desktopIcon.setBorder(UIManager.getBorder("InternalFrame.border"));
/*     */   }
/*     */ 
/*     */   public Dimension getPreferredSize(JComponent c)
/*     */   {
/* 117 */     return getMinimumSize(c);
/*     */   }
/*     */ 
/*     */   public Dimension getMinimumSize(JComponent c)
/*     */   {
/* 139 */     return new Dimension(this.width, 
/* 140 */       this.desktopIcon.getLayout().minimumLayoutSize(this.desktopIcon).height);
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch10_internalframe.BEDesktopIconUI
 * JD-Core Version:    0.6.2
 */