/*     */ package org.jb2011.lnf.beautyeye.ch10_internalframe;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.Rectangle;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import javax.swing.plaf.basic.BasicInternalFrameTitlePane;
/*     */ import javax.swing.plaf.basic.BasicInternalFrameTitlePane.PropertyChangeHandler;
/*     */ import javax.swing.plaf.basic.BasicInternalFrameTitlePane.TitlePaneLayout;
/*     */ import javax.swing.plaf.metal.MetalLookAndFeel;
/*     */ import org.jb2011.lnf.beautyeye.ch1_titlepane.BETitlePane;
/*     */ import org.jb2011.lnf.beautyeye.utils.MySwingUtilities2;
/*     */ import org.jb2011.lnf.beautyeye.winlnfutils.WinUtils;
/*     */ 
/*     */ public class BEInternalFrameTitlePane extends BasicInternalFrameTitlePane
/*     */ {
/*  59 */   private static final Border handyEmptyBorder = new EmptyBorder(0, 0, 0, 0);
/*     */   private String selectedBackgroundKey;
/*     */   private String selectedForegroundKey;
/*     */   private String selectedShadowKey;
/*     */   private boolean wasClosable;
/*  83 */   int buttonsWidth = 0;
/*     */ 
/*     */   public BEInternalFrameTitlePane(JInternalFrame f)
/*     */   {
/*  92 */     super(f);
/*     */   }
/*     */ 
/*     */   public void addNotify()
/*     */   {
/* 100 */     super.addNotify();
/*     */ 
/* 105 */     updateOptionPaneState();
/*     */   }
/*     */ 
/*     */   protected void installDefaults()
/*     */   {
/* 113 */     super.installDefaults();
/* 114 */     setFont(UIManager.getFont("InternalFrame.titleFont"));
/*     */ 
/* 118 */     this.wasClosable = this.frame.isClosable();
/* 119 */     this.selectedForegroundKey = (this.selectedBackgroundKey = null);
/*     */ 
/* 122 */     setOpaque(false);
/*     */   }
/*     */ 
/*     */   protected void uninstallDefaults()
/*     */   {
/* 131 */     super.uninstallDefaults();
/* 132 */     if (this.wasClosable != this.frame.isClosable())
/*     */     {
/* 134 */       this.frame.setClosable(this.wasClosable);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void createButtons()
/*     */   {
/* 143 */     super.createButtons();
/*     */ 
/* 145 */     Boolean paintActive = this.frame.isSelected() ? Boolean.TRUE : Boolean.FALSE;
/* 146 */     this.iconButton.putClientProperty("paintActive", paintActive);
/* 147 */     this.iconButton.setBorder(handyEmptyBorder);
/*     */ 
/* 149 */     this.maxButton.putClientProperty("paintActive", paintActive);
/* 150 */     this.maxButton.setBorder(handyEmptyBorder);
/*     */ 
/* 152 */     this.closeButton.putClientProperty("paintActive", paintActive);
/* 153 */     this.closeButton.setBorder(handyEmptyBorder);
/*     */ 
/* 157 */     this.closeButton.setBackground(MetalLookAndFeel.getPrimaryControlShadow());
/*     */ 
/* 161 */     this.iconButton.setContentAreaFilled(false);
/* 162 */     this.maxButton.setContentAreaFilled(false);
/* 163 */     this.closeButton.setContentAreaFilled(false);
/*     */   }
/*     */ 
/*     */   protected void assembleSystemMenu()
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void addSystemMenuItems(JMenu systemMenu)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void showSystemMenu()
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void addSubComponents()
/*     */   {
/* 199 */     add(this.iconButton);
/* 200 */     add(this.maxButton);
/* 201 */     add(this.closeButton);
/*     */   }
/*     */ 
/*     */   protected PropertyChangeListener createPropertyChangeListener()
/*     */   {
/* 209 */     return new MetalPropertyChangeHandler();
/*     */   }
/*     */ 
/*     */   protected LayoutManager createLayout()
/*     */   {
/* 217 */     return new XMetalTitlePaneLayout();
/*     */   }
/*     */ 
/*     */   public void paintComponent(Graphics g)
/*     */   {
/* 426 */     boolean leftToRight = WinUtils.isLeftToRight(this.frame);
/* 427 */     boolean isSelected = this.frame.isSelected();
/*     */ 
/* 429 */     int width = getWidth();
/* 430 */     int height = getHeight();
/*     */ 
/* 432 */     Color background = null;
/* 433 */     Color foreground = null;
/* 434 */     Color shadow = null;
/*     */ 
/* 436 */     if (isSelected)
/*     */     {
/* 444 */       if (this.selectedBackgroundKey != null)
/*     */       {
/* 446 */         background = UIManager.getColor(this.selectedBackgroundKey);
/*     */       }
/* 448 */       if (background == null)
/*     */       {
/* 450 */         background = UIManager.getColor("activeCaption");
/*     */       }
/* 452 */       if (this.selectedForegroundKey != null)
/*     */       {
/* 454 */         foreground = UIManager.getColor(this.selectedForegroundKey);
/*     */       }
/* 456 */       if (this.selectedShadowKey != null)
/*     */       {
/* 458 */         shadow = UIManager.getColor(this.selectedShadowKey);
/*     */       }
/* 460 */       if (shadow == null)
/*     */       {
/* 462 */         shadow = UIManager.getColor("activeCaptionBorder");
/*     */       }
/* 464 */       if (foreground == null)
/*     */       {
/* 466 */         foreground = UIManager.getColor("activeCaptionText");
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 477 */       background = UIManager.getColor("inactiveCaption");
/* 478 */       foreground = UIManager.getColor("inactiveCaptionText");
/* 479 */       shadow = UIManager.getColor("inactiveCaptionBorder");
/*     */     }
/*     */ 
/* 540 */     Insets frameInsets = this.frame.getInsets();
/*     */ 
/* 553 */     paintTitlePaneImpl(frameInsets, g, width, height, isSelected);
/*     */ 
/* 558 */     int titleLength = 0;
/* 559 */     int xOffset = leftToRight ? 5 : width - 5;
/* 560 */     String frameTitle = this.frame.getTitle();
/*     */ 
/* 562 */     Icon icon = this.frame.getFrameIcon();
/* 563 */     if (icon != null)
/*     */     {
/* 565 */       if (!leftToRight)
/* 566 */         xOffset -= icon.getIconWidth();
/* 567 */       int iconY = height / 2 - icon.getIconHeight() / 2;
/* 568 */       icon.paintIcon(this.frame, g, xOffset + 2, iconY + 1);
/* 569 */       xOffset += (leftToRight ? icon.getIconWidth() + 5 : -5);
/*     */     }
/*     */ 
/* 572 */     if (frameTitle != null)
/*     */     {
/* 574 */       Font f = getFont();
/* 575 */       g.setFont(f);
/* 576 */       FontMetrics fm = MySwingUtilities2.getFontMetrics(this.frame, g, f);
/* 577 */       int fHeight = fm.getHeight();
/*     */ 
/* 579 */       int yOffset = (height - fm.getHeight()) / 2 + fm.getAscent();
/*     */ 
/* 581 */       Rectangle rect = new Rectangle(0, 0, 0, 0);
/* 582 */       if (this.frame.isIconifiable())
/*     */       {
/* 584 */         rect = this.iconButton.getBounds();
/*     */       }
/* 586 */       else if (this.frame.isMaximizable())
/*     */       {
/* 588 */         rect = this.maxButton.getBounds();
/*     */       }
/* 590 */       else if (this.frame.isClosable())
/*     */       {
/* 592 */         rect = this.closeButton.getBounds();
/*     */       }
/*     */ 
/* 596 */       if (leftToRight)
/*     */       {
/* 598 */         if (rect.x == 0)
/*     */         {
/* 600 */           rect.x = (this.frame.getWidth() - this.frame.getInsets().right - 2);
/*     */         }
/* 602 */         int titleW = rect.x - xOffset - 4;
/* 603 */         frameTitle = getTitle(frameTitle, fm, titleW);
/*     */       }
/*     */       else
/*     */       {
/* 607 */         int titleW = xOffset - rect.x - rect.width - 4;
/* 608 */         frameTitle = getTitle(frameTitle, fm, titleW);
/* 609 */         xOffset -= MySwingUtilities2.stringWidth(this.frame, fm, frameTitle);
/*     */       }
/*     */ 
/* 612 */       titleLength = MySwingUtilities2.stringWidth(this.frame, fm, frameTitle);
/*     */ 
/* 616 */       g.setColor(foreground);
/*     */ 
/* 619 */       MySwingUtilities2.drawString(this.frame, g, frameTitle, xOffset, yOffset);
/*     */ 
/* 622 */       xOffset += (leftToRight ? titleLength + 5 : -5);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void paintTitlePaneImpl(Insets frameInsets, Graphics g, int width, int height, boolean isSelected)
/*     */   {
/* 638 */     BETitlePane.paintTitlePane(g, 
/* 639 */       frameInsets.left, 
/* 640 */       frameInsets.top, 
/* 641 */       width - frameInsets.left - frameInsets.right, 
/* 642 */       height, isSelected);
/*     */   }
/*     */ 
/*     */   private void updateOptionPaneState()
/*     */   {
/* 677 */     int type = -2;
/* 678 */     boolean closable = this.wasClosable;
/* 679 */     Object obj = this.frame.getClientProperty("JInternalFrame.messageType");
/*     */ 
/* 681 */     if (obj == null)
/*     */     {
/* 684 */       return;
/*     */     }
/* 686 */     if ((obj instanceof Integer))
/*     */     {
/* 688 */       type = ((Integer)obj).intValue();
/*     */     }
/* 690 */     switch (type)
/*     */     {
/*     */     case 0:
/* 693 */       this.selectedBackgroundKey = "OptionPane.errorDialog.titlePane.background";
/* 694 */       this.selectedForegroundKey = "OptionPane.errorDialog.titlePane.foreground";
/* 695 */       this.selectedShadowKey = "OptionPane.errorDialog.titlePane.shadow";
/* 696 */       closable = false;
/* 697 */       break;
/*     */     case 3:
/* 699 */       this.selectedBackgroundKey = "OptionPane.questionDialog.titlePane.background";
/* 700 */       this.selectedForegroundKey = "OptionPane.questionDialog.titlePane.foreground";
/* 701 */       this.selectedShadowKey = "OptionPane.questionDialog.titlePane.shadow";
/* 702 */       closable = false;
/* 703 */       break;
/*     */     case 2:
/* 705 */       this.selectedBackgroundKey = "OptionPane.warningDialog.titlePane.background";
/* 706 */       this.selectedForegroundKey = "OptionPane.warningDialog.titlePane.foreground";
/* 707 */       this.selectedShadowKey = "OptionPane.warningDialog.titlePane.shadow";
/* 708 */       closable = false;
/* 709 */       break;
/*     */     case -1:
/*     */     case 1:
/* 712 */       this.selectedBackgroundKey = (this.selectedForegroundKey = this.selectedShadowKey = null);
/* 713 */       closable = false;
/* 714 */       break;
/*     */     default:
/* 716 */       this.selectedBackgroundKey = (this.selectedForegroundKey = this.selectedShadowKey = null);
/*     */     }
/*     */ 
/* 719 */     if (closable != this.frame.isClosable())
/*     */     {
/* 721 */       this.frame.setClosable(closable);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void uninstallListeners()
/*     */   {
/* 733 */     super.uninstallListeners();
/*     */   }
/*     */ 
/*     */   class MetalPropertyChangeHandler extends BasicInternalFrameTitlePane.PropertyChangeHandler
/*     */   {
/*     */     MetalPropertyChangeHandler()
/*     */     {
/* 223 */       super();
/*     */     }
/*     */ 
/*     */     public void propertyChange(PropertyChangeEvent evt)
/*     */     {
/* 232 */       String prop = evt.getPropertyName();
/* 233 */       if (prop.equals("selected"))
/*     */       {
/* 235 */         Boolean b = (Boolean)evt.getNewValue();
/* 236 */         BEInternalFrameTitlePane.this.iconButton.putClientProperty("paintActive", b);
/* 237 */         BEInternalFrameTitlePane.this.closeButton.putClientProperty("paintActive", b);
/* 238 */         BEInternalFrameTitlePane.this.maxButton.putClientProperty("paintActive", b);
/*     */       }
/* 240 */       else if ("JInternalFrame.messageType".equals(prop))
/*     */       {
/* 242 */         BEInternalFrameTitlePane.this.updateOptionPaneState();
/* 243 */         BEInternalFrameTitlePane.this.frame.repaint();
/*     */       }
/* 245 */       super.propertyChange(evt);
/*     */     }
/*     */   }
/*     */ 
/*     */   class XMetalTitlePaneLayout extends BasicInternalFrameTitlePane.TitlePaneLayout
/*     */   {
/*     */     XMetalTitlePaneLayout() {
/* 252 */       super();
/*     */     }
/*     */ 
/*     */     public void addLayoutComponent(String name, Component c)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void removeLayoutComponent(Component c)
/*     */     {
/*     */     }
/*     */ 
/*     */     public Dimension preferredLayoutSize(Container c)
/*     */     {
/* 274 */       return minimumLayoutSize(c);
/*     */     }
/*     */ 
/*     */     public Dimension minimumLayoutSize(Container c)
/*     */     {
/* 283 */       int width = 30;
/* 284 */       if (BEInternalFrameTitlePane.this.frame.isClosable())
/*     */       {
/* 286 */         width += 21;
/*     */       }
/* 288 */       if (BEInternalFrameTitlePane.this.frame.isMaximizable())
/*     */       {
/* 290 */         width += 16 + (BEInternalFrameTitlePane.this.frame.isClosable() ? 10 : 4);
/*     */       }
/* 292 */       if (BEInternalFrameTitlePane.this.frame.isIconifiable())
/*     */       {
/* 295 */         width = width + (16 + (
/* 295 */           BEInternalFrameTitlePane.this.frame.isClosable() ? 10 : BEInternalFrameTitlePane.this.frame.isMaximizable() ? 2 : 
/* 295 */           4));
/*     */       }
/* 297 */       FontMetrics fm = BEInternalFrameTitlePane.this.frame.getFontMetrics(BEInternalFrameTitlePane.this.getFont());
/* 298 */       String frameTitle = BEInternalFrameTitlePane.this.frame.getTitle();
/* 299 */       int title_w = frameTitle != null ? MySwingUtilities2.stringWidth(
/* 300 */         BEInternalFrameTitlePane.this.frame, fm, frameTitle) : 0;
/* 301 */       int title_length = frameTitle != null ? frameTitle.length() : 0;
/*     */ 
/* 303 */       if (title_length > 2)
/*     */       {
/* 305 */         int subtitle_w = MySwingUtilities2.stringWidth(BEInternalFrameTitlePane.this.frame, fm, BEInternalFrameTitlePane.this.frame
/* 306 */           .getTitle().substring(0, 2) + 
/* 307 */           "...");
/* 308 */         width += (title_w < subtitle_w ? title_w : subtitle_w);
/*     */       }
/*     */       else
/*     */       {
/* 312 */         width += title_w;
/*     */       }
/*     */ 
/* 316 */       int height = 0;
/*     */ 
/* 324 */       int fontHeight = fm.getHeight();
/* 325 */       fontHeight += 4;
/* 326 */       Icon icon = BEInternalFrameTitlePane.this.frame.getFrameIcon();
/* 327 */       int iconHeight = 0;
/* 328 */       if (icon != null)
/*     */       {
/* 331 */         iconHeight = Math.min(icon.getIconHeight(), 16);
/*     */       }
/* 333 */       iconHeight += 5;
/* 334 */       height = Math.max(fontHeight, iconHeight) + 5;
/*     */ 
/* 337 */       return new Dimension(width, height);
/*     */     }
/*     */ 
/*     */     public void layoutContainer(Container c)
/*     */     {
/* 345 */       boolean leftToRight = WinUtils.isLeftToRight(BEInternalFrameTitlePane.this.frame);
/*     */ 
/* 347 */       int w = BEInternalFrameTitlePane.this.getWidth();
/* 348 */       int x = leftToRight ? w : 0;
/* 349 */       int y = 5;
/*     */ 
/* 354 */       int buttonHeight = BEInternalFrameTitlePane.this.closeButton.getIcon().getIconHeight();
/* 355 */       int buttonWidth = BEInternalFrameTitlePane.this.closeButton.getIcon().getIconWidth();
/*     */ 
/* 357 */       if (BEInternalFrameTitlePane.this.frame.isClosable())
/*     */       {
/* 370 */         int spacing = 4;
/* 371 */         x += (leftToRight ? -spacing - buttonWidth : spacing);
/* 372 */         BEInternalFrameTitlePane.this.closeButton.setBounds(x, y, buttonWidth, buttonHeight);
/* 373 */         if (!leftToRight) {
/* 374 */           x += buttonWidth;
/*     */         }
/*     */       }
/*     */ 
/* 378 */       if (BEInternalFrameTitlePane.this.frame.isMaximizable())
/*     */       {
/* 380 */         int spacing = BEInternalFrameTitlePane.this.frame.isClosable() ? 2 : 4;
/* 381 */         x += (leftToRight ? -spacing - buttonWidth : spacing);
/* 382 */         BEInternalFrameTitlePane.this.maxButton.setBounds(x, y, buttonWidth, buttonHeight);
/* 383 */         if (!leftToRight) {
/* 384 */           x += buttonWidth;
/*     */         }
/*     */       }
/* 387 */       if (BEInternalFrameTitlePane.this.frame.isIconifiable())
/*     */       {
/* 389 */         int spacing = BEInternalFrameTitlePane.this.frame.isClosable() ? 10 : BEInternalFrameTitlePane.this.frame.isMaximizable() ? 2 : 
/* 390 */           4;
/* 391 */         x += (leftToRight ? -spacing - buttonWidth : spacing);
/* 392 */         BEInternalFrameTitlePane.this.iconButton.setBounds(x, y, buttonWidth, buttonHeight);
/* 393 */         if (!leftToRight) {
/* 394 */           x += buttonWidth;
/*     */         }
/*     */       }
/* 397 */       BEInternalFrameTitlePane.this.buttonsWidth = (leftToRight ? w - x : x);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch10_internalframe.BEInternalFrameTitlePane
 * JD-Core Version:    0.6.2
 */