/*    */ package org.jb2011.lnf.beautyeye.ch10_internalframe;
/*    */ 
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.plaf.BorderUIResource;
/*    */ import javax.swing.plaf.ColorUIResource;
/*    */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*    */ import org.jb2011.lnf.beautyeye.ch1_titlepane.__IconFactory__;
/*    */ import org.jb2011.lnf.beautyeye.widget.border.BEShadowBorder;
/*    */ 
/*    */ public class __UI__
/*    */ {
/*    */   public static void uiImpl()
/*    */   {
/* 33 */     UIManager.put("InternalFrame.borderColor", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/* 34 */     UIManager.put("InternalFrame.minimizeIconBackground", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/*    */ 
/* 37 */     UIManager.put("InternalFrame.icon", 
/* 38 */       __IconFactory__.getInstance().getInternelFrameIcon());
/* 39 */     UIManager.put("InternalFrame.iconifyIcon", 
/* 40 */       __IconFactory__.getInstance().getInternalIconfiedIcon());
/* 41 */     UIManager.put("InternalFrame.minimizeIcon", 
/* 42 */       __IconFactory__.getInstance().getInternalFrameMinIcon());
/* 43 */     UIManager.put("InternalFrame.maximizeIcon", 
/* 44 */       __IconFactory__.getInstance().getInternalFrameMaxIcon());
/* 45 */     UIManager.put("InternalFrame.closeIcon", 
/* 46 */       __IconFactory__.getInstance().getInternalFrameCloseIcon());
/* 47 */     UIManager.put("InternalFrameUI", BEInternalFrameUI.class.getName());
/*    */ 
/* 51 */     Object internalFrameBorder = new BorderUIResource(new BEShadowBorder());
/* 52 */     UIManager.put("InternalFrame.border", internalFrameBorder);
/* 53 */     UIManager.put("InternalFrame.paletteBorder", internalFrameBorder);
/* 54 */     UIManager.put("InternalFrame.optionDialogBorder", internalFrameBorder);
/*    */ 
/* 58 */     UIManager.put("Desktop.background", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/*    */ 
/* 62 */     UIManager.put("DesktopIcon.width", Integer.valueOf(180));
/*    */ 
/* 64 */     UIManager.put("DesktopIconUI", BEDesktopIconUI.class.getName());
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch10_internalframe.__UI__
 * JD-Core Version:    0.6.2
 */