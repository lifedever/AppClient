/*     */ package org.jb2011.lnf.beautyeye.winlnfutils;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.ComponentOrientation;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.UIManager;
/*     */ import org.jb2011.lnf.beautyeye.utils.MySwingUtilities2;
/*     */ 
/*     */ public class WinUtils
/*     */ {
/*  38 */   private static boolean isMnemonicHidden = true;
/*     */ 
/*     */   public static boolean isMnemonicHidden()
/*     */   {
/*  48 */     if (UIManager.getBoolean("Button.showMnemonics"))
/*     */     {
/*  50 */       isMnemonicHidden = false;
/*     */     }
/*  52 */     return isMnemonicHidden;
/*     */   }
/*     */ 
/*     */   public static boolean isOnVista()
/*     */   {
/*  61 */     boolean rv = false;
/*  62 */     String osName = System.getProperty("os.name");
/*  63 */     String osVers = System.getProperty("os.version");
/*  64 */     if ((osName != null) && 
/*  65 */       (osName.startsWith("Windows")) && 
/*  66 */       (osVers != null) && 
/*  67 */       (osVers.length() > 0))
/*     */     {
/*  69 */       int p = osVers.indexOf('.');
/*  70 */       if (p >= 0) {
/*  71 */         osVers = osVers.substring(0, p);
/*     */       }
/*     */       try
/*     */       {
/*  75 */         rv = Integer.parseInt(osVers) >= 6;
/*     */       } catch (NumberFormatException localNumberFormatException) {
/*     */       }
/*     */     }
/*  79 */     return rv;
/*     */   }
/*     */ 
/*     */   public static void paintText(Graphics g, AbstractButton b, Rectangle textRect, String text, int textShiftOffset)
/*     */   {
/* 100 */     FontMetrics fm = MySwingUtilities2.getFontMetrics(
/* 101 */       b, g);
/*     */ 
/* 103 */     int mnemIndex = b.getDisplayedMnemonicIndex();
/*     */ 
/* 106 */     if (isMnemonicHidden()) {
/* 107 */       mnemIndex = -1;
/*     */     }
/*     */ 
/* 119 */     paintClassicText(b, g, textRect.x + textShiftOffset, 
/* 120 */       textRect.y + fm.getAscent() + textShiftOffset, 
/* 121 */       text, mnemIndex);
/*     */   }
/*     */ 
/*     */   static void paintClassicText(AbstractButton b, Graphics g, int x, int y, String text, int mnemIndex)
/*     */   {
/* 137 */     ButtonModel model = b.getModel();
/*     */ 
/* 140 */     Color color = b.getForeground();
/* 141 */     if (model.isEnabled())
/*     */     {
/* 143 */       if (((!(b instanceof JMenuItem)) || (!model.isArmed())) && (
/* 144 */         (!(b instanceof JMenu)) || ((!model.isSelected()) && (!model.isRollover()))))
/*     */       {
/* 150 */         g.setColor(b.getForeground());
/*     */       }
/*     */ 
/* 153 */       MySwingUtilities2.drawStringUnderlineCharAt(b, 
/* 154 */         g, text, mnemIndex, x, y);
/*     */     } else {
/* 156 */       color = UIManager.getColor("Button.shadow");
/* 157 */       Color shadow = UIManager.getColor("Button.disabledShadow");
/* 158 */       if (model.isArmed()) {
/* 159 */         color = UIManager.getColor("Button.disabledForeground");
/*     */       } else {
/* 161 */         if (shadow == null) {
/* 162 */           shadow = b.getBackground().darker();
/*     */         }
/* 164 */         g.setColor(shadow);
/*     */ 
/* 167 */         MySwingUtilities2.drawStringUnderlineCharAt(b, g, text, mnemIndex, 
/* 168 */           x + 1, y + 1);
/*     */       }
/* 170 */       if (color == null) {
/* 171 */         color = b.getBackground().brighter();
/*     */       }
/* 173 */       g.setColor(color);
/*     */ 
/* 175 */       MySwingUtilities2.drawStringUnderlineCharAt(
/* 176 */         b, g, text, mnemIndex, x, y);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean isLeftToRight(Component c)
/*     */   {
/* 221 */     return c.getComponentOrientation().isLeftToRight();
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.winlnfutils.WinUtils
 * JD-Core Version:    0.6.2
 */