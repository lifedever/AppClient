/*     */ package org.jb2011.lnf.beautyeye.ch8_toolbar;
/*     */ 
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.ComponentOrientation;
/*     */ import java.awt.Container;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.event.ContainerEvent;
/*     */ import java.awt.event.ContainerListener;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JToolBar;
/*     */ import javax.swing.SwingConstants;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.AbstractBorder;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.basic.BasicToolBarUI;
/*     */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.__UseParentPaintSurported;
/*     */ import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI.XPEmptyBorder;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class BEToolBarUI extends BasicToolBarUI
/*     */   implements BeautyEyeLNFHelper.__UseParentPaintSurported
/*     */ {
/*     */   public static ComponentUI createUI(JComponent c)
/*     */   {
/*  69 */     return new BEToolBarUI();
/*     */   }
/*     */ 
/*     */   protected void installDefaults()
/*     */   {
/*  79 */     setRolloverBorders(true);
/*     */ 
/*  81 */     super.installDefaults();
/*     */   }
/*     */ 
/*     */   public boolean isUseParentPaint()
/*     */   {
/*  99 */     return (this.toolBar != null) && 
/*  99 */       (!(this.toolBar.getBackground() instanceof UIResource));
/*     */   }
/*     */ 
/*     */   protected Border createRolloverBorder()
/*     */   {
/* 107 */     return new EmptyBorder(3, 3, 3, 3);
/*     */   }
/*     */ 
/*     */   protected Border createNonRolloverBorder()
/*     */   {
/* 115 */     return new EmptyBorder(3, 3, 3, 3);
/*     */   }
/*     */ 
/*     */   public void paint(Graphics g, JComponent c)
/*     */   {
/* 129 */     boolean isPaintPlainBackground = false;
/* 130 */     String isPaintPlainBackgroundKey = "ToolBar.isPaintPlainBackground";
/*     */ 
/* 132 */     Object isPaintPlainBackgroundObj = c.getClientProperty(isPaintPlainBackgroundKey);
/*     */ 
/* 134 */     if (isPaintPlainBackgroundObj == null)
/* 135 */       isPaintPlainBackgroundObj = Boolean.valueOf(UIManager.getBoolean(isPaintPlainBackgroundKey));
/* 136 */     if (isPaintPlainBackgroundObj != null) {
/* 137 */       isPaintPlainBackground = ((Boolean)isPaintPlainBackgroundObj).booleanValue();
/*     */     }
/*     */ 
/* 140 */     if ((isPaintPlainBackground) || (isUseParentPaint()))
/*     */     {
/* 142 */       super.paint(g, c);
/*     */     }
/*     */     else
/*     */     {
/* 147 */       NinePatch np = __Icon9Factory__.getInstance().getToolBarBg_NORTH();
/*     */ 
/* 149 */       Container parent = this.toolBar.getParent();
/* 150 */       if (parent != null)
/*     */       {
/* 152 */         LayoutManager lm = parent.getLayout();
/* 153 */         if ((lm instanceof BorderLayout))
/*     */         {
/* 155 */           Object cons = ((BorderLayout)lm).getConstraints(this.toolBar);
/* 156 */           if (cons != null)
/*     */           {
/* 158 */             if (cons.equals("North"))
/* 159 */               np = __Icon9Factory__.getInstance().getToolBarBg_NORTH();
/* 160 */             else if (cons.equals("South"))
/* 161 */               np = __Icon9Factory__.getInstance().getToolBarBg_SOUTH();
/* 162 */             else if (cons.equals("West"))
/* 163 */               np = __Icon9Factory__.getInstance().getToolBarBg_WEST();
/* 164 */             else if (cons.equals("East"))
/* 165 */               np = __Icon9Factory__.getInstance().getToolBarBg_EAST();
/*     */           }
/*     */         }
/*     */       }
/* 169 */       np.draw((Graphics2D)g, 0, 0, c.getWidth(), c.getHeight());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Border getRolloverBorder(AbstractButton b)
/*     */   {
/* 183 */     return new BEButtonUI.XPEmptyBorder(new Insets(3, 3, 3, 3));
/*     */   }
/*     */ 
/*     */   protected ContainerListener createToolBarContListener()
/*     */   {
/* 197 */     return new ToolBarContListenerJb2011();
/*     */   }
/*     */ 
/*     */   public static class ToolBarBorder extends AbstractBorder
/*     */     implements UIResource, SwingConstants
/*     */   {
/*     */     protected Color shadow;
/*     */     protected Color highlight;
/*     */     protected Insets insets;
/*     */ 
/*     */     public ToolBarBorder(Color shadow, Color highlight, Insets insets)
/*     */     {
/* 273 */       this.highlight = highlight;
/* 274 */       this.shadow = shadow;
/* 275 */       this.insets = insets;
/*     */     }
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/*     */     {
/* 283 */       g.translate(x, y);
/*     */ 
/* 286 */       if (((JToolBar)c).isFloatable())
/*     */       {
/* 288 */         boolean vertical = ((JToolBar)c).getOrientation() == 1;
/*     */ 
/* 291 */         Stroke oldStroke = ((Graphics2D)g).getStroke();
/* 292 */         Stroke sroke = new BasicStroke(1.0F, 0, 
/* 293 */           2, 0.0F, new float[] { 1.0F, 1.0F }, 0.0F);
/* 294 */         ((Graphics2D)g).setStroke(sroke);
/*     */ 
/* 296 */         if (!vertical)
/*     */         {
/* 298 */           int gap_top = 8; int gap_bottom = 8;
/* 299 */           if (c.getComponentOrientation().isLeftToRight())
/*     */           {
/* 301 */             int drawX = 3;
/* 302 */             drawTouchH(g, drawX, gap_top - 1, drawX, height - gap_bottom - 1);
/*     */           }
/*     */           else
/*     */           {
/* 306 */             int drawX = 2;
/* 307 */             drawTouchH(g, width - drawX, gap_top - 1, width - drawX, height - gap_bottom - 1);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 312 */           int gap_left = 8; int gap_right = 8;
/* 313 */           int drawY = 3;
/* 314 */           drawTouchV(g, gap_left - 1, drawY, width - gap_right - 1, drawY);
/*     */         }
/*     */ 
/* 317 */         ((Graphics2D)g).setStroke(oldStroke);
/*     */       }
/*     */ 
/* 320 */       g.translate(-x, -y);
/*     */     }
/*     */ 
/*     */     private void drawTouchH(Graphics g, int x1, int y1, int x2, int y2)
/*     */     {
/* 327 */       g.setColor(this.shadow);
/* 328 */       g.drawLine(x1, y1, x1, y2 - 1);
/*     */ 
/* 330 */       g.setColor(this.highlight);
/* 331 */       g.drawLine(x1 + 1, y1 + 1, x1 + 1, y2);
/*     */ 
/* 334 */       g.setColor(this.shadow);
/* 335 */       g.drawLine(x1 + 2, y1, x1 + 2, y2 - 1);
/*     */ 
/* 337 */       g.setColor(this.highlight);
/* 338 */       g.drawLine(x1 + 3, y1 + 1, x1 + 3, y2);
/*     */     }
/*     */ 
/*     */     private void drawTouchV(Graphics g, int x1, int y1, int x2, int y2)
/*     */     {
/* 344 */       g.setColor(this.shadow);
/* 345 */       g.drawLine(x1, y1, x2 - 1, y2);
/*     */ 
/* 347 */       g.setColor(this.highlight);
/* 348 */       g.drawLine(x1 + 1, y1 + 1, x2, y2 + 1);
/*     */ 
/* 351 */       g.setColor(this.shadow);
/* 352 */       g.drawLine(x1, y1 + 2, x2 - 1, y2 + 2);
/*     */ 
/* 354 */       g.setColor(this.highlight);
/* 355 */       g.drawLine(x1 + 1, y1 + 3, x2, y2 + 3);
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c)
/*     */     {
/* 365 */       Insets DEFAILT_IS = this.insets;
/* 366 */       Insets is = DEFAILT_IS;
/* 367 */       if ((c instanceof JToolBar))
/*     */       {
/* 369 */         Container parent = c.getParent();
/* 370 */         if (parent != null)
/*     */         {
/* 372 */           LayoutManager lm = parent.getLayout();
/* 373 */           if ((lm instanceof BorderLayout))
/*     */           {
/* 375 */             Object cons = ((BorderLayout)lm).getConstraints((JToolBar)c);
/* 376 */             if (cons != null)
/*     */             {
/* 378 */               if (cons.equals("North"))
/* 379 */                 is = DEFAILT_IS;
/* 380 */               else if (cons.equals("South"))
/* 381 */                 is = new Insets(DEFAILT_IS.bottom, 0, DEFAILT_IS.top, 0);
/* 382 */               else if (cons.equals("West"))
/* 383 */                 is = new Insets(0, DEFAILT_IS.top, 0, DEFAILT_IS.bottom);
/* 384 */               else if (cons.equals("East")) {
/* 385 */                 is = new Insets(0, DEFAILT_IS.bottom, 0, DEFAILT_IS.top);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 391 */       return getBorderInsets(c, is);
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c, Insets insets)
/*     */     {
/* 399 */       if (((JToolBar)c).isFloatable())
/*     */       {
/* 402 */         int gripInset = 9;
/* 403 */         if (((JToolBar)c).getOrientation() == 0)
/*     */         {
/* 405 */           if (c.getComponentOrientation().isLeftToRight())
/* 406 */             insets.left = gripInset;
/*     */           else
/* 408 */             insets.right = gripInset;
/*     */         }
/*     */         else
/* 411 */           insets.top = gripInset;
/*     */       }
/* 413 */       return insets;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class ToolBarContListenerJb2011
/*     */     implements ContainerListener
/*     */   {
/*     */     protected ToolBarContListenerJb2011()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void componentAdded(ContainerEvent evt)
/*     */     {
/* 212 */       Component c = evt.getChild();
/*     */ 
/* 214 */       if (BEToolBarUI.this.toolBarFocusListener != null) {
/* 215 */         c.addFocusListener(BEToolBarUI.this.toolBarFocusListener);
/*     */       }
/*     */ 
/* 218 */       if (BEToolBarUI.this.isRolloverBorders()) {
/* 219 */         BEToolBarUI.this.setBorderToRollover(c);
/*     */       }
/*     */       else
/*     */       {
/* 223 */         BEToolBarUI.this.setBorderToNonRollover(c);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void componentRemoved(ContainerEvent evt)
/*     */     {
/* 240 */       Component c = evt.getChild();
/*     */ 
/* 242 */       if (BEToolBarUI.this.toolBarFocusListener != null) {
/* 243 */         c.removeFocusListener(BEToolBarUI.this.toolBarFocusListener);
/*     */       }
/*     */ 
/* 247 */       BEToolBarUI.this.setBorderToNormal(c);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch8_toolbar.BEToolBarUI
 * JD-Core Version:    0.6.2
 */