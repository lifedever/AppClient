/*    */ package org.jb2011.lnf.beautyeye.ch8_toolbar;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.plaf.BorderUIResource;
/*    */ import javax.swing.plaf.ColorUIResource;
/*    */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*    */ 
/*    */ public class __UI__
/*    */ {
/*    */   public static void uiImpl()
/*    */   {
/* 38 */     UIManager.put("ToolBar.isPaintPlainBackground", Boolean.FALSE);
/*    */ 
/* 40 */     UIManager.put("ToolBar.shadow", new ColorUIResource(new Color(180, 183, 187)));
/*    */ 
/* 42 */     UIManager.put("ToolBar.highlight", new ColorUIResource(Color.white));
/* 43 */     UIManager.put("ToolBar.dockingBackground", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/* 44 */     UIManager.put("ToolBar.floatingBackground", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/* 45 */     UIManager.put("ToolBar.background", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/* 46 */     UIManager.put("ToolBar.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/*    */ 
/* 48 */     UIManager.put("ToolBar.border", new BorderUIResource(
/* 50 */       new BEToolBarUI.ToolBarBorder(UIManager.getColor("ToolBar.shadow"), 
/* 51 */       UIManager.getColor("ToolBar.highlight"), new Insets(6, 0, 11, 0))));
/*    */ 
/* 54 */     UIManager.put("ToolBarSeparatorUI", 
/* 55 */       BEToolBarSeparatorUI.class.getName());
/* 56 */     UIManager.put("ToolBarUI", BEToolBarUI.class.getName());
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch8_toolbar.__UI__
 * JD-Core Version:    0.6.2
 */