/*     */ package org.jb2011.lnf.beautyeye.ch8_toolbar;
/*     */ 
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Stroke;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JSeparator;
/*     */ import javax.swing.JToolBar.Separator;
/*     */ import javax.swing.UIDefaults;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicToolBarSeparatorUI;
/*     */ 
/*     */ public class BEToolBarSeparatorUI extends BasicToolBarSeparatorUI
/*     */ {
/*     */   public static ComponentUI createUI(JComponent c)
/*     */   {
/*  48 */     return new BEToolBarSeparatorUI();
/*     */   }
/*     */ 
/*     */   public Dimension getPreferredSize(JComponent c)
/*     */   {
/*  56 */     Dimension size = ((JToolBar.Separator)c).getSeparatorSize();
/*     */ 
/*  58 */     if (size != null)
/*     */     {
/*  60 */       size = size.getSize();
/*     */     }
/*     */     else
/*     */     {
/*  64 */       size = new Dimension(6, 6);
/*     */ 
/*  74 */       if (((JSeparator)c).getOrientation() == 1)
/*     */       {
/*  76 */         size.height = 0;
/*     */       }
/*     */       else
/*     */       {
/*  80 */         size.width = 0;
/*     */       }
/*     */     }
/*  83 */     return size;
/*     */   }
/*     */ 
/*     */   public Dimension getMaximumSize(JComponent c)
/*     */   {
/*  90 */     Dimension pref = getPreferredSize(c);
/*  91 */     if (((JSeparator)c).getOrientation() == 1) {
/*  92 */       return new Dimension(pref.width, 32767);
/*     */     }
/*  94 */     return new Dimension(32767, pref.height);
/*     */   }
/*     */ 
/*     */   public void paint(Graphics g, JComponent c)
/*     */   {
/* 103 */     boolean vertical = ((JSeparator)c).getOrientation() == 1;
/* 104 */     Dimension size = c.getSize();
/*     */ 
/* 107 */     Stroke oldStroke = ((Graphics2D)g).getStroke();
/* 108 */     Stroke sroke = new BasicStroke(1.0F, 0, 
/* 109 */       2, 0.0F, new float[] { 2.0F, 2.0F }, 0.0F);
/* 110 */     ((Graphics2D)g).setStroke(sroke);
/*     */ 
/* 112 */     Color temp = g.getColor();
/* 113 */     UIDefaults table = UIManager.getLookAndFeelDefaults();
/* 114 */     Color shadow = table.getColor("ToolBar.shadow");
/* 115 */     Color highlight = table.getColor("ToolBar.highlight");
/*     */ 
/* 120 */     if (vertical)
/*     */     {
/* 122 */       int x = size.width / 2 - 1;
/*     */ 
/* 128 */       g.setColor(shadow);
/* 129 */       g.drawLine(x + 1, 2, x + 1, size.height - 2);
/*     */     }
/*     */     else
/*     */     {
/* 139 */       int y = size.height / 2 - 1;
/* 140 */       g.setColor(shadow);
/* 141 */       g.drawLine(2, y, size.width - 2, y);
/*     */ 
/* 143 */       g.setColor(highlight);
/* 144 */       g.drawLine(2, y + 1, size.width - 2, y + 1);
/*     */     }
/* 146 */     g.setColor(temp);
/*     */ 
/* 149 */     ((Graphics2D)g).setStroke(oldStroke);
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch8_toolbar.BEToolBarSeparatorUI
 * JD-Core Version:    0.6.2
 */