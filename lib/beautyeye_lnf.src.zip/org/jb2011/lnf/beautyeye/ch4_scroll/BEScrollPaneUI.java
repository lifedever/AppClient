/*    */ package org.jb2011.lnf.beautyeye.ch4_scroll;
/*    */ 
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.JScrollPane;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.basic.BasicScrollPaneUI;
/*    */ 
/*    */ public class BEScrollPaneUI extends BasicScrollPaneUI
/*    */ {
/*    */   public static ComponentUI createUI(JComponent x)
/*    */   {
/* 35 */     return new BEScrollPaneUI();
/*    */   }
/*    */ 
/*    */   protected void installDefaults(JScrollPane scrollpane)
/*    */   {
/* 43 */     super.installDefaults(scrollpane);
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch4_scroll.BEScrollPaneUI
 * JD-Core Version:    0.6.2
 */