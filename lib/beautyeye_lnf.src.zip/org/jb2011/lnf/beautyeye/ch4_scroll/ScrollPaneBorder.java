/*    */ package org.jb2011.lnf.beautyeye.ch4_scroll;
/*    */ 
/*    */ import java.awt.Insets;
/*    */ import org.jb2011.lnf.beautyeye.widget.border.NinePatchBorder;
/*    */ 
/*    */ public class ScrollPaneBorder extends NinePatchBorder
/*    */ {
/*    */   public ScrollPaneBorder()
/*    */   {
/* 32 */     super(new Insets(6, 6, 8, 6), 
/* 32 */       __Icon9Factory__.getInstance().getScrollPaneBorderBg());
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch4_scroll.ScrollPaneBorder
 * JD-Core Version:    0.6.2
 */