/*     */ package org.jb2011.lnf.beautyeye.ch4_scroll;
/*     */ 
/*     */ import org.jb2011.lnf.beautyeye.utils.NinePatchHelper;
/*     */ import org.jb2011.lnf.beautyeye.utils.RawCache;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class __Icon9Factory__ extends RawCache<NinePatch>
/*     */ {
/*     */   public static final String IMGS_ROOT = "imgs/np";
/*  30 */   private static __Icon9Factory__ instance = null;
/*     */ 
/*     */   public static __Icon9Factory__ getInstance()
/*     */   {
/*  39 */     if (instance == null)
/*  40 */       instance = new __Icon9Factory__();
/*  41 */     return instance;
/*     */   }
/*     */ 
/*     */   protected NinePatch getResource(String relativePath, Class baseClass)
/*     */   {
/*  50 */     return NinePatchHelper.createNinePatch(baseClass.getResource(relativePath), false);
/*     */   }
/*     */ 
/*     */   public NinePatch getRaw(String relativePath)
/*     */   {
/*  61 */     return (NinePatch)getRaw(relativePath, getClass());
/*     */   }
/*     */ 
/*     */   public NinePatch getScrollBar_v()
/*     */   {
/*  72 */     return getRaw("imgs/np/scroll_bar_v.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getScrollBar_rover_v()
/*     */   {
/*  82 */     return getRaw("imgs/np/scroll_bar_rover_v.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getScrollBar_pressed_v()
/*     */   {
/*  92 */     return getRaw("imgs/np/scroll_bar_pressed_v.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getScrollBar_h()
/*     */   {
/* 102 */     return getRaw("imgs/np/scroll_bar_h.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getScrollBar_rover_h()
/*     */   {
/* 112 */     return getRaw("imgs/np/scroll_bar_rover_h.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getScrollBar_pressed_h()
/*     */   {
/* 122 */     return getRaw("imgs/np/scroll_bar_pressed_h.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getScrollBarArrow_toBottom()
/*     */   {
/* 132 */     return getRaw("imgs/np/arrow_toBottom.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getScrollBarArrow_toTop()
/*     */   {
/* 142 */     return getRaw("imgs/np/arrow_toTop.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getScrollBarArrow_toLeft()
/*     */   {
/* 152 */     return getRaw("imgs/np/arrow_toLeft.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getScrollBarArrow_toRight()
/*     */   {
/* 162 */     return getRaw("imgs/np/arrow_toRight.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getScrollBarArrow_toTop_rover()
/*     */   {
/* 172 */     return getRaw("imgs/np/arrow_toTop_rover.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getScrollBarArrow_toBottom_rover()
/*     */   {
/* 182 */     return getRaw("imgs/np/arrow_toBottom_rover.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getScrollBarArrow_toLeft_rover()
/*     */   {
/* 192 */     return getRaw("imgs/np/arrow_toLeft_rover.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getScrollBarArrow_toRight_rover()
/*     */   {
/* 202 */     return getRaw("imgs/np/arrow_toRight_rover.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getScrollPaneBorderBg()
/*     */   {
/* 212 */     return getRaw("imgs/np/scroll_pane_bg1.9.png");
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch4_scroll.__Icon9Factory__
 * JD-Core Version:    0.6.2
 */