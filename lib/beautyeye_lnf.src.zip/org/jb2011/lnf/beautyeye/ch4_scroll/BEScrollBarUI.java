/*     */ package org.jb2011.lnf.beautyeye.ch4_scroll;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Paint;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JScrollBar;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicArrowButton;
/*     */ import javax.swing.plaf.basic.BasicScrollBarUI;
/*     */ import org.jb2011.lnf.beautyeye.utils.BEUtils;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class BEScrollBarUI extends BasicScrollBarUI
/*     */ {
/*     */   public static ComponentUI createUI(JComponent c)
/*     */   {
/*  52 */     return new BEScrollBarUI();
/*     */   }
/*     */ 
/*     */   protected JButton createDecreaseButton(int orientation)
/*     */   {
/*  60 */     return new WindowsArrowButton(orientation, 
/*  61 */       UIManager.getColor("ScrollBar.thumb"), 
/*  62 */       UIManager.getColor("ScrollBar.thumbShadow"), 
/*  63 */       UIManager.getColor("ScrollBar.thumbDarkShadow"), 
/*  64 */       UIManager.getColor("ScrollBar.thumbHighlight"));
/*     */   }
/*     */ 
/*     */   protected JButton createIncreaseButton(int orientation)
/*     */   {
/*  72 */     return new WindowsArrowButton(orientation, 
/*  73 */       UIManager.getColor("ScrollBar.thumb"), 
/*  74 */       UIManager.getColor("ScrollBar.thumbShadow"), 
/*  75 */       UIManager.getColor("ScrollBar.thumbDarkShadow"), 
/*  76 */       UIManager.getColor("ScrollBar.thumbHighlight"));
/*     */   }
/*     */ 
/*     */   protected void paintTrack(Graphics g, JComponent c, Rectangle trackBounds)
/*     */   {
/* 231 */     if ((c == null) || (g == null))
/* 232 */       return;
/* 233 */     Graphics2D g2 = (Graphics2D)g;
/*     */ 
/* 235 */     Paint oldp = g2.getPaint();
/* 236 */     int w = trackBounds.width;
/* 237 */     int h = trackBounds.height;
/* 238 */     int x = trackBounds.x;
/* 239 */     int y = trackBounds.y;
/*     */ 
/* 241 */     if (this.scrollbar.getOrientation() == 1)
/*     */     {
/* 254 */       int hhhWidth = 5;
/* 255 */       int px = (w - hhhWidth) / 2;
/* 256 */       int delta = 50;
/*     */ 
/* 258 */       g2.setColor(new Color(150 + delta, 151 + delta, 146 + delta));
/* 259 */       g2.drawLine(px + 0, y + 10, px + 0, y + h - 10);
/*     */ 
/* 261 */       g2.setColor(new Color(160 + delta, 160 + delta, 162 + delta));
/* 262 */       g2.drawLine(px + 1, y + 10, px + 1, y + h - 10);
/*     */ 
/* 264 */       g2.setColor(new Color(163 + delta, 162 + delta, 167 + delta));
/* 265 */       g2.drawLine(px + 2, y + 10, px + 2, y + h - 10);
/*     */ 
/* 267 */       g2.setColor(new Color(162 + delta, 162 + delta, 162 + delta));
/* 268 */       g2.drawLine(px + 3, y + 10, px + 3, y + h - 10);
/*     */ 
/* 270 */       g2.setColor(new Color(150 + delta, 150 + delta, 150 + delta));
/* 271 */       g2.drawLine(px + 4, y + 10, px + 4, y + h - 10);
/*     */     }
/*     */     else
/*     */     {
/* 286 */       int hhhWidth = 5;
/* 287 */       int py = (h - hhhWidth) / 2;
/* 288 */       int delta = 50;
/*     */ 
/* 290 */       g2.setColor(new Color(150 + delta, 151 + delta, 146 + delta));
/* 291 */       g2.drawLine(x + 10, py + 0, x + w - 10, py + 0);
/*     */ 
/* 293 */       g2.setColor(new Color(160 + delta, 160 + delta, 162 + delta));
/* 294 */       g2.drawLine(x + 10, py + 1, x + w - 10, py + 1);
/*     */ 
/* 296 */       g2.setColor(new Color(163 + delta, 162 + delta, 167 + delta));
/* 297 */       g2.drawLine(x + 10, py + 2, x + w - 10, py + 2);
/*     */ 
/* 299 */       g2.setColor(new Color(162 + delta, 162 + delta, 162 + delta));
/* 300 */       g2.drawLine(x + 10, py + 3, x + w - 10, py + 3);
/*     */ 
/* 302 */       g2.setColor(new Color(150 + delta, 150 + delta, 150 + delta));
/* 303 */       g2.drawLine(x + 10, py + 4, x + w - 10, py + 4);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds)
/*     */   {
/* 316 */     if ((thumbBounds.isEmpty()) || (!this.scrollbar.isEnabled()))
/*     */     {
/* 318 */       return;
/*     */     }
/* 320 */     Graphics2D g2 = (Graphics2D)g;
/* 321 */     int w = thumbBounds.width - 4;
/* 322 */     int h = thumbBounds.height - 4;
/* 323 */     g2.translate(thumbBounds.x + 2, thumbBounds.y + 2);
/*     */ 
/* 326 */     BEUtils.setAntiAliasing(g2, true);
/*     */ 
/* 328 */     if (this.scrollbar.getOrientation() == 1)
/*     */     {
/* 333 */       NinePatch np = null;
/* 334 */       if (this.isDragging)
/* 335 */         np = __Icon9Factory__.getInstance().getScrollBar_pressed_v();
/* 336 */       else if (isThumbRollover())
/* 337 */         np = __Icon9Factory__.getInstance().getScrollBar_rover_v();
/*     */       else {
/* 339 */         np = __Icon9Factory__.getInstance().getScrollBar_v();
/*     */       }
/*     */ 
/* 342 */       if (h < np.getHeight())
/* 343 */         paintThumbIfSoSmall(g2, 0, 0, w, h);
/*     */       else {
/* 345 */         np.draw(g2, 0, 0, w, h);
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 352 */       NinePatch np = null;
/* 353 */       if (this.isDragging)
/* 354 */         np = __Icon9Factory__.getInstance().getScrollBar_pressed_h();
/* 355 */       else if (isThumbRollover())
/* 356 */         np = __Icon9Factory__.getInstance().getScrollBar_rover_h();
/*     */       else {
/* 358 */         np = __Icon9Factory__.getInstance().getScrollBar_h();
/*     */       }
/*     */ 
/* 361 */       if (w < np.getWidth())
/* 362 */         paintThumbIfSoSmall(g2, 0, 0, w, h);
/*     */       else {
/* 364 */         np.draw(g2, 0, 0, w, h);
/*     */       }
/*     */     }
/* 367 */     g2.translate(-thumbBounds.x, -thumbBounds.y);
/*     */ 
/* 369 */     BEUtils.setAntiAliasing(g2, false);
/*     */   }
/*     */ 
/*     */   protected void paintThumbIfSoSmall(Graphics2D g2, int x, int y, int w, int h)
/*     */   {
/* 385 */     int NORMAL_ARC = 6;
/*     */ 
/* 387 */     int arc = (w <= 6) || (h <= 6) ? 0 : 6;
/* 388 */     g2.setColor(this.thumbDarkShadowColor);
/* 389 */     g2.drawRoundRect(x, y, w - 1, h - 1, arc, arc);
/* 390 */     g2.setColor(this.thumbColor);
/* 391 */     g2.fillRoundRect(x + 1, y + 1, w - 2, h - 2, arc, arc);
/*     */   }
/*     */ 
/*     */   protected class WindowsArrowButton extends BasicArrowButton
/*     */   {
/*     */     public WindowsArrowButton(int direction, Color background, Color shadow, Color darkShadow, Color highlight)
/*     */     {
/*  99 */       super(background, shadow, darkShadow, highlight);
/*     */     }
/*     */ 
/*     */     public WindowsArrowButton(int direction)
/*     */     {
/* 108 */       super();
/*     */     }
/*     */ 
/*     */     public void paint(Graphics g)
/*     */     {
/* 119 */       ButtonModel model = getModel();
/*     */ 
/* 166 */       Graphics2D g2 = (Graphics2D)g;
/* 167 */       switch (this.direction)
/*     */       {
/*     */       case 1:
/* 170 */         if (model.isRollover())
/* 171 */           __Icon9Factory__.getInstance().getScrollBarArrow_toTop_rover().draw(g2, 0, 0, getWidth(), getHeight());
/*     */         else
/* 173 */           __Icon9Factory__.getInstance().getScrollBarArrow_toTop().draw(g2, 0, 0, getWidth(), getHeight());
/* 174 */         break;
/*     */       case 5:
/* 176 */         if (model.isRollover())
/* 177 */           __Icon9Factory__.getInstance().getScrollBarArrow_toBottom_rover().draw(g2, 0, 0, getWidth(), getHeight());
/*     */         else
/* 179 */           __Icon9Factory__.getInstance().getScrollBarArrow_toBottom().draw(g2, 0, 0, getWidth(), getHeight());
/* 180 */         break;
/*     */       case 7:
/* 182 */         if (model.isRollover())
/* 183 */           __Icon9Factory__.getInstance().getScrollBarArrow_toLeft_rover().draw(g2, 0, 0, getWidth(), getHeight());
/*     */         else
/* 185 */           __Icon9Factory__.getInstance().getScrollBarArrow_toLeft().draw(g2, 0, 0, getWidth(), getHeight());
/* 186 */         break;
/*     */       case 3:
/* 188 */         if (model.isRollover())
/* 189 */           __Icon9Factory__.getInstance().getScrollBarArrow_toRight_rover().draw(g2, 0, 0, getWidth(), getHeight());
/*     */         else
/* 191 */           __Icon9Factory__.getInstance().getScrollBarArrow_toRight().draw(g2, 0, 0, getWidth(), getHeight());
/*     */         break;
/*     */       case 2:
/*     */       case 4:
/*     */       case 6:
/*     */       }
/*     */     }
/*     */ 
/*     */     public Dimension getPreferredSize()
/*     */     {
/* 206 */       int size = 16;
/* 207 */       if (BEScrollBarUI.this.scrollbar != null)
/*     */       {
/* 209 */         switch (BEScrollBarUI.this.scrollbar.getOrientation())
/*     */         {
/*     */         case 1:
/* 212 */           size = BEScrollBarUI.this.scrollbar.getWidth();
/* 213 */           break;
/*     */         case 0:
/* 215 */           size = BEScrollBarUI.this.scrollbar.getHeight();
/*     */         }
/*     */ 
/* 218 */         size = Math.max(size, 5);
/*     */       }
/* 220 */       return new Dimension(size, size);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch4_scroll.BEScrollBarUI
 * JD-Core Version:    0.6.2
 */