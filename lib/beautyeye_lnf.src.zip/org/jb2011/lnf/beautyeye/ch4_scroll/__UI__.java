/*    */ package org.jb2011.lnf.beautyeye.ch4_scroll;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.plaf.BorderUIResource;
/*    */ import javax.swing.plaf.ColorUIResource;
/*    */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*    */ 
/*    */ public class __UI__
/*    */ {
/*    */   public static void uiImpl()
/*    */   {
/* 34 */     UIManager.put("Viewport.background", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/* 35 */     UIManager.put("Viewport.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/*    */ 
/* 38 */     UIManager.put("ScrollPane.border", new BorderUIResource(new ScrollPaneBorder()));
/* 39 */     UIManager.put("ScrollPane.background", new ColorUIResource(Color.white));
/* 40 */     UIManager.put("ScrollPane.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/* 41 */     UIManager.put("ScrollPaneUI", BEScrollPaneUI.class.getName());
/*    */ 
/* 44 */     UIManager.put("ScrollBar.thumb", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/* 45 */     UIManager.put("ScrollBar.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/* 46 */     UIManager.put("ScrollBar.background", new ColorUIResource(new Color(250, 250, 250)));
/* 47 */     UIManager.put("ScrollBar.trackForeground", new ColorUIResource(new Color(250, 250, 250)));
/* 48 */     UIManager.put("scrollbar", new ColorUIResource(new Color(250, 250, 250)));
/* 49 */     UIManager.put("ScrollBarUI", BEScrollBarUI.class.getName());
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch4_scroll.__UI__
 * JD-Core Version:    0.6.2
 */