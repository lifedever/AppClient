/*     */ package org.jb2011.lnf.beautyeye;
/*     */ 
/*     */ import javax.swing.UIDefaults;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.metal.MetalLookAndFeel;
/*     */ import org.jb2011.lnf.beautyeye.ch20_filechooser.__UI__;
/*     */ 
/*     */ public class BeautyEyeLookAndFeelCross extends MetalLookAndFeel
/*     */ {
/*     */   static
/*     */   {
/*  33 */     BeautyEyeLookAndFeelWin.initLookAndFeelDecorated();
/*     */   }
/*     */ 
/*     */   public BeautyEyeLookAndFeelCross()
/*     */   {
/*  46 */     UIManager.put("swing.boldMetal", Boolean.FALSE);
/*     */ 
/*  48 */     UIManager.put("TabbedPane.contentOpaque", Boolean.FALSE);
/*     */ 
/*  50 */     UIManager.put("TabbedPane.tabsOpaque", Boolean.FALSE);
/*  51 */     BeautyEyeLNFHelper.implLNF();
/*     */ 
/*  54 */     __UI__.uiImpl_cross();
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  66 */     return "BeautyEyeCross";
/*     */   }
/*     */ 
/*     */   public String getID()
/*     */   {
/*  75 */     return "BeautyEyeCross";
/*     */   }
/*     */ 
/*     */   public String getDescription()
/*     */   {
/*  84 */     return "BeautyEye cross-platform L&F developed by Jack Jiang(jb2011@163.com).";
/*     */   }
/*     */ 
/*     */   public boolean getSupportsWindowDecorations()
/*     */   {
/*  96 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isNativeLookAndFeel()
/*     */   {
/* 105 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isSupportedLookAndFeel()
/*     */   {
/* 114 */     return true;
/*     */   }
/*     */ 
/*     */   protected void initComponentDefaults(UIDefaults table)
/*     */   {
/* 122 */     super.initComponentDefaults(table);
/* 123 */     initOtherResourceBundle(table);
/*     */   }
/*     */ 
/*     */   protected void initOtherResourceBundle(UIDefaults table)
/*     */   {
/* 131 */     table.addResourceBundle("org.jb2011.lnf.beautyeye.resources.beautyeye");
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.BeautyEyeLookAndFeelCross
 * JD-Core Version:    0.6.2
 */