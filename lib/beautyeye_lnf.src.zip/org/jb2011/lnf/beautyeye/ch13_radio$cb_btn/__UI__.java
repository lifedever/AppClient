/*     */ package org.jb2011.lnf.beautyeye.ch13_radio$cb_btn;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.io.Serializable;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ColorUIResource;
/*     */ import javax.swing.plaf.InsetsUIResource;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*     */ 
/*     */ public class __UI__
/*     */ {
/*     */   public static void uiImpl()
/*     */   {
/*  43 */     UIManager.put("CheckBox.margin", new InsetsUIResource(4, 3, 4, 3));
/*  44 */     UIManager.put("RadioButton.margin", new InsetsUIResource(4, 3, 4, 3));
/*     */ 
/*  46 */     UIManager.put("RadioButton.background", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/*  47 */     UIManager.put("CheckBox.background", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/*     */ 
/*  49 */     UIManager.put("CheckBox.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/*  50 */     UIManager.put("RadioButton.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/*     */ 
/*  52 */     UIManager.put("RadioButton.icon", new RadioButtonIcon(null));
/*  53 */     UIManager.put("CheckBox.icon", new CheckBoxIcon(null));
/*     */ 
/*  56 */     UIManager.put("RadioButton.margin", new InsetsUIResource(1, 1, 1, 1));
/*  57 */     UIManager.put("CheckBox.margin", new InsetsUIResource(1, 1, 1, 1));
/*     */   }
/*     */ 
/*     */   private static class CheckBoxIcon
/*     */     implements Icon, Serializable
/*     */   {
/*     */     public void paintIcon(Component c, Graphics g, int x, int y)
/*     */     {
/*  73 */       JCheckBox cb = (JCheckBox)c;
/*  74 */       ButtonModel model = cb.getModel();
/*     */ 
/*  77 */       if (model.isSelected())
/*     */       {
/*  80 */         if (!model.isEnabled()) {
/*  81 */           g.drawImage(__IconFactory__.getInstance().getCheckBoxButtonIcon_disable().getImage(), x, y, null);
/*     */         }
/*  85 */         else if (model.isPressed())
/*  86 */           g.drawImage(__IconFactory__.getInstance().getCheckBoxButtonIcon_pressed().getImage(), x, y, null);
/*     */         else {
/*  88 */           g.drawImage(__IconFactory__.getInstance().getCheckBoxButtonIcon_normal().getImage(), x, y, null);
/*     */         }
/*     */ 
/*     */       }
/*  95 */       else if (!model.isEnabled()) {
/*  96 */         g.drawImage(__IconFactory__.getInstance().getCheckBoxButtonIcon_unchecked_disable().getImage(), x, y, null);
/*     */       }
/* 100 */       else if (model.isPressed())
/* 101 */         g.drawImage(__IconFactory__.getInstance().getCheckBoxButtonIcon_unchecked_pressed().getImage(), x, y, null);
/*     */       else
/* 103 */         g.drawImage(__IconFactory__.getInstance().getCheckBoxButtonIcon_unchecked_normal().getImage(), x, y, null);
/*     */     }
/*     */ 
/*     */     public int getIconWidth()
/*     */     {
/* 113 */       return 24;
/*     */     }
/*     */ 
/*     */     public int getIconHeight()
/*     */     {
/* 121 */       return 24;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class RadioButtonIcon
/*     */     implements Icon, UIResource, Serializable
/*     */   {
/*     */     public void paintIcon(Component c, Graphics g, int x, int y)
/*     */     {
/* 137 */       AbstractButton b = (AbstractButton)c;
/* 138 */       ButtonModel model = b.getModel();
/*     */ 
/* 141 */       if (model.isSelected())
/*     */       {
/* 144 */         if (!model.isEnabled()) {
/* 145 */           g.drawImage(__IconFactory__.getInstance().getRadioButtonIcon_disable().getImage(), x, y, null);
/*     */         }
/* 149 */         else if (model.isPressed())
/* 150 */           g.drawImage(__IconFactory__.getInstance().getRadioButtonIcon_pressed().getImage(), x, y, null);
/*     */         else {
/* 152 */           g.drawImage(__IconFactory__.getInstance().getRadioButtonIcon_normal().getImage(), x, y, null);
/*     */         }
/*     */ 
/*     */       }
/* 159 */       else if (!model.isEnabled()) {
/* 160 */         g.drawImage(__IconFactory__.getInstance().getRadioButtonIcon_unchecked_disable().getImage(), x, y, null);
/*     */       }
/* 164 */       else if (model.isPressed())
/* 165 */         g.drawImage(__IconFactory__.getInstance().getRadioButtonIcon_unchecked_pressed().getImage(), x, y, null);
/*     */       else
/* 167 */         g.drawImage(__IconFactory__.getInstance().getRadioButtonIcon_unchecked_normal().getImage(), x, y, null);
/*     */     }
/*     */ 
/*     */     public int getIconWidth()
/*     */     {
/* 177 */       return 24;
/*     */     }
/*     */ 
/*     */     public int getIconHeight()
/*     */     {
/* 185 */       return 24;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch13_radio.cb_btn.__UI__
 * JD-Core Version:    0.6.2
 */