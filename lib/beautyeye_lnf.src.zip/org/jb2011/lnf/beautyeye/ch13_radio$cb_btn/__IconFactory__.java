/*     */ package org.jb2011.lnf.beautyeye.ch13_radio$cb_btn;
/*     */ 
/*     */ import javax.swing.ImageIcon;
/*     */ import org.jb2011.lnf.beautyeye.utils.RawCache;
/*     */ 
/*     */ public class __IconFactory__ extends RawCache<ImageIcon>
/*     */ {
/*     */   public static final String IMGS_ROOT = "imgs";
/*  31 */   private static cb_btn/__IconFactory__ instance = null;
/*     */ 
/*     */   public static cb_btn/__IconFactory__ getInstance()
/*     */   {
/*  40 */     if (instance == null)
/*  41 */       instance = new cb_btn/__IconFactory__();
/*  42 */     return instance;
/*     */   }
/*     */ 
/*     */   protected ImageIcon getResource(String relativePath, Class baseClass)
/*     */   {
/*  51 */     return new ImageIcon(baseClass.getResource(relativePath));
/*     */   }
/*     */ 
/*     */   public ImageIcon getImage(String relativePath)
/*     */   {
/*  62 */     return (ImageIcon)getRaw(relativePath, getClass());
/*     */   }
/*     */ 
/*     */   public ImageIcon getRadioButtonIcon_disable()
/*     */   {
/*  72 */     return getImage("imgs/rb_disable.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getRadioButtonIcon_normal()
/*     */   {
/*  82 */     return getImage("imgs/rb_normal.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getRadioButtonIcon_pressed()
/*     */   {
/*  92 */     return getImage("imgs/rb_pressed.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getRadioButtonIcon_unchecked_disable()
/*     */   {
/* 102 */     return getImage("imgs/rb_un_disable.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getRadioButtonIcon_unchecked_normal()
/*     */   {
/* 112 */     return getImage("imgs/rb_un_normal.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getRadioButtonIcon_unchecked_pressed()
/*     */   {
/* 122 */     return getImage("imgs/rb_un_pressed.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getCheckBoxButtonIcon_disable()
/*     */   {
/* 132 */     return getImage("imgs/cb_disable.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getCheckBoxButtonIcon_normal()
/*     */   {
/* 142 */     return getImage("imgs/cb_normal.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getCheckBoxButtonIcon_pressed()
/*     */   {
/* 152 */     return getImage("imgs/cb_pressed.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getCheckBoxButtonIcon_unchecked_disable()
/*     */   {
/* 162 */     return getImage("imgs/cb_un_disable.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getCheckBoxButtonIcon_unchecked_normal()
/*     */   {
/* 172 */     return getImage("imgs/cb_un_normal.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getCheckBoxButtonIcon_unchecked_pressed()
/*     */   {
/* 182 */     return getImage("imgs/cb_un_pressed.png");
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch13_radio.cb_btn.__IconFactory__
 * JD-Core Version:    0.6.2
 */