/*     */ package org.jb2011.lnf.beautyeye.ch1_titlepane;
/*     */ 
/*     */ import javax.swing.ImageIcon;
/*     */ import org.jb2011.lnf.beautyeye.utils.RawCache;
/*     */ 
/*     */ public class __IconFactory__ extends RawCache<ImageIcon>
/*     */ {
/*     */   public static final String IMGS_ROOT = "imgs";
/*  31 */   private static __IconFactory__ instance = null;
/*     */ 
/*     */   public static __IconFactory__ getInstance()
/*     */   {
/*  40 */     if (instance == null)
/*  41 */       instance = new __IconFactory__();
/*  42 */     return instance;
/*     */   }
/*     */ 
/*     */   protected ImageIcon getResource(String relativePath, Class baseClass)
/*     */   {
/*  51 */     return new ImageIcon(baseClass.getResource(relativePath));
/*     */   }
/*     */ 
/*     */   public ImageIcon getImage(String relativePath)
/*     */   {
/*  62 */     return (ImageIcon)getRaw(relativePath, getClass());
/*     */   }
/*     */ 
/*     */   public ImageIcon getInternalFrameCloseIcon()
/*     */   {
/*  72 */     return getImage("imgs/frame_close_over.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getInternalFrameMinIcon()
/*     */   {
/*  82 */     return getImage("imgs/frame_windowize_over.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getInternalFrameMaxIcon()
/*     */   {
/*  92 */     return getImage("imgs/frame_maximize_over.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getInternalIconfiedIcon()
/*     */   {
/* 102 */     return getImage("imgs/frame_minimize_over.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getInternelFrameIcon()
/*     */   {
/* 112 */     return getImage("imgs/ifi1.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getFrameIcon_16_16()
/*     */   {
/* 122 */     return getImage("imgs/default_frame_icon.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getFrameTitleHeadBg_active()
/*     */   {
/* 132 */     return getImage("imgs/head_bg.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getFrameTitleHeadBg_inactive()
/*     */   {
/* 142 */     return getImage("imgs/head_inactive.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getInternalFrameSetupIcon()
/*     */   {
/* 152 */     return getImage("imgs/frame_setup_normal.png");
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch1_titlepane.__IconFactory__
 * JD-Core Version:    0.6.2
 */