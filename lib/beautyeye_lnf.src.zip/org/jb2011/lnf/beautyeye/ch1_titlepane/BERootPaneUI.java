/*      */ package org.jb2011.lnf.beautyeye.ch1_titlepane;
/*      */ 
/*      */ import java.awt.Component;
/*      */ import java.awt.Container;
/*      */ import java.awt.Cursor;
/*      */ import java.awt.Dialog;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Frame;
/*      */ import java.awt.HeadlessException;
/*      */ import java.awt.Insets;
/*      */ import java.awt.LayoutManager;
/*      */ import java.awt.LayoutManager2;
/*      */ import java.awt.MouseInfo;
/*      */ import java.awt.Point;
/*      */ import java.awt.PointerInfo;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.Window;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.event.WindowAdapter;
/*      */ import java.awt.event.WindowEvent;
/*      */ import java.awt.event.WindowListener;
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JLayeredPane;
/*      */ import javax.swing.JMenuBar;
/*      */ import javax.swing.JRootPane;
/*      */ import javax.swing.LookAndFeel;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.UIManager;
/*      */ import javax.swing.border.Border;
/*      */ import javax.swing.event.MouseInputListener;
/*      */ import javax.swing.plaf.ComponentUI;
/*      */ import javax.swing.plaf.UIResource;
/*      */ import javax.swing.plaf.basic.BasicRootPaneUI;
/*      */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*      */ import org.jb2011.lnf.beautyeye.utils.WindowTranslucencyHelper;
/*      */ 
/*      */ public class BERootPaneUI extends BasicRootPaneUI
/*      */ {
/*   66 */   private static final String[] borderKeys = { 
/*   68 */     0, "RootPane.frameBorder", 
/*   69 */     "RootPane.plainDialogBorder", 
/*   70 */     "RootPane.informationDialogBorder", 
/*   71 */     "RootPane.errorDialogBorder", 
/*   72 */     "RootPane.colorChooserDialogBorder", 
/*   73 */     "RootPane.fileChooserDialogBorder", 
/*   74 */     "RootPane.questionDialogBorder", 
/*   75 */     "RootPane.warningDialogBorder" };
/*      */   private static final int BORDER_DRAG_THICKNESS = 5;
/*      */   private Window window;
/*      */   private JComponent titlePane;
/*      */   private MouseInputListener mouseInputListener;
/*      */   private LayoutManager layoutManager;
/*      */   private LayoutManager savedOldLayout;
/*      */   private JRootPane root;
/*  133 */   private Cursor lastCursor = Cursor.getPredefinedCursor(0);
/*      */ 
/*  137 */   private WindowListener windowsListener = null;
/*      */ 
/*  858 */   private static final int[] cursorMapping = { 6, 
/*  859 */     6, 
/*  860 */     8, 
/*  861 */     7, 
/*  862 */     7, 
/*  863 */     6, 
/*  867 */     0, 0, 0, 7, 
/*  868 */     10, 
/*  872 */     0, 0, 0, 11, 
/*  873 */     4, 
/*  877 */     0, 0, 0, 5, 
/*  878 */     4, 
/*  879 */     4, 
/*  880 */     9, 
/*  881 */     5, 
/*  882 */     5 };
/*      */ 
/*      */   public static ComponentUI createUI(JComponent c)
/*      */   {
/*  147 */     return new BERootPaneUI();
/*      */   }
/*      */ 
/*      */   public void installUI(JComponent c)
/*      */   {
/*  166 */     super.installUI(c);
/*      */ 
/*  168 */     this.root = ((JRootPane)c);
/*  169 */     int style = this.root.getWindowDecorationStyle();
/*      */ 
/*  171 */     if (style != 0)
/*      */     {
/*  173 */       installClientDecorations(this.root);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void uninstallUI(JComponent c)
/*      */   {
/*  191 */     super.uninstallUI(c);
/*  192 */     uninstallClientDecorations(this.root);
/*      */ 
/*  194 */     this.layoutManager = null;
/*  195 */     this.mouseInputListener = null;
/*  196 */     this.root = null;
/*      */   }
/*      */ 
/*      */   void installBorder(JRootPane root)
/*      */   {
/*  207 */     int style = root.getWindowDecorationStyle();
/*      */ 
/*  209 */     if (style == 0)
/*      */     {
/*  211 */       LookAndFeel.uninstallBorder(root);
/*      */     }
/*      */     else
/*      */     {
/*  215 */       Border b = root.getBorder();
/*  216 */       if ((b == null) || ((b instanceof UIResource)))
/*      */       {
/*  218 */         root.setBorder(null);
/*  219 */         root.setBorder(UIManager.getBorder(borderKeys[style]));
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void uninstallBorder(JRootPane root)
/*      */   {
/*  231 */     LookAndFeel.uninstallBorder(root);
/*      */   }
/*      */ 
/*      */   private void installWindowListeners(JRootPane root, Component parent)
/*      */   {
/*  247 */     if ((parent instanceof Window))
/*      */     {
/*  249 */       this.window = ((Window)parent);
/*      */     }
/*      */     else
/*      */     {
/*  253 */       this.window = SwingUtilities.getWindowAncestor(parent);
/*      */     }
/*  255 */     if (this.window != null)
/*      */     {
/*  257 */       if (this.mouseInputListener == null)
/*      */       {
/*  259 */         this.mouseInputListener = createWindowMouseInputListener(root);
/*      */       }
/*      */ 
/*  262 */       this.window.addMouseListener(this.mouseInputListener);
/*  263 */       this.window.addMouseMotionListener(this.mouseInputListener);
/*      */ 
/*  266 */       if (BeautyEyeLNFHelper.translucencyAtFrameInactive)
/*      */       {
/*  268 */         if (this.windowsListener == null)
/*      */         {
/*  270 */           this.windowsListener = new WindowAdapter() {
/*      */             public void windowActivated(WindowEvent e) {
/*  272 */               if (BERootPaneUI.this.window != null)
/*      */               {
/*  274 */                 WindowTranslucencyHelper.setOpacity(BERootPaneUI.this.window, 1.0F);
/*      */               }
/*      */             }
/*  277 */             public void windowDeactivated(WindowEvent e) { if (BERootPaneUI.this.window != null)
/*      */               {
/*  279 */                 WindowTranslucencyHelper.setOpacity(BERootPaneUI.this.window, 0.94F);
/*      */               } }
/*      */           };
/*      */         }
/*  283 */         this.window.addWindowListener(this.windowsListener);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void uninstallWindowListeners(JRootPane root)
/*      */   {
/*  296 */     if (this.window != null)
/*      */     {
/*  298 */       this.window.removeMouseListener(this.mouseInputListener);
/*  299 */       this.window.removeMouseMotionListener(this.mouseInputListener);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void installLayout(JRootPane root)
/*      */   {
/*  311 */     if (this.layoutManager == null)
/*      */     {
/*  313 */       this.layoutManager = createLayoutManager();
/*      */     }
/*  315 */     this.savedOldLayout = root.getLayout();
/*  316 */     root.setLayout(this.layoutManager);
/*      */   }
/*      */ 
/*      */   private void uninstallLayout(JRootPane root)
/*      */   {
/*  326 */     if (this.savedOldLayout != null)
/*      */     {
/*  328 */       root.setLayout(this.savedOldLayout);
/*  329 */       this.savedOldLayout = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void installClientDecorations(JRootPane root)
/*      */   {
/*  342 */     installBorder(root);
/*      */ 
/*  344 */     JComponent titlePane = createTitlePane(root);
/*      */ 
/*  346 */     setTitlePane(root, titlePane);
/*  347 */     installWindowListeners(root, root.getParent());
/*  348 */     installLayout(root);
/*      */ 
/*  355 */     if ((!BeautyEyeLNFHelper.__isFrameBorderOpaque()) && 
/*  356 */       (this.window != null))
/*      */     {
/*  367 */       WindowTranslucencyHelper.setWindowOpaque(this.window, false);
/*  368 */       root.revalidate();
/*  369 */       root.repaint();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void uninstallClientDecorations(JRootPane root)
/*      */   {
/*  384 */     uninstallBorder(root);
/*  385 */     uninstallWindowListeners(root);
/*  386 */     setTitlePane(root, null);
/*  387 */     uninstallLayout(root);
/*      */ 
/*  393 */     int style = root.getWindowDecorationStyle();
/*  394 */     if (style == 0)
/*      */     {
/*  396 */       root.repaint();
/*  397 */       root.revalidate();
/*      */     }
/*      */ 
/*  400 */     if (this.window != null)
/*      */     {
/*  402 */       this.window.setCursor(Cursor.getPredefinedCursor(0));
/*      */     }
/*  404 */     this.window = null;
/*      */   }
/*      */ 
/*      */   private JComponent createTitlePane(JRootPane root)
/*      */   {
/*  416 */     return new BETitlePane(root, this);
/*      */   }
/*      */ 
/*      */   private MouseInputListener createWindowMouseInputListener(JRootPane root)
/*      */   {
/*  428 */     return new MouseInputHandler(null);
/*      */   }
/*      */ 
/*      */   private LayoutManager createLayoutManager()
/*      */   {
/*  439 */     return new XMetalRootLayout(null);
/*      */   }
/*      */ 
/*      */   private void setTitlePane(JRootPane root, JComponent titlePane)
/*      */   {
/*  454 */     JLayeredPane layeredPane = root.getLayeredPane();
/*  455 */     JComponent oldTitlePane = getTitlePane();
/*      */ 
/*  457 */     if (oldTitlePane != null)
/*      */     {
/*  459 */       oldTitlePane.setVisible(false);
/*  460 */       layeredPane.remove(oldTitlePane);
/*      */     }
/*  462 */     if (titlePane != null)
/*      */     {
/*  464 */       layeredPane.add(titlePane, JLayeredPane.FRAME_CONTENT_LAYER);
/*  465 */       titlePane.setVisible(true);
/*      */     }
/*  467 */     this.titlePane = titlePane;
/*      */   }
/*      */ 
/*      */   private JComponent getTitlePane()
/*      */   {
/*  479 */     return this.titlePane;
/*      */   }
/*      */ 
/*      */   private JRootPane getRootPane()
/*      */   {
/*  490 */     return this.root;
/*      */   }
/*      */ 
/*      */   public void propertyChange(PropertyChangeEvent e)
/*      */   {
/*  513 */     super.propertyChange(e);
/*      */ 
/*  515 */     String propertyName = e.getPropertyName();
/*  516 */     if (propertyName == null)
/*      */     {
/*  518 */       return;
/*      */     }
/*      */ 
/*  521 */     if (propertyName.equals("windowDecorationStyle"))
/*      */     {
/*  523 */       JRootPane root = (JRootPane)e.getSource();
/*  524 */       int style = root.getWindowDecorationStyle();
/*      */ 
/*  531 */       uninstallClientDecorations(root);
/*  532 */       if (style != 0)
/*      */       {
/*  534 */         installClientDecorations(root);
/*      */       }
/*      */     }
/*  537 */     else if (propertyName.equals("ancestor"))
/*      */     {
/*  539 */       uninstallWindowListeners(this.root);
/*  540 */       if (((JRootPane)e.getSource()).getWindowDecorationStyle() != 0)
/*      */       {
/*  543 */         installWindowListeners(this.root, this.root.getParent());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private class MouseInputHandler
/*      */     implements MouseInputListener
/*      */   {
/*      */     private boolean isMovingWindow;
/*      */     private int dragCursor;
/*      */     private int dragOffsetX;
/*      */     private int dragOffsetY;
/*      */     private int dragWidth;
/*      */     private int dragHeight;
/*  927 */     private final PrivilegedExceptionAction getLocationAction = new PrivilegedExceptionAction()
/*      */     {
/*      */       public Object run() throws HeadlessException
/*      */       {
/*  931 */         return MouseInfo.getPointerInfo().getLocation();
/*      */       }
/*  927 */     };
/*      */ 
/*      */     private MouseInputHandler()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void mousePressed(MouseEvent ev)
/*      */     {
/*  940 */       JRootPane rootPane = BERootPaneUI.this.getRootPane();
/*      */ 
/*  942 */       if (rootPane.getWindowDecorationStyle() == 0)
/*      */       {
/*  944 */         return;
/*      */       }
/*  946 */       Point dragWindowOffset = ev.getPoint();
/*  947 */       Window w = (Window)ev.getSource();
/*  948 */       if (w != null)
/*      */       {
/*  950 */         w.toFront();
/*      */       }
/*  952 */       Point convertedDragWindowOffset = SwingUtilities.convertPoint(w, 
/*  953 */         dragWindowOffset, BERootPaneUI.this.getTitlePane());
/*      */ 
/*  955 */       Frame f = null;
/*  956 */       Dialog d = null;
/*      */ 
/*  958 */       if ((w instanceof Frame))
/*      */       {
/*  960 */         f = (Frame)w;
/*      */       }
/*  962 */       else if ((w instanceof Dialog))
/*      */       {
/*  964 */         d = (Dialog)w;
/*      */       }
/*      */ 
/*  967 */       int frameState = f != null ? f.getExtendedState() : 0;
/*      */ 
/*  969 */       if ((BERootPaneUI.this.getTitlePane() != null) && 
/*  970 */         (BERootPaneUI.this.getTitlePane().contains(convertedDragWindowOffset)))
/*      */       {
/*  972 */         Insets insets = w.getInsets();
/*  973 */         if (((f != null) && ((frameState & 0x6) == 0)) || ((d != null) && 
/*  974 */           (dragWindowOffset.y >= 5) && 
/*  975 */           (dragWindowOffset.x >= 5)))
/*      */         {
/*  977 */           if (dragWindowOffset.x < w.getWidth() - 
/*  977 */             5)
/*      */           {
/*  979 */             this.isMovingWindow = true;
/*  980 */             this.dragOffsetX = dragWindowOffset.x;
/*  981 */             this.dragOffsetY = dragWindowOffset.y;
/*      */           }
/*      */         }
/*  984 */       } else if (((f != null) && (f.isResizable()) && 
/*  985 */         ((frameState & 0x6) == 0)) || (
/*  986 */         (d != null) && (d.isResizable())))
/*      */       {
/*  989 */         this.dragOffsetX = dragWindowOffset.x;
/*  990 */         this.dragOffsetY = dragWindowOffset.y;
/*  991 */         this.dragWidth = w.getWidth();
/*  992 */         this.dragHeight = w.getHeight();
/*  993 */         this.dragCursor = 
/*  995 */           getCursor_new(w, dragWindowOffset.x, dragWindowOffset.y);
/*      */       }
/*      */     }
/*      */ 
/*      */     public void mouseReleased(MouseEvent ev)
/*      */     {
/* 1004 */       if ((this.dragCursor != 0) && (BERootPaneUI.this.window != null) && (!BERootPaneUI.this.window.isValid()))
/*      */       {
/* 1008 */         BERootPaneUI.this.window.validate();
/* 1009 */         BERootPaneUI.this.getRootPane().repaint();
/*      */       }
/* 1011 */       this.isMovingWindow = false;
/* 1012 */       this.dragCursor = 0;
/*      */     }
/*      */ 
/*      */     public void mouseMoved(MouseEvent ev)
/*      */     {
/* 1020 */       JRootPane root = BERootPaneUI.this.getRootPane();
/*      */ 
/* 1022 */       if (root.getWindowDecorationStyle() == 0)
/*      */       {
/* 1024 */         return;
/*      */       }
/*      */ 
/* 1027 */       Window w = (Window)ev.getSource();
/*      */ 
/* 1029 */       Frame f = null;
/* 1030 */       Dialog d = null;
/*      */ 
/* 1032 */       if ((w instanceof Frame))
/*      */       {
/* 1034 */         f = (Frame)w;
/*      */       }
/* 1036 */       else if ((w instanceof Dialog))
/*      */       {
/* 1038 */         d = (Dialog)w;
/*      */       }
/*      */ 
/* 1042 */       int cursor = 
/* 1044 */         getCursor_new(w, ev.getX(), ev.getY());
/*      */ 
/* 1046 */       if ((cursor != 0) && (
/* 1047 */         ((f != null) && (f.isResizable()) && ((f.getExtendedState() & 0x6) == 0)) || ((d != null) && 
/* 1048 */         (d
/* 1048 */         .isResizable()))))
/*      */       {
/* 1050 */         w.setCursor(Cursor.getPredefinedCursor(cursor));
/*      */       }
/*      */       else
/*      */       {
/* 1054 */         w.setCursor(BERootPaneUI.this.lastCursor);
/*      */       }
/*      */     }
/*      */ 
/*      */     private void adjust(Rectangle bounds, Dimension min, int deltaX, int deltaY, int deltaWidth, int deltaHeight)
/*      */     {
/* 1071 */       bounds.x += deltaX;
/* 1072 */       bounds.y += deltaY;
/* 1073 */       bounds.width += deltaWidth;
/* 1074 */       bounds.height += deltaHeight;
/* 1075 */       if (min != null)
/*      */       {
/* 1077 */         if (bounds.width < min.width)
/*      */         {
/* 1079 */           int correction = min.width - bounds.width;
/* 1080 */           if (deltaX != 0)
/*      */           {
/* 1082 */             bounds.x -= correction;
/*      */           }
/* 1084 */           bounds.width = min.width;
/*      */         }
/* 1086 */         if (bounds.height < min.height)
/*      */         {
/* 1088 */           int correction = min.height - bounds.height;
/* 1089 */           if (deltaY != 0)
/*      */           {
/* 1091 */             bounds.y -= correction;
/*      */           }
/* 1093 */           bounds.height = min.height;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public void mouseDragged(MouseEvent ev)
/*      */     {
/* 1103 */       Window w = (Window)ev.getSource();
/* 1104 */       Point pt = ev.getPoint();
/*      */ 
/* 1106 */       if (this.isMovingWindow)
/*      */       {
/*      */         try
/*      */         {
/* 1111 */           Point windowPt = 
/* 1112 */             (Point)AccessController.doPrivileged(this.getLocationAction);
/* 1113 */           windowPt.x -= this.dragOffsetX;
/* 1114 */           windowPt.y -= this.dragOffsetY;
/* 1115 */           w.setLocation(windowPt);
/*      */         }
/*      */         catch (PrivilegedActionException localPrivilegedActionException)
/*      */         {
/*      */         }
/*      */       }
/* 1121 */       else if (this.dragCursor != 0)
/*      */       {
/* 1123 */         Rectangle r = w.getBounds();
/* 1124 */         Rectangle startBounds = new Rectangle(r);
/* 1125 */         Dimension min = w.getMinimumSize();
/*      */ 
/* 1127 */         switch (this.dragCursor)
/*      */         {
/*      */         case 11:
/* 1130 */           adjust(r, min, 0, 0, pt.x + (this.dragWidth - this.dragOffsetX) - 
/* 1131 */             r.width, 0);
/* 1132 */           break;
/*      */         case 9:
/* 1134 */           adjust(r, min, 0, 0, 0, pt.y + (
/* 1135 */             this.dragHeight - this.dragOffsetY) - r.height);
/* 1136 */           break;
/*      */         case 8:
/* 1138 */           adjust(r, min, 0, pt.y - this.dragOffsetY, 0, 
/* 1139 */             -(pt.y - this.dragOffsetY));
/* 1140 */           break;
/*      */         case 10:
/* 1142 */           adjust(r, min, pt.x - this.dragOffsetX, 0, 
/* 1143 */             -(pt.x - this.dragOffsetX), 0);
/* 1144 */           break;
/*      */         case 7:
/* 1146 */           adjust(r, min, 0, pt.y - this.dragOffsetY, pt.x + (
/* 1147 */             this.dragWidth - this.dragOffsetX) - r.width, 
/* 1148 */             -(pt.y - this.dragOffsetY));
/* 1149 */           break;
/*      */         case 5:
/* 1151 */           adjust(r, min, 0, 0, pt.x + (this.dragWidth - this.dragOffsetX) - 
/* 1152 */             r.width, pt.y + (this.dragHeight - this.dragOffsetY) - 
/* 1153 */             r.height);
/* 1154 */           break;
/*      */         case 6:
/* 1156 */           adjust(r, min, pt.x - this.dragOffsetX, pt.y - this.dragOffsetY, 
/* 1157 */             -(pt.x - this.dragOffsetX), -(pt.y - this.dragOffsetY));
/* 1158 */           break;
/*      */         case 4:
/* 1160 */           adjust(r, min, pt.x - this.dragOffsetX, 0, 
/* 1161 */             -(pt.x - this.dragOffsetX), pt.y + (
/* 1162 */             this.dragHeight - this.dragOffsetY) - r.height);
/* 1163 */           break;
/*      */         }
/*      */ 
/* 1167 */         if (!r.equals(startBounds))
/*      */         {
/* 1169 */           w.setBounds(r);
/*      */ 
/* 1172 */           if (Toolkit.getDefaultToolkit().isDynamicLayoutActive())
/*      */           {
/* 1174 */             w.validate();
/* 1175 */             BERootPaneUI.this.getRootPane().repaint();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public void mouseEntered(MouseEvent ev)
/*      */     {
/* 1186 */       Window w = (Window)ev.getSource();
/* 1187 */       BERootPaneUI.this.lastCursor = w.getCursor();
/* 1188 */       mouseMoved(ev);
/*      */     }
/*      */ 
/*      */     public void mouseExited(MouseEvent ev)
/*      */     {
/* 1196 */       Window w = (Window)ev.getSource();
/*      */ 
/* 1203 */       w.setCursor(Cursor.getPredefinedCursor(0));
/*      */     }
/*      */ 
/*      */     public void mouseClicked(MouseEvent ev)
/*      */     {
/* 1211 */       Window w = (Window)ev.getSource();
/* 1212 */       Frame f = null;
/*      */ 
/* 1214 */       if ((w instanceof Frame))
/*      */       {
/* 1216 */         f = (Frame)w;
/*      */       }
/*      */       else
/*      */       {
/* 1220 */         return;
/*      */       }
/*      */ 
/* 1223 */       Point convertedPoint = SwingUtilities.convertPoint(w, 
/* 1224 */         ev.getPoint(), BERootPaneUI.this.getTitlePane());
/*      */ 
/* 1226 */       int state = f.getExtendedState();
/* 1227 */       if ((BERootPaneUI.this.getTitlePane() != null) && 
/* 1228 */         (BERootPaneUI.this.getTitlePane().contains(convertedPoint)))
/*      */       {
/* 1230 */         if ((ev.getClickCount() % 2 == 0) && 
/* 1231 */           ((ev.getModifiers() & 0x10) != 0))
/*      */         {
/* 1233 */           if (f.isResizable())
/*      */           {
/* 1235 */             if ((state & 0x6) != 0)
/*      */             {
/* 1237 */               f.setExtendedState(state & 0xFFFFFFF9);
/*      */             }
/*      */             else
/*      */             {
/* 1241 */               f.setExtendedState(state | 0x6);
/*      */             }
/* 1243 */             return;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public int getCursor_new(Window w, int x, int y)
/*      */     {
/* 1340 */       Insets insets = w.getInsets();
/* 1341 */       return getCursor_new(x - insets.left, y - insets.top, 
/* 1342 */         w.getWidth() - insets.left - insets.right, 
/* 1343 */         w.getHeight() - insets.top - insets.bottom);
/*      */     }
/*      */ 
/*      */     public int getCursor_new(int x, int y, int w, int h)
/*      */     {
/* 1387 */       int B = 5;
/*      */ 
/* 1389 */       Insets iss = BERootPaneUI.this.getRootPane().getInsets();
/* 1390 */       int topI = iss.top; int bottomI = iss.bottom; int leftI = iss.left; int rightI = iss.right;
/*      */ 
/* 1393 */       Rectangle r1 = new Rectangle(leftI - B, topI - B, B, B);
/* 1394 */       Rectangle r2 = new Rectangle(leftI, topI - B, w - leftI - rightI, B);
/* 1395 */       Rectangle r3 = new Rectangle(w - rightI, topI - B, B, B);
/* 1396 */       Rectangle r4 = new Rectangle(w - rightI, topI, B, h - topI - bottomI);
/* 1397 */       Rectangle r5 = new Rectangle(w - rightI, h - bottomI, B, B);
/* 1398 */       Rectangle r6 = new Rectangle(leftI, h - bottomI, w - leftI - rightI, B);
/* 1399 */       Rectangle r7 = new Rectangle(leftI - B, h - bottomI, B, B);
/* 1400 */       Rectangle r8 = new Rectangle(leftI - B, topI, B, h - topI - bottomI);
/*      */ 
/* 1402 */       Point p = new Point(x, y);
/* 1403 */       int cc = 0;
/*      */ 
/* 1405 */       if (r1.contains(p))
/*      */       {
/* 1408 */         cc = 6;
/*      */       }
/* 1410 */       else if (r3.contains(p))
/*      */       {
/* 1413 */         cc = 7;
/*      */       }
/* 1415 */       else if (r5.contains(p))
/*      */       {
/* 1418 */         cc = 5;
/*      */       }
/* 1420 */       else if (r7.contains(p))
/*      */       {
/* 1423 */         cc = 4;
/*      */       }
/* 1425 */       else if (r2.contains(p))
/*      */       {
/* 1428 */         cc = 8;
/*      */       }
/* 1430 */       else if (r4.contains(p))
/*      */       {
/* 1433 */         cc = 11;
/*      */       }
/* 1435 */       else if (r6.contains(p))
/*      */       {
/* 1438 */         cc = 9;
/*      */       }
/* 1440 */       else if (r8.contains(p))
/*      */       {
/* 1443 */         cc = 10;
/*      */       }
/*      */ 
/* 1446 */       return cc;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class XMetalRootLayout
/*      */     implements LayoutManager2
/*      */   {
/*      */     public Dimension preferredLayoutSize(Container parent)
/*      */     {
/*  568 */       int cpWidth = 0;
/*  569 */       int cpHeight = 0;
/*  570 */       int mbWidth = 0;
/*  571 */       int mbHeight = 0;
/*  572 */       int tpWidth = 0;
/*  573 */       int tpHeight = 0;
/*  574 */       Insets i = parent.getInsets();
/*  575 */       JRootPane root = (JRootPane)parent;
/*      */       Dimension cpd;
/*      */       Dimension cpd;
/*  577 */       if (root.getContentPane() != null)
/*      */       {
/*  579 */         cpd = root.getContentPane().getPreferredSize();
/*      */       }
/*      */       else
/*      */       {
/*  583 */         cpd = root.getSize();
/*      */       }
/*  585 */       if (cpd != null)
/*      */       {
/*  587 */         cpWidth = cpd.width;
/*  588 */         cpHeight = cpd.height;
/*      */       }
/*      */ 
/*  591 */       if (root.getMenuBar() != null)
/*      */       {
/*  593 */         Dimension mbd = root.getMenuBar().getPreferredSize();
/*  594 */         if (mbd != null)
/*      */         {
/*  596 */           mbWidth = mbd.width;
/*  597 */           mbHeight = mbd.height;
/*      */         }
/*      */       }
/*      */ 
/*  601 */       if ((root.getWindowDecorationStyle() != 0) && 
/*  602 */         ((root.getUI() instanceof BERootPaneUI)))
/*      */       {
/*  604 */         JComponent titlePane = ((BERootPaneUI)root.getUI())
/*  605 */           .getTitlePane();
/*  606 */         if (titlePane != null)
/*      */         {
/*  608 */           Dimension tpd = titlePane.getPreferredSize();
/*  609 */           if (tpd != null)
/*      */           {
/*  611 */             tpWidth = tpd.width;
/*  612 */             tpHeight = tpd.height;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*  617 */       return new Dimension(Math.max(Math.max(cpWidth, mbWidth), tpWidth) + i.left + i.right, 
/*  618 */         cpHeight + mbHeight + tpWidth + i.top + i.bottom);
/*      */     }
/*      */ 
/*      */     public Dimension minimumLayoutSize(Container parent)
/*      */     {
/*  630 */       int cpWidth = 0;
/*  631 */       int cpHeight = 0;
/*  632 */       int mbWidth = 0;
/*  633 */       int mbHeight = 0;
/*  634 */       int tpWidth = 0;
/*  635 */       int tpHeight = 0;
/*  636 */       Insets i = parent.getInsets();
/*  637 */       JRootPane root = (JRootPane)parent;
/*      */       Dimension cpd;
/*      */       Dimension cpd;
/*  639 */       if (root.getContentPane() != null)
/*      */       {
/*  641 */         cpd = root.getContentPane().getMinimumSize();
/*      */       }
/*      */       else
/*      */       {
/*  645 */         cpd = root.getSize();
/*      */       }
/*  647 */       if (cpd != null)
/*      */       {
/*  649 */         cpWidth = cpd.width;
/*  650 */         cpHeight = cpd.height;
/*      */       }
/*      */ 
/*  653 */       if (root.getMenuBar() != null)
/*      */       {
/*  655 */         Dimension mbd = root.getMenuBar().getMinimumSize();
/*  656 */         if (mbd != null) {
/*  657 */           mbWidth = mbd.width;
/*  658 */           mbHeight = mbd.height;
/*      */         }
/*      */       }
/*  661 */       if ((root.getWindowDecorationStyle() != 0) && 
/*  662 */         ((root.getUI() instanceof BERootPaneUI))) {
/*  663 */         JComponent titlePane = ((BERootPaneUI)root.getUI())
/*  664 */           .getTitlePane();
/*  665 */         if (titlePane != null)
/*      */         {
/*  667 */           Dimension tpd = titlePane.getMinimumSize();
/*  668 */           if (tpd != null)
/*      */           {
/*  670 */             tpWidth = tpd.width;
/*  671 */             tpHeight = tpd.height;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*  676 */       return new Dimension(Math.max(Math.max(cpWidth, mbWidth), tpWidth) + i.left + i.right, 
/*  677 */         cpHeight + mbHeight + tpWidth + i.top + i.bottom);
/*      */     }
/*      */ 
/*      */     public Dimension maximumLayoutSize(Container target)
/*      */     {
/*  689 */       int cpWidth = 2147483647;
/*  690 */       int cpHeight = 2147483647;
/*  691 */       int mbWidth = 2147483647;
/*  692 */       int mbHeight = 2147483647;
/*  693 */       int tpWidth = 2147483647;
/*  694 */       int tpHeight = 2147483647;
/*  695 */       Insets i = target.getInsets();
/*  696 */       JRootPane root = (JRootPane)target;
/*      */ 
/*  698 */       if (root.getContentPane() != null)
/*      */       {
/*  700 */         Dimension cpd = root.getContentPane().getMaximumSize();
/*  701 */         if (cpd != null)
/*      */         {
/*  703 */           cpWidth = cpd.width;
/*  704 */           cpHeight = cpd.height;
/*      */         }
/*      */       }
/*      */ 
/*  708 */       if (root.getMenuBar() != null)
/*      */       {
/*  710 */         Dimension mbd = root.getMenuBar().getMaximumSize();
/*  711 */         if (mbd != null)
/*      */         {
/*  713 */           mbWidth = mbd.width;
/*  714 */           mbHeight = mbd.height;
/*      */         }
/*      */       }
/*      */ 
/*  718 */       if ((root.getWindowDecorationStyle() != 0) && 
/*  719 */         ((root.getUI() instanceof BERootPaneUI)))
/*      */       {
/*  721 */         JComponent titlePane = ((BERootPaneUI)root.getUI())
/*  722 */           .getTitlePane();
/*  723 */         if (titlePane != null)
/*      */         {
/*  725 */           Dimension tpd = titlePane.getMaximumSize();
/*  726 */           if (tpd != null)
/*      */           {
/*  728 */             tpWidth = tpd.width;
/*  729 */             tpHeight = tpd.height;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*  734 */       int maxHeight = Math.max(Math.max(cpHeight, mbHeight), tpHeight);
/*      */ 
/*  737 */       if (maxHeight != 2147483647)
/*      */       {
/*  739 */         maxHeight = cpHeight + mbHeight + tpHeight + i.top + i.bottom;
/*      */       }
/*      */ 
/*  742 */       int maxWidth = Math.max(Math.max(cpWidth, mbWidth), tpWidth);
/*      */ 
/*  744 */       if (maxWidth != 2147483647)
/*      */       {
/*  746 */         maxWidth += i.left + i.right;
/*      */       }
/*      */ 
/*  749 */       return new Dimension(maxWidth, maxHeight);
/*      */     }
/*      */ 
/*      */     public void layoutContainer(Container parent)
/*      */     {
/*  761 */       JRootPane root = (JRootPane)parent;
/*  762 */       Rectangle b = root.getBounds();
/*  763 */       Insets i = root.getInsets();
/*  764 */       int nextY = 0;
/*  765 */       int w = b.width - i.right - i.left;
/*  766 */       int h = b.height - i.top - i.bottom;
/*      */ 
/*  768 */       if (root.getLayeredPane() != null)
/*      */       {
/*  770 */         root.getLayeredPane().setBounds(i.left, i.top, w, h);
/*      */       }
/*  772 */       if (root.getGlassPane() != null)
/*      */       {
/*  774 */         root.getGlassPane().setBounds(i.left, i.top, w, h);
/*      */       }
/*      */ 
/*  778 */       if ((root.getWindowDecorationStyle() != 0) && 
/*  779 */         ((root.getUI() instanceof BERootPaneUI)))
/*      */       {
/*  781 */         JComponent titlePane = ((BERootPaneUI)root.getUI())
/*  782 */           .getTitlePane();
/*  783 */         if (titlePane != null)
/*      */         {
/*  785 */           Dimension tpd = titlePane.getPreferredSize();
/*  786 */           if (tpd != null)
/*      */           {
/*  788 */             int tpHeight = tpd.height;
/*  789 */             titlePane.setBounds(0, 0, w, tpHeight);
/*  790 */             nextY += tpHeight;
/*      */           }
/*      */         }
/*      */       }
/*  794 */       if (root.getMenuBar() != null)
/*      */       {
/*  803 */         if (root.getMenuBar().isVisible())
/*      */         {
/*  806 */           Dimension mbd = root.getMenuBar().getPreferredSize();
/*  807 */           root.getMenuBar().setBounds(0, nextY, w, mbd.height);
/*  808 */           nextY += mbd.height;
/*      */         }
/*      */       }
/*  810 */       if (root.getContentPane() != null)
/*      */       {
/*  812 */         if (root.getContentPane().isVisible())
/*      */         {
/*  815 */           Dimension cpd = root.getContentPane().getPreferredSize();
/*  816 */           root.getContentPane().setBounds(0, nextY, w, 
/*  817 */             h < nextY ? 0 : h - nextY);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public void addLayoutComponent(String name, Component comp)
/*      */     {
/*      */     }
/*      */ 
/*      */     public void removeLayoutComponent(Component comp)
/*      */     {
/*      */     }
/*      */ 
/*      */     public void addLayoutComponent(Component comp, Object constraints)
/*      */     {
/*      */     }
/*      */ 
/*      */     public float getLayoutAlignmentX(Container target)
/*      */     {
/*  839 */       return 0.0F;
/*      */     }
/*      */ 
/*      */     public float getLayoutAlignmentY(Container target)
/*      */     {
/*  844 */       return 0.0F;
/*      */     }
/*      */ 
/*      */     public void invalidateLayout(Container target)
/*      */     {
/*      */     }
/*      */   }
/*      */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch1_titlepane.BERootPaneUI
 * JD-Core Version:    0.6.2
 */