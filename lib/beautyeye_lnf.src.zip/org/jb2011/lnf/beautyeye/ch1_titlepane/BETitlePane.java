/*      */ package org.jb2011.lnf.beautyeye.ch1_titlepane;
/*      */ 
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.ComponentOrientation;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dialog;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.FontMetrics;
/*      */ import java.awt.Frame;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.GraphicsConfiguration;
/*      */ import java.awt.Image;
/*      */ import java.awt.Insets;
/*      */ import java.awt.LayoutManager;
/*      */ import java.awt.Paint;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.Window;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.WindowAdapter;
/*      */ import java.awt.event.WindowEvent;
/*      */ import java.awt.event.WindowListener;
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import javax.accessibility.AccessibleContext;
/*      */ import javax.swing.AbstractAction;
/*      */ import javax.swing.AbstractButton;
/*      */ import javax.swing.Action;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JFrame;
/*      */ import javax.swing.JMenu;
/*      */ import javax.swing.JMenuBar;
/*      */ import javax.swing.JMenuItem;
/*      */ import javax.swing.JOptionPane;
/*      */ import javax.swing.JRootPane;
/*      */ import javax.swing.JSeparator;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.UIManager;
/*      */ import javax.swing.border.Border;
/*      */ import javax.swing.border.EmptyBorder;
/*      */ import javax.swing.plaf.UIResource;
/*      */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*      */ import org.jb2011.lnf.beautyeye.utils.BEUtils;
/*      */ import org.jb2011.lnf.beautyeye.utils.JVM;
/*      */ import org.jb2011.lnf.beautyeye.utils.LogHelper;
/*      */ import org.jb2011.lnf.beautyeye.utils.MySwingUtilities2;
/*      */ import org.jb2011.lnf.beautyeye.utils.ReflectHelper;
/*      */ 
/*      */ public class BETitlePane extends JComponent
/*      */ {
/*   83 */   private static final Border handyEmptyBorder = new EmptyBorder(0, 0, 0, 0);
/*      */   private static final int IMAGE_HEIGHT = 16;
/*      */   private static final int IMAGE_WIDTH = 16;
/*      */   private PropertyChangeListener propertyChangeListener;
/*      */   private JMenuBar menuBar;
/*      */   private Action closeAction;
/*      */   private Action iconifyAction;
/*      */   private Action restoreAction;
/*      */   private Action maximizeAction;
/*      */   private Action setupAction;
/*      */   private JButton toggleButton;
/*      */   private JButton iconifyButton;
/*      */   private JButton closeButton;
/*      */   private Icon maximizeIcon;
/*      */   private Icon minimizeIcon;
/*      */   private JButton setupButton;
/*      */   private WindowListener windowListener;
/*      */   private Window window;
/*      */   private JRootPane rootPane;
/*      */   private int buttonsWidth;
/*      */   private int state;
/*      */   private BERootPaneUI rootPaneUI;
/*  185 */   private Color inactiveBackground = UIManager.getColor("inactiveCaption");
/*      */ 
/*  188 */   private Color inactiveForeground = UIManager.getColor("inactiveCaptionText");
/*      */ 
/*  191 */   private Color inactiveShadow = UIManager.getColor("inactiveCaptionBorder");
/*      */ 
/*  194 */   private Color activeBackground = null;
/*      */ 
/*  197 */   private Color activeForeground = null;
/*      */ 
/*  200 */   private Color activeShadow = null;
/*      */ 
/*      */   public BETitlePane(JRootPane root, BERootPaneUI ui)
/*      */   {
/*  210 */     this.rootPane = root;
/*  211 */     this.rootPaneUI = ui;
/*      */ 
/*  213 */     this.state = -1;
/*      */ 
/*  215 */     installSubcomponents();
/*  216 */     determineColors();
/*  217 */     installDefaults();
/*      */ 
/*  219 */     setLayout(createLayout());
/*      */   }
/*      */ 
/*      */   private void uninstall()
/*      */   {
/*  227 */     uninstallListeners();
/*  228 */     this.window = null;
/*  229 */     removeAll();
/*      */   }
/*      */ 
/*      */   private void installListeners()
/*      */   {
/*  237 */     if (this.window != null)
/*      */     {
/*  239 */       this.windowListener = createWindowListener();
/*  240 */       this.window.addWindowListener(this.windowListener);
/*  241 */       this.propertyChangeListener = createWindowPropertyChangeListener();
/*  242 */       this.window.addPropertyChangeListener(this.propertyChangeListener);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void uninstallListeners()
/*      */   {
/*  251 */     if (this.window != null)
/*      */     {
/*  253 */       this.window.removeWindowListener(this.windowListener);
/*  254 */       this.window.removePropertyChangeListener(this.propertyChangeListener);
/*      */     }
/*      */   }
/*      */ 
/*      */   private WindowListener createWindowListener()
/*      */   {
/*  266 */     return new WindowHandler(null);
/*      */   }
/*      */ 
/*      */   private PropertyChangeListener createWindowPropertyChangeListener()
/*      */   {
/*  277 */     return new PropertyChangeHandler(null);
/*      */   }
/*      */ 
/*      */   public JRootPane getRootPane()
/*      */   {
/*  287 */     return this.rootPane;
/*      */   }
/*      */ 
/*      */   private int getWindowDecorationStyle()
/*      */   {
/*  297 */     return getRootPane().getWindowDecorationStyle();
/*      */   }
/*      */ 
/*      */   public void addNotify()
/*      */   {
/*      */     try
/*      */     {
/*  306 */       super.addNotify();
/*      */     }
/*      */     catch (Exception localException) {
/*      */     }
/*  310 */     uninstallListeners();
/*      */ 
/*  312 */     this.window = SwingUtilities.getWindowAncestor(this);
/*  313 */     if (this.window != null)
/*      */     {
/*  315 */       if ((this.window instanceof Frame))
/*      */       {
/*  317 */         setState(((Frame)this.window).getExtendedState());
/*      */ 
/*  320 */         if (BeautyEyeLNFHelper.setMaximizedBoundForFrame)
/*      */         {
/*  325 */           setFrameMaxBound((Frame)this.window);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  330 */         setState(0);
/*      */       }
/*  332 */       setActive(this.window.isActive());
/*  333 */       installListeners();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void setFrameMaxBound(Frame f)
/*      */   {
/*  348 */     GraphicsConfiguration gc = f.getGraphicsConfiguration();
/*  349 */     Insets screenInsets = Toolkit.getDefaultToolkit().getScreenInsets(gc);
/*  350 */     Rectangle screenBounds = gc.getBounds();
/*  351 */     int x = Math.max(0, screenInsets.left);
/*  352 */     int y = Math.max(0, screenInsets.top);
/*  353 */     int w = screenBounds.width - (screenInsets.left + screenInsets.right);
/*  354 */     int h = screenBounds.height - (screenInsets.top + screenInsets.bottom);
/*      */ 
/*  356 */     f.setMaximizedBounds(new Rectangle(x, y, w, h));
/*      */   }
/*      */ 
/*      */   public void removeNotify()
/*      */   {
/*  364 */     super.removeNotify();
/*      */ 
/*  366 */     uninstallListeners();
/*  367 */     this.window = null;
/*      */   }
/*      */ 
/*      */   private void installSubcomponents()
/*      */   {
/*  375 */     int decorationStyle = getWindowDecorationStyle();
/*      */ 
/*  377 */     if ((decorationStyle == 1) || (decorationStyle == 2))
/*      */     {
/*  379 */       createActions();
/*  380 */       this.menuBar = createMenuBar();
/*  381 */       add(this.menuBar);
/*  382 */       createButtons();
/*      */ 
/*  384 */       add(this.closeButton);
/*      */ 
/*  387 */       Object isSetupButtonVisibleObj = UIManager.get("RootPane.setupButtonVisible");
/*      */ 
/*  389 */       boolean isSetupButtonVisible = isSetupButtonVisibleObj == null ? true : ((Boolean)isSetupButtonVisibleObj).booleanValue();
/*  390 */       if (isSetupButtonVisible)
/*      */       {
/*  392 */         add(this.setupButton);
/*      */       }
/*  394 */       if (decorationStyle != 2)
/*      */       {
/*  396 */         add(this.iconifyButton);
/*  397 */         add(this.toggleButton);
/*  398 */         this.menuBar.setEnabled(false);
/*      */       }
/*      */ 
/*      */     }
/*  405 */     else if ((decorationStyle == 3) || 
/*  406 */       (decorationStyle == 4) || 
/*  407 */       (decorationStyle == 5) || 
/*  408 */       (decorationStyle == 6) || 
/*  409 */       (decorationStyle == 7) || 
/*  410 */       (decorationStyle == 8))
/*      */     {
/*  412 */       createActions();
/*  413 */       createButtons();
/*  414 */       add(this.closeButton);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void determineColors()
/*      */   {
/*  423 */     switch (getWindowDecorationStyle())
/*      */     {
/*      */     case 1:
/*  426 */       this.activeBackground = UIManager.getColor("activeCaption");
/*  427 */       this.activeForeground = UIManager.getColor("activeCaptionText");
/*  428 */       this.activeShadow = UIManager.getColor("activeCaptionBorder");
/*  429 */       break;
/*      */     case 4:
/*  431 */       this.activeBackground = 
/*  432 */         UIManager.getColor("OptionPane.errorDialog.titlePane.background");
/*  433 */       this.activeForeground = 
/*  434 */         UIManager.getColor("OptionPane.errorDialog.titlePane.foreground");
/*  435 */       this.activeShadow = 
/*  436 */         UIManager.getColor("OptionPane.errorDialog.titlePane.shadow");
/*  437 */       break;
/*      */     case 5:
/*      */     case 6:
/*      */     case 7:
/*  441 */       this.activeBackground = 
/*  442 */         UIManager.getColor("OptionPane.questionDialog.titlePane.background");
/*  443 */       this.activeForeground = 
/*  444 */         UIManager.getColor("OptionPane.questionDialog.titlePane.foreground");
/*  445 */       this.activeShadow = 
/*  446 */         UIManager.getColor("OptionPane.questionDialog.titlePane.shadow");
/*  447 */       break;
/*      */     case 8:
/*  449 */       this.activeBackground = 
/*  450 */         UIManager.getColor("OptionPane.warningDialog.titlePane.background");
/*  451 */       this.activeForeground = 
/*  452 */         UIManager.getColor("OptionPane.warningDialog.titlePane.foreground");
/*  453 */       this.activeShadow = 
/*  454 */         UIManager.getColor("OptionPane.warningDialog.titlePane.shadow");
/*  455 */       break;
/*      */     case 2:
/*      */     case 3:
/*      */     default:
/*  459 */       this.activeBackground = UIManager.getColor("activeCaption");
/*  460 */       this.activeForeground = UIManager.getColor("activeCaptionText");
/*  461 */       this.activeShadow = UIManager.getColor("activeCaptionBorder");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void installDefaults()
/*      */   {
/*  471 */     setFont(UIManager.getFont("InternalFrame.titleFont", getLocale()));
/*      */   }
/*      */ 
/*      */   private void uninstallDefaults()
/*      */   {
/*      */   }
/*      */ 
/*      */   protected JMenuBar createMenuBar()
/*      */   {
/*  489 */     this.menuBar = new SystemMenuBar(null);
/*  490 */     this.menuBar.setOpaque(false);
/*  491 */     this.menuBar.setFocusable(false);
/*  492 */     this.menuBar.setBorderPainted(true);
/*  493 */     this.menuBar.add(createMenu());
/*  494 */     return this.menuBar;
/*      */   }
/*      */ 
/*      */   private void close()
/*      */   {
/*  502 */     Window window = getWindow();
/*      */ 
/*  504 */     if (window != null)
/*      */     {
/*  506 */       window.dispatchEvent(new WindowEvent(window, 
/*  507 */         201));
/*      */     }
/*      */   }
/*      */ 
/*      */   private void iconify()
/*      */   {
/*  516 */     Frame frame = getFrame();
/*  517 */     if (frame != null)
/*      */     {
/*  519 */       frame.setExtendedState(this.state | 0x1);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void maximize()
/*      */   {
/*  528 */     Frame frame = getFrame();
/*  529 */     if (frame != null)
/*      */     {
/*  531 */       frame.setExtendedState(this.state | 0x6);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void restore()
/*      */   {
/*  540 */     Frame frame = getFrame();
/*      */ 
/*  542 */     if (frame == null)
/*      */     {
/*  544 */       return;
/*      */     }
/*      */ 
/*  547 */     if ((this.state & 0x1) != 0)
/*      */     {
/*  549 */       frame.setExtendedState(this.state & 0xFFFFFFFE);
/*      */     }
/*      */     else
/*      */     {
/*  553 */       frame.setExtendedState(this.state & 0xFFFFFFF9);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void createActions()
/*      */   {
/*  563 */     this.closeAction = new CloseAction();
/*  564 */     if (getWindowDecorationStyle() == 1)
/*      */     {
/*  566 */       this.iconifyAction = new IconifyAction();
/*  567 */       this.restoreAction = new RestoreAction();
/*  568 */       this.maximizeAction = new MaximizeAction();
/*      */ 
/*  570 */       this.setupAction = new AbstractAction(
/*  571 */         UIManager.getString("BETitlePane.setupButtonText", getLocale()))
/*      */       {
/*      */         public void actionPerformed(ActionEvent e)
/*      */         {
/*  575 */           JOptionPane.showMessageDialog(BETitlePane.this.rootPane, "This button just used for demo.In the future,you can customize it.\nNow, you can set UIManager.put(\"RootPane.setupButtonVisible\", false) to hide it(detault is true).\nBeautyEye L&F developed by Jack Jiang, you can mail with jb2011@163.com.");
/*      */         }
/*      */       };
/*      */     }
/*      */   }
/*      */ 
/*      */   private JMenu createMenu()
/*      */   {
/*  592 */     JMenu menu = new JMenu("");
/*      */ 
/*  594 */     menu.setOpaque(false);
/*  595 */     if ((getWindowDecorationStyle() == 1) || 
/*  596 */       (getWindowDecorationStyle() == 2))
/*      */     {
/*  599 */       addMenuItems(menu);
/*      */     }
/*  601 */     return menu;
/*      */   }
/*      */ 
/*      */   private void addMenuItems(JMenu menu)
/*      */   {
/*  611 */     Locale locale = getRootPane().getLocale();
/*  612 */     menu.setToolTipText(
/*  613 */       UIManager.getString("BETitlePane.titleMenuToolTipText", getLocale()));
/*      */ 
/*  617 */     if (getWindowDecorationStyle() == 1)
/*      */     {
/*  619 */       JMenuItem mi = menu.add(this.restoreAction);
/*  620 */       int mnemonic = BEUtils.getInt("MetalTitlePane.restoreMnemonic", -1);
/*  621 */       if (mnemonic != -1)
/*      */       {
/*  623 */         mi.setMnemonic(mnemonic);
/*      */       }
/*      */ 
/*  626 */       mi = menu.add(this.iconifyAction);
/*  627 */       mnemonic = BEUtils.getInt("MetalTitlePane.iconifyMnemonic", -1);
/*  628 */       if (mnemonic != -1)
/*      */       {
/*  630 */         mi.setMnemonic(mnemonic);
/*      */       }
/*      */ 
/*  633 */       if (Toolkit.getDefaultToolkit().isFrameStateSupported(
/*  634 */         6))
/*      */       {
/*  636 */         mi = menu.add(this.maximizeAction);
/*  637 */         mnemonic = BEUtils.getInt("MetalTitlePane.maximizeMnemonic", 
/*  638 */           -1);
/*  639 */         if (mnemonic != -1)
/*      */         {
/*  641 */           mi.setMnemonic(mnemonic);
/*      */         }
/*      */       }
/*      */ 
/*  645 */       menu.add(new JSeparator());
/*      */     }
/*      */ 
/*  648 */     JMenuItem mi = menu.add(this.closeAction);
/*  649 */     int mnemonic = BEUtils.getInt("MetalTitlePane.closeMnemonic", -1);
/*  650 */     if (mnemonic != -1)
/*      */     {
/*  652 */       mi.setMnemonic(mnemonic);
/*      */     }
/*      */   }
/*      */ 
/*      */   private JButton createTitleButton()
/*      */   {
/*  664 */     JButton button = new JButton();
/*      */ 
/*  666 */     button.setFocusPainted(false);
/*  667 */     button.setFocusable(false);
/*  668 */     button.setOpaque(true);
/*  669 */     return button;
/*      */   }
/*      */ 
/*      */   private void createButtons()
/*      */   {
/*  678 */     this.setupButton = createTitleButton();
/*  679 */     this.setupButton.setAction(this.setupAction);
/*      */ 
/*  682 */     this.setupButton.setBorder(handyEmptyBorder);
/*      */ 
/*  684 */     this.setupButton.setIcon(UIManager.getIcon("Frame.setupIcon"));
/*  685 */     setButtonIcon(this.setupButton, this.setupButton.getIcon());
/*  686 */     this.setupButton.setContentAreaFilled(false);
/*      */ 
/*  689 */     this.closeButton = createTitleButton();
/*  690 */     this.closeButton.setAction(this.closeAction);
/*  691 */     this.closeButton.setText(null);
/*  692 */     this.closeButton.putClientProperty("paintActive", Boolean.TRUE);
/*  693 */     this.closeButton.setBorder(handyEmptyBorder);
/*  694 */     this.closeButton.getAccessibleContext().setAccessibleName("Close");
/*  695 */     this.closeButton.setIcon(UIManager.getIcon("Frame.closeIcon"));
/*  696 */     setButtonIcon(this.closeButton, this.closeButton.getIcon());
/*  697 */     this.closeButton.setContentAreaFilled(false);
/*  698 */     this.closeButton.setToolTipText(
/*  699 */       UIManager.getString("BETitlePane.closeButtonToolTipext", getLocale()));
/*      */ 
/*  701 */     if (getWindowDecorationStyle() == 1)
/*      */     {
/*  703 */       this.maximizeIcon = UIManager.getIcon("Frame.maximizeIcon");
/*  704 */       this.minimizeIcon = UIManager.getIcon("Frame.minimizeIcon");
/*      */ 
/*  706 */       this.iconifyButton = createTitleButton();
/*  707 */       this.iconifyButton.setAction(this.iconifyAction);
/*  708 */       this.iconifyButton.setText(null);
/*  709 */       this.iconifyButton.putClientProperty("paintActive", Boolean.TRUE);
/*  710 */       this.iconifyButton.setBorder(handyEmptyBorder);
/*  711 */       this.iconifyButton.getAccessibleContext().setAccessibleName("Iconify");
/*  712 */       this.iconifyButton.setIcon(UIManager.getIcon("Frame.iconifyIcon"));
/*  713 */       setButtonIcon(this.iconifyButton, this.iconifyButton.getIcon());
/*  714 */       this.iconifyButton.setContentAreaFilled(false);
/*  715 */       this.iconifyButton.setToolTipText(
/*  716 */         UIManager.getString("BETitlePane.iconifyButtonToolTipText", getLocale()));
/*      */ 
/*  718 */       this.toggleButton = createTitleButton();
/*  719 */       this.toggleButton.setAction(this.restoreAction);
/*  720 */       this.toggleButton.putClientProperty("paintActive", Boolean.TRUE);
/*  721 */       this.toggleButton.setBorder(handyEmptyBorder);
/*  722 */       this.toggleButton.getAccessibleContext().setAccessibleName("Maximize");
/*  723 */       this.toggleButton.setIcon(this.maximizeIcon);
/*  724 */       setButtonIcon(this.toggleButton, this.toggleButton.getIcon());
/*  725 */       this.toggleButton.setContentAreaFilled(false);
/*  726 */       this.toggleButton.setToolTipText(
/*  727 */         UIManager.getString("BETitlePane.toggleButtonToolTipText", getLocale()));
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void setButtonIcon(AbstractButton btn, Icon ico)
/*      */   {
/*  741 */     btn.setIcon(ico);
/*  742 */     if ((ico != null) && ((ico instanceof ImageIcon)))
/*      */     {
/*  745 */       btn.setRolloverIcon(BEUtils.filterWithRescaleOp((ImageIcon)ico, 2.0F, 1.0F, 1.0F, 1.0F));
/*      */ 
/*  747 */       btn.setPressedIcon(BEUtils.filterWithRescaleOp((ImageIcon)ico, 2.0F, 1.0F, 1.0F, 0.5F));
/*      */     }
/*      */   }
/*      */ 
/*      */   private LayoutManager createLayout()
/*      */   {
/*  759 */     return new TitlePaneLayout(null);
/*      */   }
/*      */ 
/*      */   private void setActive(boolean isActive)
/*      */   {
/*  769 */     Boolean activeB = isActive ? Boolean.TRUE : Boolean.FALSE;
/*  770 */     this.closeButton.putClientProperty("paintActive", activeB);
/*  771 */     if (getWindowDecorationStyle() == 1)
/*      */     {
/*  773 */       this.iconifyButton.putClientProperty("paintActive", activeB);
/*  774 */       this.toggleButton.putClientProperty("paintActive", activeB);
/*      */     }
/*      */ 
/*  778 */     getRootPane().repaint();
/*      */   }
/*      */ 
/*      */   private void setState(int state)
/*      */   {
/*  788 */     setState(state, false);
/*      */   }
/*      */ 
/*      */   private void setState(int state, boolean updateRegardless)
/*      */   {
/*  800 */     Window w = getWindow();
/*      */ 
/*  802 */     if ((w != null) && (getWindowDecorationStyle() == 1))
/*      */     {
/*  804 */       if ((this.state == state) && (!updateRegardless))
/*      */       {
/*  806 */         return;
/*      */       }
/*  808 */       Frame frame = getFrame();
/*      */ 
/*  810 */       if (frame != null)
/*      */       {
/*  812 */         JRootPane rootPane = getRootPane();
/*      */ 
/*  814 */         if (((state & 0x6) != 0) && 
/*  815 */           ((rootPane.getBorder() == null) || 
/*  816 */           ((rootPane
/*  816 */           .getBorder() instanceof UIResource))) && 
/*  817 */           (frame.isShowing()))
/*      */         {
/*  819 */           rootPane.setBorder(null);
/*      */         }
/*  821 */         else if ((state & 0x6) == 0)
/*      */         {
/*  825 */           this.rootPaneUI.installBorder(rootPane);
/*      */         }
/*  827 */         if (frame.isResizable())
/*      */         {
/*  829 */           if ((state & 0x6) != 0)
/*      */           {
/*  831 */             updateToggleButton(this.restoreAction, this.minimizeIcon);
/*  832 */             this.maximizeAction.setEnabled(false);
/*  833 */             this.restoreAction.setEnabled(true);
/*      */           }
/*      */           else
/*      */           {
/*  837 */             updateToggleButton(this.maximizeAction, this.maximizeIcon);
/*  838 */             this.maximizeAction.setEnabled(true);
/*  839 */             this.restoreAction.setEnabled(false);
/*      */           }
/*  841 */           if ((this.toggleButton.getParent() == null) || 
/*  842 */             (this.iconifyButton.getParent() == null))
/*      */           {
/*  844 */             add(this.toggleButton);
/*  845 */             add(this.iconifyButton);
/*  846 */             revalidate();
/*  847 */             repaint();
/*      */           }
/*  849 */           this.toggleButton.setText(null);
/*      */         }
/*      */         else
/*      */         {
/*  853 */           this.maximizeAction.setEnabled(false);
/*  854 */           this.restoreAction.setEnabled(false);
/*  855 */           if (this.toggleButton.getParent() != null)
/*      */           {
/*  857 */             remove(this.toggleButton);
/*  858 */             revalidate();
/*  859 */             repaint();
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  866 */         this.maximizeAction.setEnabled(false);
/*  867 */         this.restoreAction.setEnabled(false);
/*  868 */         this.iconifyAction.setEnabled(false);
/*  869 */         remove(this.toggleButton);
/*  870 */         remove(this.iconifyButton);
/*  871 */         revalidate();
/*  872 */         repaint();
/*      */       }
/*  874 */       this.closeAction.setEnabled(true);
/*  875 */       this.state = state;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void updateToggleButton(Action action, Icon icon)
/*      */   {
/*  888 */     this.toggleButton.setAction(action);
/*  889 */     this.toggleButton.setIcon(icon);
/*  890 */     setButtonIcon(this.toggleButton, this.toggleButton.getIcon());
/*  891 */     this.toggleButton.setText(null);
/*      */   }
/*      */ 
/*      */   private Frame getFrame()
/*      */   {
/*  902 */     Window window = getWindow();
/*      */ 
/*  904 */     if ((window instanceof Frame))
/*      */     {
/*  906 */       return (Frame)window;
/*      */     }
/*  908 */     return null;
/*      */   }
/*      */ 
/*      */   private Window getWindow()
/*      */   {
/*  920 */     return this.window;
/*      */   }
/*      */ 
/*      */   private String getTitle()
/*      */   {
/*  930 */     Window w = getWindow();
/*      */ 
/*  932 */     if ((w instanceof Frame))
/*      */     {
/*  934 */       return ((Frame)w).getTitle();
/*      */     }
/*  936 */     if ((w instanceof Dialog))
/*      */     {
/*  938 */       return ((Dialog)w).getTitle();
/*      */     }
/*  940 */     return null;
/*      */   }
/*      */ 
/*      */   public void paintComponent(Graphics g)
/*      */   {
/*  952 */     if (getFrame() != null)
/*      */     {
/*  954 */       setState(getFrame().getExtendedState());
/*      */     }
/*  956 */     JRootPane rootPane = getRootPane();
/*  957 */     Window window = getWindow();
/*  958 */     boolean leftToRight = window == null ? rootPane
/*  959 */       .getComponentOrientation().isLeftToRight() : window
/*  960 */       .getComponentOrientation().isLeftToRight();
/*  961 */     boolean isSelected = window == null ? true : window.isActive();
/*  962 */     int width = getWidth();
/*  963 */     int height = getHeight();
/*      */     Color darkShadow;
/*      */     Color foreground;
/*      */     Color darkShadow;
/*  969 */     if (isSelected)
/*      */     {
/*  971 */       Color background = this.activeBackground;
/*  972 */       Color foreground = this.activeForeground;
/*  973 */       darkShadow = this.activeShadow;
/*      */     }
/*      */     else
/*      */     {
/*  977 */       Color background = this.inactiveBackground;
/*  978 */       foreground = this.inactiveForeground;
/*  979 */       darkShadow = this.inactiveShadow;
/*      */     }
/*      */ 
/*  983 */     paintTitlePane(g, 0, 0, width, height, isSelected);
/*      */ 
/*  986 */     int xOffset = leftToRight ? 5 : width - 5;
/*      */ 
/*  988 */     if ((getWindowDecorationStyle() == 1) || (getWindowDecorationStyle() == 2))
/*      */     {
/*  990 */       xOffset += (leftToRight ? 21 : -21);
/*      */     }
/*      */ 
/*  993 */     String theTitle = getTitle();
/*  994 */     if (theTitle != null)
/*      */     {
/*  996 */       FontMetrics fm = MySwingUtilities2.getFontMetrics(rootPane, g);
/*  997 */       int yOffset = (height - fm.getHeight()) / 2 + fm.getAscent();
/*      */ 
/*  999 */       Rectangle rect = new Rectangle(0, 0, 0, 0);
/* 1000 */       if ((this.iconifyButton != null) && (this.iconifyButton.getParent() != null))
/*      */       {
/* 1002 */         rect = this.iconifyButton.getBounds();
/*      */       }
/*      */ 
/* 1006 */       if (leftToRight)
/*      */       {
/* 1008 */         if (rect.x == 0)
/*      */         {
/* 1010 */           rect.x = (window.getWidth() - window.getInsets().right - 2);
/*      */         }
/* 1012 */         int titleW = rect.x - xOffset - 4;
/* 1013 */         theTitle = MySwingUtilities2.clipStringIfNecessary(rootPane, fm, 
/* 1014 */           theTitle, titleW);
/*      */       }
/*      */       else
/*      */       {
/* 1018 */         int titleW = xOffset - rect.x - rect.width - 4;
/* 1019 */         theTitle = MySwingUtilities2.clipStringIfNecessary(rootPane, fm, 
/* 1020 */           theTitle, titleW);
/* 1021 */         xOffset -= MySwingUtilities2.stringWidth(rootPane, fm, theTitle);
/*      */       }
/*      */ 
/* 1024 */       int titleLength = MySwingUtilities2.stringWidth(rootPane, fm, theTitle);
/* 1025 */       g.setColor(foreground);
/* 1026 */       MySwingUtilities2.drawString(rootPane, g, theTitle, xOffset, yOffset);
/* 1027 */       xOffset += (leftToRight ? titleLength + 5 : -5);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void paintTitlePane(Graphics g, int x, int y, int width, int height, boolean actived)
/*      */   {
/* 1044 */     Graphics2D g2 = (Graphics2D)g;
/*      */ 
/* 1047 */     Paint oldpaint = g2.getPaint();
/* 1048 */     g2.setPaint(BEUtils.createTexturePaint(
/* 1049 */       actived ? __IconFactory__.getInstance().getFrameTitleHeadBg_active().getImage() : 
/* 1050 */       __IconFactory__.getInstance().getFrameTitleHeadBg_inactive().getImage()));
/* 1051 */     g2.fillRect(x, y, width, height);
/* 1052 */     g2.setPaint(oldpaint);
/*      */   }
/*      */ 
/*      */   private class CloseAction extends AbstractAction
/*      */   {
/*      */     public CloseAction()
/*      */     {
/* 1067 */       super();
/*      */     }
/*      */ 
/*      */     public void actionPerformed(ActionEvent e)
/*      */     {
/* 1075 */       BETitlePane.this.close();
/*      */     }
/*      */   }
/*      */ 
/*      */   private class IconifyAction extends AbstractAction
/*      */   {
/*      */     public IconifyAction()
/*      */     {
/* 1091 */       super();
/*      */     }
/*      */ 
/*      */     public void actionPerformed(ActionEvent e)
/*      */     {
/* 1099 */       BETitlePane.this.iconify();
/*      */     }
/*      */   }
/*      */ 
/*      */   private class MaximizeAction extends AbstractAction
/*      */   {
/*      */     public MaximizeAction()
/*      */     {
/* 1139 */       super();
/*      */     }
/*      */ 
/*      */     public void actionPerformed(ActionEvent e)
/*      */     {
/* 1147 */       BETitlePane.this.maximize();
/*      */     }
/*      */   }
/*      */ 
/*      */   private class PropertyChangeHandler
/*      */     implements PropertyChangeListener
/*      */   {
/*      */     private PropertyChangeHandler()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void propertyChange(PropertyChangeEvent pce)
/*      */     {
/* 1418 */       String name = pce.getPropertyName();
/*      */ 
/* 1421 */       if (("resizable".equals(name)) || ("state".equals(name)))
/*      */       {
/* 1423 */         Frame frame = BETitlePane.this.getFrame();
/*      */ 
/* 1425 */         if (frame != null)
/*      */         {
/* 1427 */           BETitlePane.this.setState(frame.getExtendedState(), true);
/*      */         }
/* 1429 */         if ("resizable".equals(name))
/*      */         {
/* 1431 */           BETitlePane.this.getRootPane().repaint();
/*      */         }
/*      */       }
/* 1434 */       else if ("title".equals(name))
/*      */       {
/* 1436 */         BETitlePane.this.repaint();
/*      */       }
/* 1438 */       else if (("componentOrientation".equals(name)) || 
/* 1439 */         ("iconImage".equals(name)))
/*      */       {
/* 1441 */         BETitlePane.this.revalidate();
/* 1442 */         BETitlePane.this.repaint();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private class RestoreAction extends AbstractAction
/*      */   {
/*      */     public RestoreAction()
/*      */     {
/* 1115 */       super();
/*      */     }
/*      */ 
/*      */     public void actionPerformed(ActionEvent e)
/*      */     {
/* 1123 */       BETitlePane.this.restore();
/*      */     }
/*      */   }
/*      */ 
/*      */   private class SystemMenuBar extends JMenuBar
/*      */   {
/*      */     private SystemMenuBar()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void paint(Graphics g)
/*      */     {
/* 1168 */       Window frame = BETitlePane.this.getWindow();
/*      */ 
/* 1170 */       if (isOpaque())
/*      */       {
/* 1172 */         g.setColor(getBackground());
/* 1173 */         g.fillRect(0, 0, getWidth(), getHeight());
/*      */       }
/*      */ 
/* 1178 */       Image image = null;
/* 1179 */       if (frame != null)
/*      */       {
/* 1183 */         if ((frame instanceof Frame)) {
/* 1184 */           image = ((Frame)frame).getIconImage();
/*      */         }
/*      */         else
/*      */         {
/*      */           try
/*      */           {
/* 1196 */             if (JVM.current().isOrLater(16))
/*      */             {
/* 1198 */               List iis = (List)
/* 1199 */                 ReflectHelper.invokeMethod(JFrame.class, frame, "getIconImages", new Class[0], 
/* 1200 */                 new Object[0]);
/* 1201 */               if ((iis != null) && (iis.size() > 0))
/* 1202 */                 image = (Image)iis.get(0);
/*      */             }
/*      */           }
/*      */           catch (Exception e)
/*      */           {
/* 1207 */             LogHelper.debug("Exception at BETitlePane.SystemMenuBar.paint," + e.getMessage());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 1212 */       if (image != null)
/*      */       {
/* 1214 */         g.drawImage(image, 0, 0, 16, 16, null);
/*      */       }
/*      */       else
/*      */       {
/* 1218 */         Icon icon = UIManager.getIcon("Frame.icon");
/* 1219 */         if (icon != null)
/*      */         {
/* 1221 */           icon.paintIcon(this, g, 0, 0);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public Dimension getMinimumSize()
/*      */     {
/* 1231 */       return getPreferredSize();
/*      */     }
/*      */ 
/*      */     public Dimension getPreferredSize()
/*      */     {
/* 1239 */       Dimension size = super.getPreferredSize();
/*      */ 
/* 1241 */       return new Dimension(Math.max(16, size.width), Math.max(
/* 1242 */         size.height, 16));
/*      */     }
/*      */   }
/*      */ 
/*      */   private class TitlePaneLayout
/*      */     implements LayoutManager
/*      */   {
/*      */     private TitlePaneLayout()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void addLayoutComponent(String name, Component c)
/*      */     {
/*      */     }
/*      */ 
/*      */     public void removeLayoutComponent(Component c)
/*      */     {
/*      */     }
/*      */ 
/*      */     public Dimension preferredLayoutSize(Container c)
/*      */     {
/* 1271 */       int height = computeHeight();
/* 1272 */       return new Dimension(height, height);
/*      */     }
/*      */ 
/*      */     public Dimension minimumLayoutSize(Container c)
/*      */     {
/* 1280 */       return preferredLayoutSize(c);
/*      */     }
/*      */ 
/*      */     private int computeHeight()
/*      */     {
/* 1290 */       FontMetrics fm = BETitlePane.this.rootPane.getFontMetrics(BETitlePane.this.getFont());
/* 1291 */       int fontHeight = fm.getHeight();
/* 1292 */       fontHeight += 7;
/* 1293 */       int iconHeight = 0;
/* 1294 */       if (BETitlePane.this.getWindowDecorationStyle() == 1)
/*      */       {
/* 1297 */         iconHeight = 16;
/*      */       }
/*      */ 
/* 1300 */       int finalHeight = Math.max(fontHeight, iconHeight);
/* 1301 */       return finalHeight + 2;
/*      */     }
/*      */ 
/*      */     public void layoutContainer(Container c)
/*      */     {
/* 1309 */       boolean leftToRight = BETitlePane.this.window == null ? BETitlePane.this.getRootPane()
/* 1310 */         .getComponentOrientation().isLeftToRight() : BETitlePane.this.window
/* 1311 */         .getComponentOrientation().isLeftToRight();
/*      */ 
/* 1313 */       int w = BETitlePane.this.getWidth();
/*      */ 
/* 1315 */       int y = 3;
/*      */       int buttonWidth;
/*      */       int buttonHeight;
/*      */       int buttonWidth;
/* 1320 */       if ((BETitlePane.this.closeButton != null) && (BETitlePane.this.closeButton.getIcon() != null))
/*      */       {
/* 1322 */         int buttonHeight = BETitlePane.this.closeButton.getIcon().getIconHeight();
/* 1323 */         buttonWidth = BETitlePane.this.closeButton.getIcon().getIconWidth();
/*      */       }
/*      */       else
/*      */       {
/* 1327 */         buttonHeight = 16;
/* 1328 */         buttonWidth = 16;
/*      */       }
/*      */ 
/* 1334 */       int x = leftToRight ? w : 0;
/*      */ 
/* 1336 */       int spacing = 5;
/* 1337 */       x = leftToRight ? spacing : w - buttonWidth - spacing;
/* 1338 */       if (BETitlePane.this.menuBar != null)
/*      */       {
/* 1342 */         BETitlePane.this.menuBar.setBounds(x, 
/* 1343 */           y + 2, 
/* 1347 */           16, 16);
/*      */       }
/*      */ 
/* 1350 */       x = leftToRight ? w : 0;
/* 1351 */       spacing = 4;
/* 1352 */       x += (leftToRight ? -spacing - buttonWidth : spacing);
/* 1353 */       if (BETitlePane.this.closeButton != null)
/*      */       {
/* 1355 */         BETitlePane.this.closeButton.setBounds(x, y, buttonWidth, buttonHeight);
/*      */       }
/*      */ 
/* 1358 */       if (!leftToRight) {
/* 1359 */         x += buttonWidth;
/*      */       }
/* 1361 */       if (BETitlePane.this.getWindowDecorationStyle() == 1)
/*      */       {
/* 1363 */         if (Toolkit.getDefaultToolkit().isFrameStateSupported(
/* 1364 */           6))
/*      */         {
/* 1366 */           if (BETitlePane.this.toggleButton.getParent() != null)
/*      */           {
/* 1368 */             spacing = 2;
/* 1369 */             x += (leftToRight ? -spacing - buttonWidth : spacing);
/* 1370 */             BETitlePane.this.toggleButton.setBounds(x, y, buttonWidth, buttonHeight);
/* 1371 */             if (!leftToRight)
/*      */             {
/* 1373 */               x += buttonWidth;
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/* 1378 */         if ((BETitlePane.this.iconifyButton != null) && (BETitlePane.this.iconifyButton.getParent() != null))
/*      */         {
/* 1380 */           spacing = 2;
/* 1381 */           x += (leftToRight ? -spacing - buttonWidth : spacing);
/* 1382 */           BETitlePane.this.iconifyButton.setBounds(x, y, buttonWidth, buttonHeight);
/* 1383 */           if (!leftToRight)
/*      */           {
/* 1385 */             x += buttonWidth;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1390 */         if (BETitlePane.this.setupButton != null)
/*      */         {
/* 1392 */           spacing = 2;
/* 1393 */           int stringWidth = BEUtils.getStrPixWidth(BETitlePane.this.setupButton.getFont(), BETitlePane.this.setupButton.getText());
/* 1394 */           x += (leftToRight ? -spacing - buttonWidth - stringWidth : spacing);
/* 1395 */           BETitlePane.this.setupButton.setBounds(x, y, buttonWidth + stringWidth, buttonHeight);
/* 1396 */           if (!leftToRight)
/*      */           {
/* 1398 */             x += buttonWidth;
/*      */           }
/*      */         }
/*      */       }
/* 1402 */       BETitlePane.this.buttonsWidth = (leftToRight ? w - x : x);
/*      */     }
/*      */   }
/*      */ 
/*      */   private class WindowHandler extends WindowAdapter
/*      */   {
/*      */     private WindowHandler()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void windowActivated(WindowEvent ev)
/*      */     {
/* 1458 */       BETitlePane.this.setActive(true);
/*      */     }
/*      */ 
/*      */     public void windowDeactivated(WindowEvent ev)
/*      */     {
/* 1466 */       BETitlePane.this.setActive(false);
/*      */     }
/*      */   }
/*      */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch1_titlepane.BETitlePane
 * JD-Core Version:    0.6.2
 */