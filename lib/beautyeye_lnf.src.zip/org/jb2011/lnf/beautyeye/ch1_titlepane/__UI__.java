/*    */ package org.jb2011.lnf.beautyeye.ch1_titlepane;
/*    */ 
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.plaf.BorderUIResource;
/*    */ import javax.swing.plaf.ColorUIResource;
/*    */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*    */ import org.jb2011.lnf.beautyeye.utils.BEUtils;
/*    */ 
/*    */ public class __UI__
/*    */ {
/*    */   public static void uiImpl()
/*    */   {
/* 33 */     UIManager.put("Frame.icon", __IconFactory__.getInstance().getFrameIcon_16_16());
/* 34 */     UIManager.put("Frame.iconifyIcon", __IconFactory__.getInstance().getInternalIconfiedIcon());
/* 35 */     UIManager.put("Frame.minimizeIcon", __IconFactory__.getInstance().getInternalFrameMinIcon());
/* 36 */     UIManager.put("Frame.maximizeIcon", __IconFactory__.getInstance().getInternalFrameMaxIcon());
/* 37 */     UIManager.put("Frame.closeIcon", __IconFactory__.getInstance().getInternalFrameCloseIcon());
/*    */ 
/* 39 */     UIManager.put("Frame.setupIcon", __IconFactory__.getInstance().getInternalFrameSetupIcon());
/*    */ 
/* 42 */     UIManager.put("activeCaptionText", new ColorUIResource(BeautyEyeLNFHelper.activeCaptionTextColor));
/*    */ 
/* 45 */     UIManager.put("inactiveCaptionText", new ColorUIResource(BEUtils.getColor(BeautyEyeLNFHelper.activeCaptionTextColor, -49, -27, -7)));
/*    */ 
/* 48 */     UIManager.put("RootPaneUI", BERootPaneUI.class.getName());
/*    */ 
/* 52 */     UIManager.put("RootPane.defaultButtonWindowKeyBindings", new Object[] { 
/* 53 */       "ENTER", "press", 
/* 54 */       "released ENTER", "release", 
/* 55 */       "ctrl ENTER", "press", 
/* 56 */       "ctrl released ENTER", "release" });
/*    */ 
/* 60 */     Object dialogBorder = new BorderUIResource(BeautyEyeLNFHelper.__getFrameBorder());
/* 61 */     UIManager.put("RootPane.frameBorder", dialogBorder);
/* 62 */     UIManager.put("RootPane.plainDialogBorder", dialogBorder);
/* 63 */     UIManager.put("RootPane.informationDialogBorder", dialogBorder);
/* 64 */     UIManager.put("RootPane.errorDialogBorder", dialogBorder);
/* 65 */     UIManager.put("RootPane.colorChooserDialogBorder", dialogBorder);
/* 66 */     UIManager.put("RootPane.fileChooserDialogBorder", dialogBorder);
/* 67 */     UIManager.put("RootPane.questionDialogBorder", dialogBorder);
/* 68 */     UIManager.put("RootPane.warningDialogBorder", dialogBorder);
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch1_titlepane.__UI__
 * JD-Core Version:    0.6.2
 */