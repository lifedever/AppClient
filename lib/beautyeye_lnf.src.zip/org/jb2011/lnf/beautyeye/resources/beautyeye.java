/*   */ package org.jb2011.lnf.beautyeye.resources;
/*   */ 
/*   */ import java.util.ListResourceBundle;
/*   */ 
/*   */ public final class beautyeye extends ListResourceBundle
/*   */ {
/*   */   protected final Object[][] getContents()
/*   */   {
/* 9 */     return new Object[][] { 
/* 10 */       { "BETitlePane.setupButtonText", "Setup  " }, 
/* 11 */       { "BETitlePane.titleMenuToolTipText", "Window operation." }, 
/* 12 */       { "BETitlePane.closeButtonToolTipext", "Close" }, 
/* 13 */       { "BETitlePane.iconifyButtonToolTipText", "Minimize" }, 
/* 14 */       { "BETitlePane.toggleButtonToolTipText", "Maximize" }, 
/* 15 */       { "BETitlePane.iconifyButtonText", "Minimize(N)" }, 
/* 16 */       { "BETitlePane.restoreButtonText", "Restore(R)" }, 
/* 17 */       { "BETitlePane.maximizeButtonText", "Maximized(X)" } };
/*   */   }
/*   */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.resources.beautyeye
 * JD-Core Version:    0.6.2
 */