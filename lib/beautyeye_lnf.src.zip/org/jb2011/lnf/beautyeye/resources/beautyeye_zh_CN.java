/*   */ package org.jb2011.lnf.beautyeye.resources;
/*   */ 
/*   */ import java.util.ListResourceBundle;
/*   */ 
/*   */ public final class beautyeye_zh_CN extends ListResourceBundle
/*   */ {
/*   */   protected final Object[][] getContents()
/*   */   {
/* 9 */     return new Object[][] { 
/* 10 */       { "BETitlePane.setupButtonText", "设置  " }, 
/* 11 */       { "BETitlePane.titleMenuToolTipText", "窗口相关操作." }, 
/* 12 */       { "BETitlePane.closeButtonToolTipext", "关闭" }, 
/* 13 */       { "BETitlePane.iconifyButtonToolTipText", "最小化" }, 
/* 14 */       { "BETitlePane.toggleButtonToolTipText", "最大化" }, 
/* 15 */       { "BETitlePane.iconifyButtonText", "最小化(N)" }, 
/* 16 */       { "BETitlePane.restoreButtonText", "还原(R)" }, 
/* 17 */       { "BETitlePane.maximizeButtonText", "最大化(X)" } };
/*   */   }
/*   */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.resources.beautyeye_zh_CN
 * JD-Core Version:    0.6.2
 */