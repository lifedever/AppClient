/*     */ package org.jb2011.lnf.beautyeye.ch19_list;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import javax.swing.DefaultListCellRenderer;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class MyDefaultListCellRenderer extends DefaultListCellRenderer
/*     */ {
/*  30 */   protected boolean isSelected = false;
/*     */ 
/*  33 */   protected boolean isFocuesed = false;
/*     */ 
/*     */   public MyDefaultListCellRenderer()
/*     */   {
/*  42 */     setOpaque(false);
/*     */   }
/*     */ 
/*     */   public void paintComponent(Graphics g)
/*     */   {
/*  54 */     if (this.isSelected)
/*     */     {
/*  58 */       __Icon9Factory__.getInstance()
/*  60 */         .getBgIcon_ItemSelected2()
/*  61 */         .draw((Graphics2D)g, 0, 0, getWidth(), getHeight());
/*     */     }
/*     */ 
/*  80 */     super.paintComponent(g);
/*     */   }
/*     */ 
/*     */   public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
/*     */   {
/*  95 */     Component c = super.getListCellRendererComponent(list, 
/*  96 */       value, index, isSelected, cellHasFocus);
/*     */ 
/*  98 */     this.isSelected = isSelected;
/*  99 */     this.isFocuesed = cellHasFocus;
/* 100 */     return c;
/*     */   }
/*     */ 
/*     */   public static class UIResource extends MyDefaultListCellRenderer
/*     */     implements UIResource
/*     */   {
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch19_list.MyDefaultListCellRenderer
 * JD-Core Version:    0.6.2
 */