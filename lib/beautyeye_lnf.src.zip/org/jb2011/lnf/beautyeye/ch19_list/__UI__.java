/*    */ package org.jb2011.lnf.beautyeye.ch19_list;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.BorderFactory;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.border.AbstractBorder;
/*    */ import javax.swing.border.Border;
/*    */ import javax.swing.plaf.BorderUIResource;
/*    */ import javax.swing.plaf.ColorUIResource;
/*    */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*    */ 
/*    */ public class __UI__
/*    */ {
/*    */   public static void uiImpl()
/*    */   {
/* 39 */     UIManager.put("List.border", new BorderUIResource(BorderFactory.createEmptyBorder(0, 0, 0, 0)));
/*    */ 
/* 41 */     UIManager.put("List.focusCellHighlightBorder", new BorderUIResource(BorderFactory.createEmptyBorder(1, 8, 5, 3)));
/*    */ 
/* 43 */     UIManager.put("List.focusSelectedCellHighlightBorderColor", new ColorUIResource(new Color(220, 0, 0, 255)));
/*    */ 
/* 45 */     UIManager.put("List.focusSelectedCellHighlightBorderHighlightColor", 
/* 46 */       new ColorUIResource(new Color(255, 255, 255, 70)));
/*    */ 
/* 48 */     UIManager.put("List.focusSelectedCellHighlightBorder", 
/* 49 */       new BorderUIResource(new FocusSelectedCellHighlightBorder()));
/*    */ 
/* 51 */     UIManager.put("List.cellNoFocusBorder", new BorderUIResource(BorderFactory.createEmptyBorder(1, 8, 5, 3)));
/*    */ 
/* 53 */     UIManager.put("List.background", new ColorUIResource(Color.white));
/* 54 */     UIManager.put("List.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/* 55 */     UIManager.put("List.selectionForeground", Color.white);
/* 56 */     UIManager.put("List.selectionBackground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionBackgroundColor));
/*    */ 
/* 58 */     UIManager.put("List.cellRenderer", new MyDefaultListCellRenderer.UIResource());
/* 59 */     UIManager.put("ListUI", BEListUI.class.getName());
/*    */   }
/*    */ 
/*    */   static class FocusSelectedCellHighlightBorder extends AbstractBorder
/*    */   {
/*    */     public Insets getBorderInsets(Component c)
/*    */     {
/* 76 */       return UIManager.getBorder("List.focusCellHighlightBorder").getBorderInsets(c);
/*    */     }
/*    */ 
/*    */     public Insets getBorderInsets(Component c, Insets insets)
/*    */     {
/* 84 */       return getBorderInsets(c);
/*    */     }
/*    */ 
/*    */     public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/*    */     {
/* 93 */       g.setColor(UIManager.getColor("List.focusSelectedCellHighlightBorderColor"));
/* 94 */       g.fillRect(x, y + 1, 2, height - 5);
/*    */ 
/* 98 */       g.setColor(UIManager.getColor("List.focusSelectedCellHighlightBorderHighlightColor"));
/* 99 */       g.fillRect(x + 2, y + 1, 1, height - 5);
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch19_list.__UI__
 * JD-Core Version:    0.6.2
 */