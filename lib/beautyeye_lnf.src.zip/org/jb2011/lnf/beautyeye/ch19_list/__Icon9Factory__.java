/*    */ package org.jb2011.lnf.beautyeye.ch19_list;
/*    */ 
/*    */ import org.jb2011.lnf.beautyeye.utils.NinePatchHelper;
/*    */ import org.jb2011.lnf.beautyeye.utils.RawCache;
/*    */ import org.jb2011.ninepatch4j.NinePatch;
/*    */ 
/*    */ public class __Icon9Factory__ extends RawCache<NinePatch>
/*    */ {
/*    */   public static final String IMGS_ROOT = "imgs/np";
/* 30 */   private static __Icon9Factory__ instance = null;
/*    */ 
/*    */   public static __Icon9Factory__ getInstance()
/*    */   {
/* 39 */     if (instance == null)
/* 40 */       instance = new __Icon9Factory__();
/* 41 */     return instance;
/*    */   }
/*    */ 
/*    */   protected NinePatch getResource(String relativePath, Class baseClass)
/*    */   {
/* 50 */     return NinePatchHelper.createNinePatch(baseClass.getResource(relativePath), false);
/*    */   }
/*    */ 
/*    */   public NinePatch getRaw(String relativePath)
/*    */   {
/* 61 */     return (NinePatch)getRaw(relativePath, getClass());
/*    */   }
/*    */ 
/*    */   public NinePatch getBgIcon_ItemSelected2()
/*    */   {
/* 71 */     return getRaw("imgs/np/list_cell_selected_bg2.9.png");
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch19_list.__Icon9Factory__
 * JD-Core Version:    0.6.2
 */