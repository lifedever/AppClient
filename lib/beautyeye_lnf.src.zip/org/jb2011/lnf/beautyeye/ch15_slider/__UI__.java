/*    */ package org.jb2011.lnf.beautyeye.ch15_slider;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.plaf.ColorUIResource;
/*    */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*    */ 
/*    */ public class __UI__
/*    */ {
/*    */   public static void uiImpl()
/*    */   {
/* 33 */     UIManager.put("Slider.background", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/*    */ 
/* 35 */     UIManager.put("Slider.tickColor", new ColorUIResource(new Color(154, 154, 154)));
/* 36 */     UIManager.put("Slider.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/*    */ 
/* 40 */     UIManager.put("Slider.focus", new ColorUIResource(BeautyEyeLNFHelper.commonFocusedBorderColor));
/* 41 */     UIManager.put("SliderUI", BESliderUI.class.getName());
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch15_slider.__UI__
 * JD-Core Version:    0.6.2
 */