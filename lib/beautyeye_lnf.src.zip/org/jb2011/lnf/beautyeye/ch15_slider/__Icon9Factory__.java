/*     */ package org.jb2011.lnf.beautyeye.ch15_slider;
/*     */ 
/*     */ import org.jb2011.lnf.beautyeye.utils.NinePatchHelper;
/*     */ import org.jb2011.lnf.beautyeye.utils.RawCache;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class __Icon9Factory__ extends RawCache<NinePatch>
/*     */ {
/*     */   public static final String IMGS_ROOT = "imgs/np";
/*  30 */   private static __Icon9Factory__ instance = null;
/*     */ 
/*     */   public static __Icon9Factory__ getInstance()
/*     */   {
/*  39 */     if (instance == null)
/*  40 */       instance = new __Icon9Factory__();
/*  41 */     return instance;
/*     */   }
/*     */ 
/*     */   protected NinePatch getResource(String relativePath, Class baseClass)
/*     */   {
/*  50 */     return NinePatchHelper.createNinePatch(baseClass.getResource(relativePath), false);
/*     */   }
/*     */ 
/*     */   public NinePatch getRaw(String relativePath)
/*     */   {
/*  61 */     return (NinePatch)getRaw(relativePath, getClass());
/*     */   }
/*     */ 
/*     */   public NinePatch getSliderTrack()
/*     */   {
/*  72 */     return getRaw("imgs/np/slider_track2.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getSliderTrack_VERITICAL()
/*     */   {
/*  82 */     return getRaw("imgs/np/slider_track2_v.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getSliderTrack_disable()
/*     */   {
/*  92 */     return getRaw("imgs/np/slider_track2_dark.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getSliderTrack_VERITICAL_disable()
/*     */   {
/* 102 */     return getRaw("imgs/np/slider_track2_v_dark.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getSliderTrack_forground()
/*     */   {
/* 112 */     return getRaw("imgs/np/slider_track2_forgroud.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getSliderTrack_forground_disable()
/*     */   {
/* 122 */     return getRaw("imgs/np/slider_track2_forgroud_disable.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getSliderTrack_VERTICAL_forground()
/*     */   {
/* 132 */     return getRaw("imgs/np/slider_track2_forgroud_v.9.png");
/*     */   }
/*     */ 
/*     */   public NinePatch getSliderTrack_VERTICAL_forground_disable()
/*     */   {
/* 142 */     return getRaw("imgs/np/slider_track2_forgroud_v_disable.9.png");
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch15_slider.__Icon9Factory__
 * JD-Core Version:    0.6.2
 */