/*     */ package org.jb2011.lnf.beautyeye.ch15_slider;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicSliderUI;
/*     */ import org.jb2011.lnf.beautyeye.utils.BEUtils;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class BESliderUI extends BasicSliderUI
/*     */ {
/*  39 */   protected final int THUMB_HEIGHT_HORIZONAL = 7;
/*     */ 
/*  42 */   protected final int THUMB_WIDTH_VERTICAL = 7;
/*     */ 
/*     */   public BESliderUI(JSlider b)
/*     */   {
/*  50 */     super(b);
/*     */   }
/*     */ 
/*     */   public static ComponentUI createUI(JComponent b)
/*     */   {
/*  60 */     return new BESliderUI((JSlider)b);
/*     */   }
/*     */ 
/*     */   public void paintTrack(Graphics g)
/*     */   {
/*  68 */     Rectangle trackBounds = this.trackRect;
/*  69 */     if (this.slider.getOrientation() == 0)
/*     */     {
/*  71 */       int cy = trackBounds.height / 2 - 2;
/*  72 */       int cw = trackBounds.width;
/*     */ 
/*  74 */       g.translate(trackBounds.x, trackBounds.y + cy);
/*     */ 
/*  84 */       if (this.slider.isEnabled())
/*     */       {
/*  87 */         __Icon9Factory__.getInstance().getSliderTrack()
/*  88 */           .draw((Graphics2D)g, 0, 0, cw, 7);
/*     */ 
/*  90 */         __Icon9Factory__.getInstance().getSliderTrack_forground()
/*  91 */           .draw((Graphics2D)g, 0, 0, this.thumbRect.x, 7);
/*     */       }
/*     */       else
/*     */       {
/*  96 */         __Icon9Factory__.getInstance().getSliderTrack_disable()
/*  97 */           .draw((Graphics2D)g, 0, 0, cw, 7);
/*     */ 
/*  99 */         __Icon9Factory__.getInstance().getSliderTrack_forground_disable()
/* 100 */           .draw((Graphics2D)g, 0, 0, this.thumbRect.x, 7);
/*     */       }
/*     */ 
/* 103 */       g.translate(-trackBounds.x, -(trackBounds.y + cy));
/*     */     }
/*     */     else
/*     */     {
/* 107 */       int cx = trackBounds.width / 2 - 2;
/* 108 */       int ch = trackBounds.height;
/*     */ 
/* 110 */       g.translate(trackBounds.x + cx, trackBounds.y);
/*     */ 
/* 121 */       if (this.slider.isEnabled())
/*     */       {
/* 124 */         __Icon9Factory__.getInstance().getSliderTrack_VERITICAL()
/* 125 */           .draw((Graphics2D)g, 0, 0, 7, ch);
/*     */ 
/* 128 */         __Icon9Factory__.getInstance().getSliderTrack_VERTICAL_forground()
/* 129 */           .draw((Graphics2D)g, 0, this.thumbRect.y, 7, ch - this.thumbRect.y);
/*     */       }
/*     */       else
/*     */       {
/* 134 */         __Icon9Factory__.getInstance().getSliderTrack_VERITICAL_disable()
/* 135 */           .draw((Graphics2D)g, 0, 0, 7, ch);
/*     */ 
/* 137 */         __Icon9Factory__.getInstance().getSliderTrack_VERTICAL_forground_disable()
/* 138 */           .draw((Graphics2D)g, 0, this.thumbRect.y, 7, ch - this.thumbRect.y);
/*     */       }
/*     */ 
/* 141 */       g.translate(-(trackBounds.x + cx), -trackBounds.y);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void paintFocus(Graphics g)
/*     */   {
/* 150 */     g.setColor(getFocusColor());
/*     */ 
/* 154 */     BEUtils.drawDashedRect(g, this.focusRect.x, this.focusRect.y, 
/* 155 */       this.focusRect.width, this.focusRect.height);
/*     */   }
/*     */ 
/*     */   public void paintThumb(Graphics g)
/*     */   {
/* 164 */     Rectangle knobBounds = this.thumbRect;
/* 165 */     int w = knobBounds.width;
/* 166 */     int h = knobBounds.height;
/*     */ 
/* 168 */     g.translate(knobBounds.x, knobBounds.y);
/* 169 */     if (this.slider.isEnabled())
/*     */     {
/* 171 */       g.setColor(this.slider.getBackground());
/*     */     }
/*     */     else
/*     */     {
/* 175 */       g.setColor(this.slider.getBackground().darker());
/*     */     }
/*     */ 
/* 183 */     if (isPaintNoTrangleThumb())
/*     */     {
/* 185 */       if (this.slider.getOrientation() == 0)
/* 186 */         g.drawImage(
/* 187 */           this.slider.isEnabled() ? __IconFactory__.getInstance().getSliderTick1_notrangle().getImage() : 
/* 188 */           __IconFactory__.getInstance().getSliderTick1_notrangle_disable().getImage(), 
/* 189 */           0, 0, null);
/*     */       else
/* 191 */         g.drawImage(this.slider.isEnabled() ? __IconFactory__.getInstance().getSliderTick1_notrangle_vertical().getImage() : 
/* 192 */           __IconFactory__.getInstance().getSliderTick1_notrangle_VERTICAL_disable().getImage(), 
/* 193 */           0, 0, null);
/*     */     }
/* 195 */     else if (this.slider.getOrientation() == 0)
/*     */     {
/* 197 */       g.drawImage(this.slider.isEnabled() ? __IconFactory__.getInstance().getSliderTick1().getImage() : 
/* 198 */         __IconFactory__.getInstance().getSliderTick1_disable().getImage(), 
/* 199 */         0, 0, null);
/*     */     }
/*     */     else
/*     */     {
/* 203 */       g.drawImage(this.slider.isEnabled() ? __IconFactory__.getInstance().getSliderTick1_vertical().getImage() : 
/* 204 */         __IconFactory__.getInstance().getSliderTick1_VERTICAL_disable().getImage(), 
/* 205 */         0, 0, null);
/*     */     }
/*     */ 
/* 208 */     g.translate(-knobBounds.x, -knobBounds.y);
/*     */   }
/*     */ 
/*     */   protected boolean isPaintNoTrangleThumb()
/*     */   {
/* 220 */     Boolean paintThumbArrowShape = (Boolean)this.slider
/* 221 */       .getClientProperty("Slider.paintThumbArrowShape");
/*     */ 
/* 225 */     return ((!this.slider.getPaintTicks()) && (paintThumbArrowShape == null)) || 
/* 225 */       (paintThumbArrowShape == Boolean.FALSE);
/*     */   }
/*     */ 
/*     */   protected Dimension getThumbSize()
/*     */   {
/* 234 */     boolean isPaintNoTrangle = isPaintNoTrangleThumb();
/*     */ 
/* 236 */     Dimension size = new Dimension();
/* 237 */     if (this.slider.getOrientation() == 1)
/*     */     {
/* 239 */       size.width = 17;
/* 240 */       size.height = (isPaintNoTrangle ? 16 : 12);
/*     */     }
/*     */     else
/*     */     {
/* 244 */       size.width = (isPaintNoTrangle ? 16 : 12);
/* 245 */       size.height = 17;
/*     */     }
/* 247 */     return size;
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch15_slider.BESliderUI
 * JD-Core Version:    0.6.2
 */