/*     */ package org.jb2011.lnf.beautyeye.ch15_slider;
/*     */ 
/*     */ import javax.swing.ImageIcon;
/*     */ import org.jb2011.lnf.beautyeye.utils.RawCache;
/*     */ 
/*     */ public class __IconFactory__ extends RawCache<ImageIcon>
/*     */ {
/*     */   public static final String IMGS_ROOT = "imgs";
/*  31 */   private static __IconFactory__ instance = null;
/*     */ 
/*     */   public static __IconFactory__ getInstance()
/*     */   {
/*  40 */     if (instance == null)
/*  41 */       instance = new __IconFactory__();
/*  42 */     return instance;
/*     */   }
/*     */ 
/*     */   protected ImageIcon getResource(String relativePath, Class baseClass)
/*     */   {
/*  51 */     return new ImageIcon(baseClass.getResource(relativePath));
/*     */   }
/*     */ 
/*     */   public ImageIcon getImage(String relativePath)
/*     */   {
/*  62 */     return (ImageIcon)getRaw(relativePath, getClass());
/*     */   }
/*     */ 
/*     */   public ImageIcon getSliderTick1()
/*     */   {
/*  72 */     return getImage("imgs/slider_tick1.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getSliderTick1_notrangle()
/*     */   {
/*  82 */     return getImage("imgs/slider_tick1_notrangle.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getSliderTick1_disable()
/*     */   {
/*  92 */     return getImage("imgs/slider_tick1_dark.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getSliderTick1_notrangle_disable()
/*     */   {
/* 102 */     return getImage("imgs/slider_tick1_notrangle_dark.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getSliderTick1_vertical()
/*     */   {
/* 112 */     return getImage("imgs/slider_tick1_v.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getSliderTick1_notrangle_vertical()
/*     */   {
/* 122 */     return getImage("imgs/slider_tick1_notrangle_v.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getSliderTick1_VERTICAL_disable()
/*     */   {
/* 133 */     return getImage("imgs/slider_tick1_v_dark.png");
/*     */   }
/*     */ 
/*     */   public ImageIcon getSliderTick1_notrangle_VERTICAL_disable()
/*     */   {
/* 143 */     return getImage("imgs/slider_tick1_notrangle_v_dark.png");
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch15_slider.__IconFactory__
 * JD-Core Version:    0.6.2
 */