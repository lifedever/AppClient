/*    */ package org.jb2011.lnf.beautyeye.ch14_combox;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import javax.swing.BorderFactory;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.plaf.BorderUIResource;
/*    */ import javax.swing.plaf.ColorUIResource;
/*    */ import javax.swing.plaf.InsetsUIResource;
/*    */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
/*    */ 
/*    */ public class __UI__
/*    */ {
/*    */   public static void uiImpl()
/*    */   {
/* 36 */     UIManager.put("ComboBox.scrollPaneBorder", new BorderUIResource(BorderFactory.createEmptyBorder(2, 0, 4, 0)));
/*    */ 
/* 38 */     UIManager.put("ComboBox.background", new ColorUIResource(Color.white));
/* 39 */     UIManager.put("ComboBox.disabledBackground", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/*    */ 
/* 41 */     UIManager.put("ComboBox.buttonBackground", new ColorUIResource(BeautyEyeLNFHelper.commonBackgroundColor));
/* 42 */     UIManager.put("ComboBox.selectionForeground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionForegroundColor));
/* 43 */     UIManager.put("ComboBox.selectionBackground", new ColorUIResource(BeautyEyeLNFHelper.commonSelectionBackgroundColor));
/* 44 */     UIManager.put("ComboBox.foreground", new ColorUIResource(BeautyEyeLNFHelper.commonForegroundColor));
/*    */ 
/* 47 */     UIManager.put("ComboBox.padding", new InsetsUIResource(1, 0, 1, 0));
/*    */ 
/* 49 */     UIManager.put("ComboBox.squareButton", Boolean.valueOf(true));
/*    */ 
/* 51 */     BorderUIResource border = new BorderUIResource(BorderFactory.createEmptyBorder(0, 4, 0, 0));
/*    */ 
/* 54 */     UIManager.put("ComboBox.border", border);
/* 55 */     UIManager.put("ComboBox.editorBorder", border);
/*    */ 
/* 57 */     UIManager.put("ComboBoxUI", BEComboBoxUI.class.getName());
/*    */ 
/* 60 */     UIManager.put("ComboBox.popupOffsetX", Integer.valueOf(-3));
/*    */ 
/* 63 */     UIManager.put("ComboBox.popupOffsetY", Integer.valueOf(2));
/*    */   }
/*    */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch14_combox.__UI__
 * JD-Core Version:    0.6.2
 */