/*     */ package org.jb2011.lnf.beautyeye.ch14_combox;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.ComboBoxEditor;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.ListCellRenderer;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.basic.BasicComboBoxEditor.UIResource;
/*     */ import javax.swing.plaf.basic.BasicComboBoxUI;
/*     */ import javax.swing.plaf.basic.BasicComboPopup;
/*     */ import javax.swing.plaf.basic.ComboPopup;
/*     */ import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.__UseParentPaintSurported;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class BEComboBoxUI extends BasicComboBoxUI
/*     */   implements BeautyEyeLNFHelper.__UseParentPaintSurported
/*     */ {
/*     */   public static ComponentUI createUI(JComponent c)
/*     */   {
/*  63 */     return new BEComboBoxUI();
/*     */   }
/*     */ 
/*     */   public boolean isUseParentPaint()
/*     */   {
/*  82 */     return (this.comboBox != null) && (
/*  81 */       (!(this.comboBox.getBorder() instanceof UIResource)) || 
/*  82 */       (!(this.comboBox.getBackground() instanceof UIResource)));
/*     */   }
/*     */ 
/*     */   public void installUI(JComponent c)
/*     */   {
/*  92 */     super.installUI(c);
/*     */ 
/* 100 */     this.popup.getList().setFixedCellHeight(-1);
/*     */ 
/* 108 */     Container parent = this.popup.getList().getParent();
/* 109 */     if (parent != null)
/*     */     {
/* 111 */       parent = parent.getParent();
/* 112 */       if ((parent != null) && ((parent instanceof JScrollPane)))
/* 113 */         LookAndFeel.installBorder((JScrollPane)parent, "ComboBox.scrollPaneBorder");
/*     */     }
/*     */   }
/*     */ 
/*     */   public JComboBox getCombox()
/*     */   {
/* 124 */     return this.comboBox;
/*     */   }
/*     */ 
/*     */   protected JButton createArrowButton()
/*     */   {
/* 135 */     JButton button = new JButton()
/*     */     {
/*     */       public void setBorder(Border b)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void paint(Graphics g) {
/* 142 */         boolean isEnabled = isEnabled();
/* 143 */         boolean isPressed = getModel().isPressed();
/* 144 */         if (isEnabled)
/*     */         {
/* 146 */           if (isPressed)
/* 147 */             __Icon9Factory__.getInstance().getButtonArrow_pressed()
/* 148 */               .draw((Graphics2D)g, 0, 0, getWidth(), getHeight());
/*     */           else {
/* 150 */             __Icon9Factory__.getInstance().getButtonArrow_normal()
/* 151 */               .draw((Graphics2D)g, 0, 0, getWidth(), getHeight());
/*     */           }
/*     */         }
/*     */         else
/* 155 */           __Icon9Factory__.getInstance().getButtonArrow_disable()
/* 156 */             .draw((Graphics2D)g, 0, 0, getWidth(), getHeight());
/*     */       }
/*     */ 
/*     */       public boolean isFocusTraversable()
/*     */       {
/* 161 */         return false;
/*     */       }
/*     */ 
/*     */       public Dimension getPreferredSize()
/*     */       {
/* 169 */         return new Dimension(20, 20);
/*     */       }
/*     */ 
/*     */       public Dimension getMinimumSize()
/*     */       {
/* 177 */         return new Dimension(5, 5);
/*     */       }
/*     */ 
/*     */       public Dimension getMaximumSize()
/*     */       {
/* 185 */         return new Dimension(2147483647, 2147483647);
/*     */       }
/*     */     };
/* 188 */     button.setName("ComboBox.arrowButton");
/* 189 */     return button;
/*     */   }
/*     */ 
/*     */   public void paint(Graphics g, JComponent c)
/*     */   {
/* 199 */     this.hasFocus = this.comboBox.hasFocus();
/*     */ 
/* 202 */     Rectangle r = rectangleForCurrentValue();
/* 203 */     paintCurrentValueBackground(g, r, this.hasFocus);
/* 204 */     if (!this.comboBox.isEditable())
/* 205 */       paintCurrentValue(g, r, this.hasFocus);
/*     */   }
/*     */ 
/*     */   public void paintCurrentValueBackground(Graphics g, Rectangle bounds, boolean hasFocus)
/*     */   {
/* 220 */     if (!isUseParentPaint())
/*     */     {
/* 222 */       if (this.comboBox.isEnabled())
/* 223 */         org.jb2011.lnf.beautyeye.ch6_textcoms.__Icon9Factory__.getInstance().getTextFieldBgNormal()
/* 224 */           .draw((Graphics2D)g, 0, 0, this.comboBox.getWidth(), this.comboBox.getHeight());
/*     */       else {
/* 226 */         org.jb2011.lnf.beautyeye.ch6_textcoms.__Icon9Factory__.getInstance().getTextFieldBgDisabled()
/* 227 */           .draw((Graphics2D)g, 0, 0, this.comboBox.getWidth(), this.comboBox.getHeight());
/*     */       }
/*     */     }
/*     */     else
/* 231 */       super.paintCurrentValueBackground(g, bounds, hasFocus);
/*     */   }
/*     */ 
/*     */   protected ListCellRenderer createRenderer()
/*     */   {
/* 246 */     return new BEComboBoxRenderer.UIResource(this);
/*     */   }
/*     */ 
/*     */   public Insets getInsets()
/*     */   {
/* 255 */     return super.getInsets();
/*     */   }
/*     */ 
/*     */   protected ComboPopup createPopup()
/*     */   {
/* 302 */     return new BasicComboPopup(this.comboBox)
/*     */     {
/* 304 */       private int popupOffsetX = UIManager.getInt("ComboBox.popupOffsetX");
/*     */ 
/* 306 */       private int popupOffsetY = UIManager.getInt("ComboBox.popupOffsetY");
/*     */ 
/*     */       public void show()
/*     */       {
/* 313 */         setListSelection(this.comboBox.getSelectedIndex());
/* 314 */         Point location = getPopupLocation();
/* 315 */         show(this.comboBox, 
/* 317 */           location.x + this.popupOffsetX, 
/* 318 */           location.y + this.popupOffsetY);
/*     */       }
/*     */ 
/*     */       private void setListSelection(int selectedIndex)
/*     */       {
/* 331 */         if (selectedIndex == -1) {
/* 332 */           this.list.clearSelection();
/*     */         }
/*     */         else {
/* 335 */           this.list.setSelectedIndex(selectedIndex);
/* 336 */           this.list.ensureIndexIsVisible(selectedIndex);
/*     */         }
/*     */       }
/*     */ 
/*     */       private Point getPopupLocation()
/*     */       {
/* 345 */         Dimension popupSize = this.comboBox.getSize();
/* 346 */         Insets insets = getInsets();
/*     */ 
/* 350 */         popupSize.setSize(popupSize.width - (insets.right + insets.left), 
/* 351 */           getPopupHeightForRowCount(this.comboBox.getMaximumRowCount()));
/* 352 */         Rectangle popupBounds = computePopupBounds(0, this.comboBox.getBounds().height, 
/* 353 */           popupSize.width, popupSize.height);
/* 354 */         Dimension scrollSize = popupBounds.getSize();
/* 355 */         Point popupLocation = popupBounds.getLocation();
/*     */ 
/* 357 */         this.scroller.setMaximumSize(scrollSize);
/* 358 */         this.scroller.setPreferredSize(scrollSize);
/* 359 */         this.scroller.setMinimumSize(scrollSize);
/*     */ 
/* 361 */         this.list.revalidate();
/*     */ 
/* 363 */         return popupLocation;
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   protected ComboBoxEditor createEditor()
/*     */   {
/* 382 */     BasicComboBoxEditor.UIResource bcbe = new BasicComboBoxEditor.UIResource();
/* 383 */     if (bcbe != null)
/*     */     {
/* 385 */       Component c = bcbe.getEditorComponent();
/* 386 */       if (c != null)
/*     */       {
/* 389 */         ((JComponent)c).setOpaque(false);
/*     */ 
/* 398 */         Border border = (Border)UIManager.get("ComboBox.editorBorder");
/* 399 */         if (border != null)
/*     */         {
/* 401 */           ((JComponent)c).setBorder(border);
/*     */         }
/*     */       }
/*     */     }
/* 405 */     return bcbe;
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch14_combox.BEComboBoxUI
 * JD-Core Version:    0.6.2
 */