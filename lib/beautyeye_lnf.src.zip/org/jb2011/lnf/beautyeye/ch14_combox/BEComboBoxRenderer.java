/*     */ package org.jb2011.lnf.beautyeye.ch14_combox;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.basic.BasicComboBoxRenderer;
/*     */ import org.jb2011.lnf.beautyeye.ch9_menu.__Icon9Factory__;
/*     */ import org.jb2011.lnf.beautyeye.utils.BEUtils;
/*     */ import org.jb2011.ninepatch4j.NinePatch;
/*     */ 
/*     */ public class BEComboBoxRenderer extends BasicComboBoxRenderer
/*     */ {
/*  35 */   private boolean selected = false;
/*     */ 
/*  38 */   private BEComboBoxUI ui = null;
/*     */ 
/*     */   public BEComboBoxRenderer(BEComboBoxUI ui)
/*     */   {
/*  48 */     this.ui = ui;
/*     */ 
/*  51 */     setOpaque(false);
/*     */ 
/*  54 */     setBorder(BorderFactory.createEmptyBorder(5, 4, 5, 8));
/*     */   }
/*     */ 
/*     */   public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
/*     */   {
/*  68 */     Component c = super.getListCellRendererComponent(list, 
/*  69 */       value, index, isSelected, cellHasFocus);
/*     */ 
/*  71 */     this.selected = isSelected;
/*  72 */     return c;
/*     */   }
/*     */ 
/*     */   public void paintComponent(Graphics g)
/*     */   {
/*  83 */     if ((this.ui.isPopupVisible(null)) && (this.selected))
/*     */     {
/*  85 */       __Icon9Factory__.getInstance().getBgIcon_ItemSelected()
/*  86 */         .draw((Graphics2D)g, 0, 0, getWidth(), getHeight());
/*     */     }
/*  94 */     else if ((!this.ui.isPopupVisible(null)) && 
/*  95 */       (this.ui.getCombox().isFocusOwner()))
/*     */     {
/*  98 */       g.setColor(getBackground());
/*     */ 
/* 103 */       Insets is = new Insets(2, 0, 2, 3);
/*     */ 
/* 107 */       BEUtils.fillTextureRoundRec((Graphics2D)g, getBackground(), is.left, is.top, 
/* 108 */         getWidth() - is.left - is.right, 
/* 109 */         getHeight() - is.top - is.bottom, 20, 20);
/*     */     }
/*     */ 
/* 115 */     super.paintComponent(g);
/*     */   }
/*     */ 
/*     */   public static class UIResource extends BEComboBoxRenderer
/*     */     implements UIResource
/*     */   {
/*     */     public UIResource(BEComboBoxUI ui)
/*     */     {
/* 144 */       super();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\参考资料\java及开源框架\swing 实例\beautyeye_lnf_v3.5_all_in_one\beautyeye_lnf_v3.5_all_in_one\dist\beautyeye_lnf.jar
 * Qualified Name:     org.jb2011.lnf.beautyeye.ch14_combox.BEComboBoxRenderer
 * JD-Core Version:    0.6.2
 */